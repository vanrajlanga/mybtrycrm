/*
  # Create addon options table

  1. New Tables
    - `addon_options`
      - `id` (uuid, primary key)
      - `category_id` (uuid, foreign key)
      - `name` (text)
      - `description` (text, nullable)
      - `price` (numeric)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `addon_options` table
    - Add policies for viewing and managing options
*/

CREATE TABLE IF NOT EXISTS addon_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid REFERENCES addon_categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text,
  price numeric(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE addon_options ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Addon options are viewable by authenticated users"
  ON addon_options
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage addon options"
  ON addon_options
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );