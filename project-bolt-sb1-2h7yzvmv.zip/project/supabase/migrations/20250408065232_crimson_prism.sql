/*
  # Add Services Product Schema

  1. New Tables
    - `service_products`: Main services product table
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `price` (numeric)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `service_product_features`: Features for each service product
      - `id` (uuid, primary key)
      - `service_product_id` (uuid, references service_products)
      - `title` (text)
      - `description` (text)
      - `created_at` (timestamp)
    
    - `service_product_standards`: Standards and compliance
      - `id` (uuid, primary key)
      - `service_product_id` (uuid, references service_products)
      - `title` (text)
      - `description` (text)
      - `created_at` (timestamp)
    
    - `service_product_configurations`: Example project configurations
      - `id` (uuid, primary key)
      - `service_product_id` (uuid, references service_products)
      - `title` (text)
      - `description` (text)
      - `created_at` (timestamp)
    
    - `service_product_warranties`: Warranty options
      - `id` (uuid, primary key)
      - `service_product_id` (uuid, references service_products)
      - `title` (text)
      - `description` (text)
      - `duration_months` (integer)
      - `price` (numeric)
      - `created_at` (timestamp)
    
    - `service_product_benefits`: Customer benefits
      - `id` (uuid, primary key)
      - `service_product_id` (uuid, references service_products)
      - `title` (text)
      - `description` (text)
      - `created_at` (timestamp)
    
    - `service_product_guarantees`: Performance guarantees
      - `id` (uuid, primary key)
      - `service_product_id` (uuid, references service_products)
      - `title` (text)
      - `description` (text)
      - `created_at` (timestamp)
    
    - `service_product_trainings`: Training services
      - `id` (uuid, primary key)
      - `service_product_id` (uuid, references service_products)
      - `title` (text)
      - `description` (text)
      - `duration_days` (integer)
      - `price` (numeric)
      - `created_at` (timestamp)

  2. Updates to quotations table
    - Add service_product_id column
    - Add selected add-ons columns for each category

  3. Security
    - Enable RLS on all tables
    - Add policies for viewing and managing service products
*/

-- Create service_products table
CREATE TABLE IF NOT EXISTS service_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create service_product_features table
CREATE TABLE IF NOT EXISTS service_product_features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_product_id uuid REFERENCES service_products(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create service_product_standards table
CREATE TABLE IF NOT EXISTS service_product_standards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_product_id uuid REFERENCES service_products(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create service_product_configurations table
CREATE TABLE IF NOT EXISTS service_product_configurations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_product_id uuid REFERENCES service_products(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create service_product_warranties table
CREATE TABLE IF NOT EXISTS service_product_warranties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_product_id uuid REFERENCES service_products(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  duration_months integer NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create service_product_benefits table
CREATE TABLE IF NOT EXISTS service_product_benefits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_product_id uuid REFERENCES service_products(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create service_product_guarantees table
CREATE TABLE IF NOT EXISTS service_product_guarantees (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_product_id uuid REFERENCES service_products(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create service_product_trainings table
CREATE TABLE IF NOT EXISTS service_product_trainings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_product_id uuid REFERENCES service_products(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text NOT NULL,
  duration_days integer NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Add service_product_id to quotations table
ALTER TABLE quotations 
ADD COLUMN IF NOT EXISTS service_product_id uuid REFERENCES service_products(id),
ADD COLUMN IF NOT EXISTS selected_standards text[] DEFAULT '{}'::text[],
ADD COLUMN IF NOT EXISTS selected_configurations text[] DEFAULT '{}'::text[],
ADD COLUMN IF NOT EXISTS selected_benefits text[] DEFAULT '{}'::text[],
ADD COLUMN IF NOT EXISTS selected_guarantees text[] DEFAULT '{}'::text[];

-- Enable RLS
ALTER TABLE service_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_standards ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_warranties ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_benefits ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_guarantees ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_trainings ENABLE ROW LEVEL SECURITY;

-- Add RLS policies for service_products
CREATE POLICY "Service products are viewable by authenticated users"
  ON service_products FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage service products"
  ON service_products FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Add RLS policies for service_product_features
CREATE POLICY "Service product features are viewable by authenticated users"
  ON service_product_features FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage service product features"
  ON service_product_features FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Add RLS policies for service_product_standards
CREATE POLICY "Service product standards are viewable by authenticated users"
  ON service_product_standards FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage service product standards"
  ON service_product_standards FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Add RLS policies for service_product_configurations
CREATE POLICY "Service product configurations are viewable by authenticated users"
  ON service_product_configurations FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage service product configurations"
  ON service_product_configurations FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Add RLS policies for service_product_warranties
CREATE POLICY "Service product warranties are viewable by authenticated users"
  ON service_product_warranties FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage service product warranties"
  ON service_product_warranties FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Add RLS policies for service_product_benefits
CREATE POLICY "Service product benefits are viewable by authenticated users"
  ON service_product_benefits FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage service product benefits"
  ON service_product_benefits FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Add RLS policies for service_product_guarantees
CREATE POLICY "Service product guarantees are viewable by authenticated users"
  ON service_product_guarantees FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage service product guarantees"
  ON service_product_guarantees FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Add RLS policies for service_product_trainings
CREATE POLICY "Service product trainings are viewable by authenticated users"
  ON service_product_trainings FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can manage service product trainings"
  ON service_product_trainings FOR ALL TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));