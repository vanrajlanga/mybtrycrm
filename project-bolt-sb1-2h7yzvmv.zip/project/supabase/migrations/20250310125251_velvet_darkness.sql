/*
  # Create PCS Products Table

  1. New Tables
    - `pcs_products`
      - `id` (uuid, primary key)
      - `name` (text)
      - `manufacturer` (text)
      - `region` (text)
      - `specifications` (jsonb)
      - `tested_by_hq` (boolean)
      - `approved_by_hq` (boolean)
      - `price` (numeric)
      - `warranty` (integer)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for viewing and managing products
*/

-- Drop existing table if it exists
DROP TABLE IF EXISTS pcs_products;

-- Create PCS Products table
CREATE TABLE pcs_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  manufacturer text NOT NULL,
  region text NOT NULL,
  specifications jsonb DEFAULT '{}'::jsonb,
  tested_by_hq boolean DEFAULT false,
  approved_by_hq boolean DEFAULT false,
  price numeric(10,2) NOT NULL DEFAULT 0,
  warranty integer NOT NULL DEFAULT 12,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE pcs_products ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "PCS products are viewable by authenticated users"
  ON pcs_products
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage PCS products"
  ON pcs_products
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Insert sample data
INSERT INTO pcs_products (name, manufacturer, region, specifications, tested_by_hq, approved_by_hq, price, warranty) VALUES
-- Europe
('PowerConverter 100', 'SolarTech', 'europe', 
  '{"voltage": 400, "current": 250, "efficiency": 98.5, "power_factor": 0.99}'::jsonb,
  true, true, 22500, 24),
('GridMaster Pro', 'PowerSolutions', 'europe',
  '{"voltage": 400, "current": 300, "efficiency": 99.0, "power_factor": 0.99}'::jsonb,
  true, true, 27000, 36),
('EuroConverter X1', 'GridTech', 'europe',
  '{"voltage": 400, "current": 200, "efficiency": 98.0, "power_factor": 0.98}'::jsonb,
  true, true, 18000, 24),

-- North America
('PowerBridge NA', 'PowerSolutions', 'namerica',
  '{"voltage": 480, "current": 250, "efficiency": 98.5, "power_factor": 0.99}'::jsonb,
  true, true, 24000, 24),
('GridForce US', 'AmeriPower', 'namerica',
  '{"voltage": 480, "current": 300, "efficiency": 99.0, "power_factor": 0.99}'::jsonb,
  true, true, 28500, 36),
('NAConverter Pro', 'GridTech', 'namerica',
  '{"voltage": 480, "current": 200, "efficiency": 98.0, "power_factor": 0.98}'::jsonb,
  true, true, 19500, 24),

-- Asia
('AsiaGrid Master', 'PowerSolutions', 'asia',
  '{"voltage": 380, "current": 250, "efficiency": 98.5, "power_factor": 0.99}'::jsonb,
  true, true, 21000, 24),
('PowerLink AS', 'AsianPower', 'asia',
  '{"voltage": 380, "current": 300, "efficiency": 99.0, "power_factor": 0.99}'::jsonb,
  true, true, 25500, 36),
('AsiaTech Pro', 'GridTech', 'asia',
  '{"voltage": 380, "current": 200, "efficiency": 98.0, "power_factor": 0.98}'::jsonb,
  true, true, 16500, 24);