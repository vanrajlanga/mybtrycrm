-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Product descriptions are viewable by authenticated users" ON product_descriptions;
  DROP POLICY IF EXISTS "System features are viewable by authenticated users" ON system_features;
  DROP POLICY IF EXISTS "Product services are viewable by authenticated users" ON product_services;
  DROP POLICY IF EXISTS "Product warranties are viewable by authenticated users" ON product_warranties;
  DROP POLICY IF EXISTS "Product benefits are viewable by authenticated users" ON product_benefits;
  DROP POLICY IF EXISTS "Product trainings are viewable by authenticated users" ON product_trainings;
  DROP POLICY IF EXISTS "Quotations are viewable by creator" ON quotations;
  DROP POLICY IF EXISTS "Quotations can be created by authenticated users" ON quotations;
  DROP POLICY IF EXISTS "Quotations can be updated by creator" ON quotations;
END $$;

-- Create product_descriptions table
CREATE TABLE IF NOT EXISTS product_descriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_type text NOT NULL CHECK (product_type IN ('SPower', 'UPower')),
  description text NOT NULL,
  technical_details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create system_features table
CREATE TABLE IF NOT EXISTS system_features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_type text NOT NULL CHECK (product_type IN ('SPower', 'UPower')),
  title text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create product_services table
CREATE TABLE IF NOT EXISTS product_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_type text NOT NULL CHECK (product_type IN ('SPower', 'UPower')),
  title text NOT NULL,
  description text NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0,
  tax_rate numeric(5,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create product_warranties table
CREATE TABLE IF NOT EXISTS product_warranties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_type text NOT NULL CHECK (product_type IN ('SPower', 'UPower')),
  title text NOT NULL,
  description text NOT NULL,
  duration_months integer NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0,
  tax_rate numeric(5,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create product_benefits table
CREATE TABLE IF NOT EXISTS product_benefits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_type text NOT NULL CHECK (product_type IN ('SPower', 'UPower')),
  title text NOT NULL,
  description text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create product_trainings table
CREATE TABLE IF NOT EXISTS product_trainings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_type text NOT NULL CHECK (product_type IN ('SPower', 'UPower')),
  title text NOT NULL,
  description text NOT NULL,
  duration_days integer NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0,
  tax_rate numeric(5,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create quotations table
CREATE TABLE IF NOT EXISTS quotations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_name text NOT NULL,
  project_description text,
  editor_name text NOT NULL,
  planning_office text NOT NULL,
  customer_name text NOT NULL,
  customer_city text NOT NULL,
  customer_address text NOT NULL,
  customer_email text NOT NULL,
  customer_phone text NOT NULL,
  product_type text NOT NULL CHECK (product_type IN ('SPower', 'UPower')),
  selected_features text[] DEFAULT '{}'::text[],
  selected_services text[] DEFAULT '{}'::text[],
  selected_warranty text,
  selected_trainings text[] DEFAULT '{}'::text[],
  total_price numeric(10,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'accepted', 'rejected')),
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE product_descriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE system_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_warranties ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_benefits ENABLE ROW LEVEL SECURITY;
ALTER TABLE product_trainings ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotations ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Product descriptions are viewable by authenticated users"
  ON product_descriptions FOR SELECT TO authenticated USING (true);

CREATE POLICY "System features are viewable by authenticated users"
  ON system_features FOR SELECT TO authenticated USING (true);

CREATE POLICY "Product services are viewable by authenticated users"
  ON product_services FOR SELECT TO authenticated USING (true);

CREATE POLICY "Product warranties are viewable by authenticated users"
  ON product_warranties FOR SELECT TO authenticated USING (true);

CREATE POLICY "Product benefits are viewable by authenticated users"
  ON product_benefits FOR SELECT TO authenticated USING (true);

CREATE POLICY "Product trainings are viewable by authenticated users"
  ON product_trainings FOR SELECT TO authenticated USING (true);

CREATE POLICY "Quotations are viewable by creator"
  ON quotations FOR SELECT TO authenticated
  USING (created_by = auth.uid() OR EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

CREATE POLICY "Quotations can be created by authenticated users"
  ON quotations FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Quotations can be updated by creator"
  ON quotations FOR UPDATE TO authenticated
  USING (created_by = auth.uid() OR EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  ));

-- Insert sample data for SPower 304
INSERT INTO product_descriptions (product_type, description, technical_details) VALUES
('SPower', 'SPower 304 - Advanced Battery Energy Storage System', '{
  "capacity": "304kWh",
  "power": "60kW",
  "voltage": "800V",
  "efficiency": "95%",
  "response_time": "<100ms",
  "lifecycle": "20 years",
  "temperature_range": "-20°C to 55°C"
}'::jsonb);

INSERT INTO system_features (product_type, title, description) VALUES
('SPower', 'Advanced Battery Management', 'Intelligent BMS with real-time monitoring and predictive maintenance'),
('SPower', 'Thermal Management', 'Active cooling system with temperature optimization'),
('SPower', 'Safety Systems', 'Multi-level safety features including fire suppression and emergency shutdown'),
('SPower', 'Grid Integration', 'Seamless grid connection with advanced power conversion');

INSERT INTO product_services (product_type, title, description, price, tax_rate) VALUES
('SPower', 'Installation Service', 'Complete installation and commissioning', 10000, 10),
('SPower', 'Maintenance Package', 'Annual maintenance and system optimization', 5000, 10),
('SPower', 'Remote Monitoring', '24/7 remote system monitoring and support', 2000, 10);

INSERT INTO product_warranties (product_type, title, description, duration_months, price, tax_rate) VALUES
('SPower', 'Standard Warranty', 'Basic coverage for major components', 24, 0, 0),
('SPower', 'Extended Warranty', 'Comprehensive coverage with priority support', 60, 10000, 10),
('SPower', 'Premium Warranty', 'Full system coverage with performance guarantee', 120, 20000, 10);

INSERT INTO product_benefits (product_type, title, description) VALUES
('SPower', 'Energy Cost Reduction', 'Significant reduction in energy costs through peak shaving'),
('SPower', 'Grid Stability', 'Enhanced grid stability and power quality'),
('SPower', 'Renewable Integration', 'Seamless integration with renewable energy sources'),
('SPower', 'Carbon Footprint', 'Reduced carbon footprint and environmental impact');

INSERT INTO product_trainings (product_type, title, description, duration_days, price, tax_rate) VALUES
('SPower', 'Basic Operation', 'Essential system operation and maintenance', 2, 1000, 10),
('SPower', 'Advanced Operation', 'Advanced system configuration and troubleshooting', 3, 2000, 10),
('SPower', 'Technical Training', 'Comprehensive technical training for maintenance staff', 5, 5000, 10);