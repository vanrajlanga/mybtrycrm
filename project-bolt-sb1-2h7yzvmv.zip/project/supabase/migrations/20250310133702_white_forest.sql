/*
  # Add products and add-ons tables

  1. New Tables
    - `products`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `type` (text) - 'SPower' or 'UPower'
      - `specifications` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `addons`
      - `id` (uuid, primary key)
      - `category` (text) - e.g., 'protection_rating', 'thermal_management', etc.
      - `name` (text)
      - `description` (text)
      - `specifications` (jsonb)
      - `price` (numeric)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `order_addons`
      - `id` (uuid, primary key)
      - `order_id` (uuid, references orders)
      - `addon_id` (uuid, references addons)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  type text NOT NULL CHECK (type IN ('SPower', 'UPower')),
  specifications jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Products are viewable by authenticated users"
  ON products
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert products"
  ON products
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

CREATE POLICY "Admins can update products"
  ON products
  FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Add-ons table
CREATE TABLE IF NOT EXISTS addons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL,
  name text NOT NULL,
  description text,
  specifications jsonb DEFAULT '{}',
  price numeric(10,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE addons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Add-ons are viewable by authenticated users"
  ON addons
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert add-ons"
  ON addons
  FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

CREATE POLICY "Admins can update add-ons"
  ON addons
  FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Order add-ons junction table
CREATE TABLE IF NOT EXISTS order_addons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  addon_id uuid REFERENCES addons(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(order_id, addon_id)
);

ALTER TABLE order_addons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Order add-ons are viewable by order participants"
  ON order_addons
  FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM orders
    WHERE orders.id = order_addons.order_id
    AND (
      orders.customer_id = auth.uid()
      OR orders.sales_person_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND profiles.role = 'admin'
      )
    )
  ));

CREATE POLICY "Sales team can manage order add-ons"
  ON order_addons
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM orders
    WHERE orders.id = order_addons.order_id
    AND (
      orders.sales_person_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND profiles.role = 'admin'
      )
    )
  ))
  WITH CHECK (EXISTS (
    SELECT 1 FROM orders
    WHERE orders.id = order_addons.order_id
    AND (
      orders.sales_person_id = auth.uid()
      OR EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND profiles.role = 'admin'
      )
    )
  ));

-- Add delete policy for orders
CREATE POLICY "Users can delete their own orders"
  ON orders
  FOR DELETE
  TO authenticated
  USING (
    customer_id = auth.uid()
    OR sales_person_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Insert default add-ons
INSERT INTO addons (category, name, description, specifications, price) VALUES
  ('protection_rating', 'IP54 (Standard)', 'Suitable for controlled environments or areas with minimal dust and moisture.', '{"recommended_for": "Deployments with moderate environmental exposure"}', 0),
  ('protection_rating', 'IP65 (Enhanced)', 'Suitable for semi-outdoor or dusty environments with low-pressure water exposure.', '{"recommended_for": "Locations with higher dust levels or occasional exposure to moisture"}', 2500),
  ('protection_rating', 'IP68 (Fully Dust-Tight and Submersible)', 'Suitable for harsh outdoor environments or areas prone to flooding.', '{"recommended_for": "Locations requiring full protection from dust and water ingress"}', 5000),
  
  ('thermal_management', 'Natural Ventilation (Standard)', 'For highest monthly average temperatures up to 27°C.', '{"suitable_for": "Moderate climates where passive cooling is sufficient"}', 0),
  ('thermal_management', 'Forced Ventilation', 'For highest monthly average temperatures between 27°C and 40°C.', '{"suitable_for": "Warmer environments requiring enhanced airflow for cooling"}', 3000),
  ('thermal_management', 'Air Conditioning (AC)', 'For highest monthly average temperatures above 40°C (up to 50°C).', '{"suitable_for": "Extreme environments with prolonged heat exposure"}', 8000),
  
  ('insulation_type', 'Standard Insulation', 'For highest monthly average temperatures up to 30°C.', '{"suitable_for": "Mild climates and indoor installations"}', 0),
  ('insulation_type', 'Double-Layer Insulation', 'For highest monthly average temperatures above 30°C or below -10°C.', '{"suitable_for": "Extreme climates, including hot desert regions or cold environments"}', 4000),
  
  ('sun_protection', 'Sun-Reflecting Paint', 'For highest monthly average temperatures up to 30°C.', '{"suitable_for": "Locations with moderate sunlight exposure"}', 1500),
  ('sun_protection', 'Sun Umbrella™ Technology', 'For highest monthly average temperatures above 30°C.', '{"suitable_for": "Locations with intense and prolonged sunlight exposure"}', 3500),
  
  ('bms_options', 'Standard BMS', 'Provides essential monitoring and control for safe operation.', '{}', 0),
  ('bms_options', 'Intelligent BMS with Optional Monitoring and Control', 'Offers advanced features for proactive maintenance and performance optimization.', '{}', 5000),
  
  ('interconnection', 'IP65-Rated Interconnections', 'No groundwork required, supports fast commissioning, and ensures reliable connections in demanding environments.', '{}', 2000),
  
  ('installation_support', 'Installation Support', 'Provided by local RKP personnel or authorized service partners.', '{}', 7500),
  
  ('maintenance_services', 'Maintenance Services', 'Includes preventive maintenance, inspections, performance optimization, and reporting.', '{}', 5000),
  
  ('warranty', 'Standard 2-Year Warranty', 'Covers all major DC components.', '{"components": ["stack", "electrolyte", "tanks", "pumps", "BMS", "structure", "cooling system", "fans", "sensors"]}', 0),
  ('warranty', 'Extended Warranty', 'Customizable coverage based on customer needs.', '{}', 10000),
  
  ('performance_guarantee', 'Performance Guarantee', 'Ensures system efficiency and capacity retention with authorized maintenance.', '{}', 15000),
  
  ('training', 'Training Programs', 'On-demand training for customers, installation partners, and service partners.', '{}', 3000);