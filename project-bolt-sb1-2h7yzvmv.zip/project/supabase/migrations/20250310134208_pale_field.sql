/*
  # Create addon categories table

  1. New Tables
    - `addon_categories`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text, nullable)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `addon_categories` table
    - Add policies for viewing and managing categories
*/

CREATE TABLE IF NOT EXISTS addon_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE addon_categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Addon categories are viewable by authenticated users"
  ON addon_categories
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage addon categories"
  ON addon_categories
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );