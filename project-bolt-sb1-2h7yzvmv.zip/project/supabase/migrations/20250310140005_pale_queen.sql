/*
  # Add-ons Schema Update

  1. New Tables
    - `addon_categories`: Stores categories of add-ons
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text, nullable)
      - `created_at` (timestamp)
    
    - `addon_options`: Stores individual add-on options
      - `id` (uuid, primary key)
      - `category_id` (uuid, references addon_categories)
      - `name` (text)
      - `description` (text, nullable)
      - `price` (numeric)
      - `created_at` (timestamp)
    
    - `order_addons`: Junction table for orders and add-ons
      - `id` (uuid, primary key)
      - `order_id` (uuid, references orders)
      - `option_id` (uuid, references addon_options)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for viewing and managing add-ons
*/

-- Create addon_categories table if it doesn't exist
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS addon_categories (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    description text,
    created_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

-- Enable RLS and create policies for addon_categories
ALTER TABLE addon_categories ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addon_categories' 
    AND policyname = 'Addon categories are viewable by authenticated users'
  ) THEN
    CREATE POLICY "Addon categories are viewable by authenticated users" 
      ON addon_categories FOR SELECT TO authenticated 
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addon_categories' 
    AND policyname = 'Admins can manage addon categories'
  ) THEN
    CREATE POLICY "Admins can manage addon categories" 
      ON addon_categories FOR ALL TO authenticated 
      USING (EXISTS (
        SELECT 1 FROM profiles 
        WHERE profiles.id = auth.uid() 
        AND profiles.role = 'admin'
      ));
  END IF;
END $$;

-- Create addon_options table if it doesn't exist
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS addon_options (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id uuid REFERENCES addon_categories(id) ON DELETE CASCADE,
    name text NOT NULL,
    description text,
    price numeric(10,2) DEFAULT 0,
    created_at timestamptz DEFAULT now()
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

-- Enable RLS and create policies for addon_options
ALTER TABLE addon_options ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addon_options' 
    AND policyname = 'Addon options are viewable by authenticated users'
  ) THEN
    CREATE POLICY "Addon options are viewable by authenticated users" 
      ON addon_options FOR SELECT TO authenticated 
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addon_options' 
    AND policyname = 'Admins can manage addon options'
  ) THEN
    CREATE POLICY "Admins can manage addon options" 
      ON addon_options FOR ALL TO authenticated 
      USING (EXISTS (
        SELECT 1 FROM profiles 
        WHERE profiles.id = auth.uid() 
        AND profiles.role = 'admin'
      ));
  END IF;
END $$;

-- Create order_addons table if it doesn't exist
DO $$ BEGIN
  CREATE TABLE IF NOT EXISTS order_addons (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
    option_id uuid REFERENCES addon_options(id) ON DELETE CASCADE,
    created_at timestamptz DEFAULT now(),
    UNIQUE(order_id, option_id)
  );
EXCEPTION
  WHEN duplicate_table THEN NULL;
END $$;

-- Enable RLS and create policies for order_addons
ALTER TABLE order_addons ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'order_addons' 
    AND policyname = 'Order add-ons are viewable by order participants'
  ) THEN
    CREATE POLICY "Order add-ons are viewable by order participants" 
      ON order_addons FOR SELECT TO authenticated 
      USING (EXISTS (
        SELECT 1 FROM orders 
        WHERE orders.id = order_addons.order_id 
        AND (
          orders.customer_id = auth.uid() 
          OR orders.sales_person_id = auth.uid() 
          OR EXISTS (
            SELECT 1 FROM profiles 
            WHERE profiles.id = auth.uid() 
            AND profiles.role = 'admin'
          )
        )
      ));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'order_addons' 
    AND policyname = 'Sales team can manage order add-ons'
  ) THEN
    CREATE POLICY "Sales team can manage order add-ons" 
      ON order_addons FOR ALL TO authenticated 
      USING (EXISTS (
        SELECT 1 FROM orders 
        WHERE orders.id = order_addons.order_id 
        AND (
          orders.sales_person_id = auth.uid() 
          OR EXISTS (
            SELECT 1 FROM profiles 
            WHERE profiles.id = auth.uid() 
            AND profiles.role = 'admin'
          )
        )
      ));
  END IF;
END $$;