/*
  # Add quotation_date column to quotations table

  1. Changes
    - Add quotation_date column to quotations table
    - Add customer_country column to quotations table
    - Set default value for quotation_date to current timestamp
*/

ALTER TABLE quotations
ADD COLUMN IF NOT EXISTS quotation_date date DEFAULT CURRENT_DATE,
ADD COLUMN IF NOT EXISTS customer_country text;

-- Update existing rows to have a quotation date if null
UPDATE quotations
SET quotation_date = created_at::date
WHERE quotation_date IS NULL;

-- Make quotation_date NOT NULL
ALTER TABLE quotations
ALTER COLUMN quotation_date SET NOT NULL;