/*
  # Fix order_addons table schema

  1. Changes
    - Drop existing order_addons table
    - Recreate order_addons table with correct column names
    - Add foreign key constraints
    - Enable RLS
    - Add RLS policies

  2. Security
    - Enable RLS on order_addons table
    - Add policies for authenticated users
*/

-- Drop existing table if it exists
DROP TABLE IF EXISTS order_addons;

-- Create new table with correct schema
CREATE TABLE IF NOT EXISTS order_addons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  addon_id uuid REFERENCES addon_options(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(order_id, addon_id)
);

-- Enable RLS
ALTER TABLE order_addons ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Order add-ons are viewable by order participants"
  ON order_addons
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_addons.order_id
      AND (
        orders.customer_id = auth.uid()
        OR orders.sales_person_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM profiles
          WHERE profiles.id = auth.uid()
          AND profiles.role = 'admin'
        )
      )
    )
  );

CREATE POLICY "Sales team can manage order add-ons"
  ON order_addons
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_addons.order_id
      AND (
        orders.sales_person_id = auth.uid()
        OR EXISTS (
          SELECT 1 FROM profiles
          WHERE profiles.id = auth.uid()
          AND profiles.role = 'admin'
        )
      )
    )
  );