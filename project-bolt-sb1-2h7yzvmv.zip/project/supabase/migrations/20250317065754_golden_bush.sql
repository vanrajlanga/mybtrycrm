/*
  # Add Battery Products Schema

  1. New Tables
    - `battery_products`: Stores battery product configurations
      - `id` (uuid, primary key)
      - `type` (text) - Product type name (e.g., 'SPower', 'UPower')
      - `specifications` (jsonb) - Technical specifications
      - `dimensions` (jsonb) - Physical dimensions
      - `building_blocks` (jsonb) - Building block configurations
      - `spacing_requirements` (jsonb) - Layout spacing requirements
      - `active` (boolean) - Whether the product is active
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for viewing and managing products
*/

CREATE TABLE IF NOT EXISTS battery_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL UNIQUE,
  specifications jsonb NOT NULL DEFAULT '{}'::jsonb,
  dimensions jsonb NOT NULL DEFAULT '{}'::jsonb,
  building_blocks jsonb NOT NULL DEFAULT '[]'::jsonb,
  spacing_requirements jsonb NOT NULL DEFAULT '{}'::jsonb,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE battery_products ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Battery products are viewable by authenticated users"
  ON battery_products
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage battery products"
  ON battery_products
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Insert default battery products
INSERT INTO battery_products (type, specifications, dimensions, building_blocks, spacing_requirements) VALUES
(
  'SPower',
  '{
    "rated_power": 60,
    "dc_efficiency": "Rated power 80% (excluding self-consumption)",
    "dc_voltage": "DC104-166.4V",
    "max_dc_current": 577,
    "operating_temperature": "-20°C~50°C",
    "storage_temperature": "0°C~45°C",
    "operational_altitude": "<2,000 meters",
    "life_cycle": ">25 years / 20,000 cycles",
    "communication_protocol": "Modbus/TCP/CANbus/Ethernet",
    "ip_grade": "IP54 (optional up to IP65)",
    "auxiliary_power": {
      "type": "380V/AC, 50Hz, Three-phase",
      "stop": "200W",
      "operation": "3.2kW~8.6kW"
    },
    "design_standards": "IEC62932-2-1; IEC62932-2-2; GB/T32509-2016"
  }'::jsonb,
  '{
    "length": 6.058,
    "width": 2.438,
    "height": 2.591,
    "weight": {
      "net": "8T",
      "with_liquid": "21T"
    }
  }'::jsonb,
  '[
    {"containers": 1, "power": 60, "capacity": 240},
    {"containers": 3, "power": 180, "capacity": 720},
    {"containers": 6, "power": 360, "capacity": 1440},
    {"containers": 9, "power": 540, "capacity": 2160}
  ]'::jsonb,
  '{
    "length_spacing": 0.3,
    "width_spacing": 2.0
  }'::jsonb
),
(
  'UPower',
  '{
    "rated_power": 10,
    "dc_efficiency": "Rated power 80% (excluding self-consumption)",
    "dc_voltage": "36~57.6V",
    "max_dc_current": 390,
    "operating_temperature": "-15~50°C (SOC=50%)",
    "storage_temperature": "0°C~45°C",
    "operational_altitude": "<2,000 meters",
    "life_cycle": ">25 years / 20,000 cycles",
    "communication_protocol": "Ethernet",
    "ip_grade": "IP20/IP54",
    "auxiliary_power": {
      "type": "220V/AC, 50Hz, Two-phase"
    },
    "design_standards": "IEC62932-2-1; IEC62932-2-2; GB/T32509-2016"
  }'::jsonb,
  '{
    "models": [
      {
        "name": "UPower 104A",
        "length": 1.775,
        "width": 0.875,
        "height": 2.060,
        "weight": "2800kg"
      },
      {
        "name": "UPower 104B",
        "length": 1.775,
        "width": 0.915,
        "height": 2.110,
        "weight": "2800kg"
      }
    ]
  }'::jsonb,
  '[
    {"units": 1, "power": 10, "capacity": 40},
    {"units": 2, "power": 20, "capacity": 80},
    {"units": 3, "power": 30, "capacity": 120},
    {"units": 4, "power": 40, "capacity": 160},
    {"units": 5, "power": 50, "capacity": 200},
    {"units": 6, "power": 60, "capacity": 240}
  ]'::jsonb,
  '{
    "front_spacing": 0.5,
    "end_spacing": 0.1,
    "between_rows": 1.0
  }'::jsonb
);