/*
  # Fix RLS policies for service products

  1. Changes
    - Drop existing policies if they exist
    - Enable RLS on service_products table
    - Add policies for viewing and managing service products
    - Add WITH CHECK clause for admin policy

  2. Security
    - All authenticated users can view service products
    - Only admins can manage (create/update/delete) service products
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Service products are viewable by authenticated users" ON service_products;
  DROP POLICY IF EXISTS "Admins can manage service products" ON service_products;
END $$;

-- Enable RLS
ALTER TABLE service_products ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'service_products' 
    AND policyname = 'Service products are viewable by authenticated users'
  ) THEN
    CREATE POLICY "Service products are viewable by authenticated users"
      ON service_products
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'service_products' 
    AND policyname = 'Admins can manage service products'
  ) THEN
    CREATE POLICY "Admins can manage service products"
      ON service_products
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND profiles.role = 'admin'
      ))
      WITH CHECK (EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND profiles.role = 'admin'
      ));
  END IF;
END $$;