/*
  # Update Battery Layout Spacing Requirements

  1. Changes
    - Update spacing requirements for SPower and UPower batteries
    - Add specific spacing values for each battery type
    - Ensure proper unit arrangement based on provided diagrams

  2. Security
    - No changes to security policies
*/

-- Update SPower spacing requirements
UPDATE battery_products
SET spacing_requirements = '{
  "length_spacing": 0.3,
  "width_spacing": 2.0,
  "unit_arrangement": {
    "pattern": "grid",
    "rows": 2,
    "cols": 3
  }
}'::jsonb
WHERE type = 'SPower';

-- Update UPower spacing requirements
UPDATE battery_products
SET spacing_requirements = '{
  "front_spacing": 0.5,
  "end_spacing": 0.1,
  "between_rows": 1.0,
  "unit_arrangement": {
    "pattern": "grid",
    "rows": 2,
    "cols": 3,
    "front_spacing": 0.5,
    "end_spacing": 0.1,
    "row_spacing": 1.0
  }
}'::jsonb
WHERE type = 'UPower';