/*
  # Add battery features and PCS products tables

  1. New Tables
    - `battery_features`: Stores available features for battery types
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `battery_type` (text)
    
    - `pcs_products`: Stores PCS (Power Conversion System) products
      - `id` (uuid, primary key)
      - `name` (text)
      - `manufacturer` (text)
      - `region` (text)
      - `specifications` (jsonb)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users
*/

-- Create battery_features table
CREATE TABLE IF NOT EXISTS battery_features (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  battery_type text NOT NULL CHECK (battery_type IN ('type1', 'type2', 'both')),
  created_at timestamptz DEFAULT now()
);

-- Create pcs_products table
CREATE TABLE IF NOT EXISTS pcs_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  manufacturer text NOT NULL,
  region text NOT NULL,
  specifications jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE battery_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE pcs_products ENABLE ROW LEVEL SECURITY;

-- Policies for battery_features
CREATE POLICY "Battery features are viewable by authenticated users"
  ON battery_features
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert battery features"
  ON battery_features
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update battery features"
  ON battery_features
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Policies for pcs_products
CREATE POLICY "PCS products are viewable by authenticated users"
  ON pcs_products
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can insert PCS products"
  ON pcs_products
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Admins can update PCS products"
  ON pcs_products
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );