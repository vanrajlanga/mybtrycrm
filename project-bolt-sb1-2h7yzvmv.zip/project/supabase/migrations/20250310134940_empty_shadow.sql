/*
  # Insert Initial Add-on Data

  1. Categories
    - System protection ratings
    - Thermal management options
    - Safety features
    - Warranty options
    - And more...

  2. Options
    - Multiple options per category
    - Each with description and price
*/

-- Insert initial addon categories
INSERT INTO addon_categories (name, description) VALUES
  ('System Protection Rating', 'Protection level against environmental factors'),
  ('Thermal Management', 'Temperature control solutions'),
  ('Insulation Type', 'Thermal insulation options'),
  ('Sun Protection Technology', 'Protection against sun exposure'),
  ('Battery Management System', 'BMS configuration options'),
  ('Interconnection Type', 'Connection options between units'),
  ('Safety Features', 'Additional safety measures'),
  ('Installation Support', 'Installation services'),
  ('Maintenance Services', 'Maintenance and support options'),
  ('Warranty', 'Warranty coverage options'),
  ('Performance Guarantee', 'System performance guarantees'),
  ('Training Programs', 'Training and education services');

DO $$ 
DECLARE 
  category_id uuid;
BEGIN
  -- System Protection Rating options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'System Protection Rating';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'IP54 (Standard)', 'Suitable for controlled environments with minimal dust and moisture', 0),
    (category_id, 'IP65 (Enhanced)', 'Suitable for semi-outdoor or dusty environments with low-pressure water exposure', 2500),
    (category_id, 'IP68 (Fully Dust-Tight and Submersible)', 'Suitable for harsh outdoor environments or areas prone to flooding', 5000);

  -- Thermal Management options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Thermal Management';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Natural Ventilation', 'For highest monthly average temperatures up to 27°C', 0),
    (category_id, 'Forced Ventilation', 'For highest monthly average temperatures between 27°C and 40°C', 3000),
    (category_id, 'Air Conditioning', 'For highest monthly average temperatures above 40°C (up to 50°C)', 8000);

  -- Insulation Type options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Insulation Type';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Standard Insulation', 'For highest monthly average temperatures up to 30°C', 0),
    (category_id, 'Double-Layer Insulation', 'For highest monthly average temperatures above 30°C or below -10°C', 4000);

  -- Sun Protection Technology options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Sun Protection Technology';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Sun-Reflecting Paint', 'For highest monthly average temperatures up to 30°C', 1500),
    (category_id, 'Sun Umbrella™ Technology', 'For highest monthly average temperatures above 30°C', 3500);

  -- Battery Management System options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Battery Management System';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Standard BMS', 'Provides essential monitoring and control for safe operation', 0),
    (category_id, 'Intelligent BMS', 'Advanced features for proactive maintenance and performance optimization', 5000);

  -- Safety Features options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Safety Features';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Emergency Stop', 'Quick shutdown capability in emergency situations', 500),
    (category_id, 'Leak Detection', 'Early detection of potential leaks', 1000),
    (category_id, 'Overcharge Protection', 'Advanced protection against overcharging', 1500),
    (category_id, 'Overtemperature Protection', 'Temperature monitoring and protection system', 1500);

  -- Installation Support options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Installation Support';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Basic Installation', 'Standard installation service', 5000),
    (category_id, 'Premium Installation', 'Comprehensive installation with additional support', 8000);

  -- Maintenance Services options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Maintenance Services';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Basic Maintenance', 'Annual maintenance and inspection', 2000),
    (category_id, 'Premium Maintenance', 'Quarterly maintenance with 24/7 support', 5000);

  -- Warranty options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Warranty';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Standard 2-Year Warranty', 'Covers all major DC components', 0),
    (category_id, 'Extended 5-Year Warranty', 'Extended coverage for major components', 5000);

  -- Performance Guarantee options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Performance Guarantee';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Standard Performance Guarantee', 'Ensures system efficiency with authorized maintenance', 3000);

  -- Training Programs options
  SELECT id INTO category_id FROM addon_categories WHERE name = 'Training Programs';
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'Basic Training', 'Essential operation and maintenance training', 1500),
    (category_id, 'Advanced Training', 'Comprehensive training including troubleshooting', 3000);
END $$;