/*
  # Fix Service Product RLS Policies

  1. Changes
    - Drop existing policies if they exist
    - Add RLS policies for service products and related tables
    - Enable RLS on all tables
    - Add policies for viewing and managing service products

  2. Security
    - Only admins can create/update/delete service products
    - All authenticated users can view service products
*/

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Service products are viewable by authenticated users" ON service_products;
  DROP POLICY IF EXISTS "Admins can manage service products" ON service_products;
  DROP POLICY IF EXISTS "Service product features are viewable by authenticated users" ON service_product_features;
  DROP POLICY IF EXISTS "Admins can manage service product features" ON service_product_features;
  DROP POLICY IF EXISTS "Service product standards are viewable by authenticated users" ON service_product_standards;
  DROP POLICY IF EXISTS "Admins can manage service product standards" ON service_product_standards;
  DROP POLICY IF EXISTS "Service product configurations are viewable by authenticated users" ON service_product_configurations;
  DROP POLICY IF EXISTS "Admins can manage service product configurations" ON service_product_configurations;
  DROP POLICY IF EXISTS "Service product warranties are viewable by authenticated users" ON service_product_warranties;
  DROP POLICY IF EXISTS "Admins can manage service product warranties" ON service_product_warranties;
  DROP POLICY IF EXISTS "Service product benefits are viewable by authenticated users" ON service_product_benefits;
  DROP POLICY IF EXISTS "Admins can manage service product benefits" ON service_product_benefits;
  DROP POLICY IF EXISTS "Service product guarantees are viewable by authenticated users" ON service_product_guarantees;
  DROP POLICY IF EXISTS "Admins can manage service product guarantees" ON service_product_guarantees;
  DROP POLICY IF EXISTS "Service product trainings are viewable by authenticated users" ON service_product_trainings;
  DROP POLICY IF EXISTS "Admins can manage service product trainings" ON service_product_trainings;
END $$;

-- Enable RLS on all tables
ALTER TABLE service_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_features ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_standards ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_warranties ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_benefits ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_guarantees ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_product_trainings ENABLE ROW LEVEL SECURITY;

-- Add RLS policies for service_products
CREATE POLICY "Service products are viewable by authenticated users"
  ON service_products
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage service products"
  ON service_products
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Add RLS policies for service_product_features
CREATE POLICY "Service product features are viewable by authenticated users"
  ON service_product_features
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage service product features"
  ON service_product_features
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Add RLS policies for service_product_standards
CREATE POLICY "Service product standards are viewable by authenticated users"
  ON service_product_standards
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage service product standards"
  ON service_product_standards
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Add RLS policies for service_product_configurations  
CREATE POLICY "Service product configurations are viewable by authenticated users"
  ON service_product_configurations
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage service product configurations"
  ON service_product_configurations
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Add RLS policies for service_product_warranties
CREATE POLICY "Service product warranties are viewable by authenticated users"
  ON service_product_warranties
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage service product warranties"
  ON service_product_warranties
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Add RLS policies for service_product_benefits
CREATE POLICY "Service product benefits are viewable by authenticated users"
  ON service_product_benefits
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage service product benefits"
  ON service_product_benefits
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Add RLS policies for service_product_guarantees
CREATE POLICY "Service product guarantees are viewable by authenticated users"
  ON service_product_guarantees
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage service product guarantees"
  ON service_product_guarantees
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Add RLS policies for service_product_trainings
CREATE POLICY "Service product trainings are viewable by authenticated users"
  ON service_product_trainings
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage service product trainings"
  ON service_product_trainings
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));