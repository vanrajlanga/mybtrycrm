/*
  # Add Add-ons Schema

  1. New Tables
    - `addon_categories`: Categories for grouping add-on options
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text, optional)
      - `created_at` (timestamp)
    
    - `addon_options`: Individual add-on options within categories
      - `id` (uuid, primary key)
      - `category_id` (uuid, references addon_categories)
      - `name` (text)
      - `description` (text, optional)
      - `price` (numeric)
      - `created_at` (timestamp)
    
    - `order_addons`: Junction table linking orders to selected add-ons
      - `id` (uuid, primary key)
      - `order_id` (uuid, references orders)
      - `option_id` (uuid, references addon_options)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for viewing and managing add-ons
*/

-- Create tables if they don't exist
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'addon_categories') THEN
    CREATE TABLE addon_categories (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      name text NOT NULL,
      description text,
      created_at timestamptz DEFAULT now()
    );

    ALTER TABLE addon_categories ENABLE ROW LEVEL SECURITY;

    -- Add RLS policies for addon_categories
    CREATE POLICY "Addon categories are viewable by authenticated users"
      ON addon_categories FOR SELECT
      TO authenticated
      USING (true);

    CREATE POLICY "Admins can manage addon categories"
      ON addon_categories FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND profiles.role = 'admin'
      ));
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'addon_options') THEN
    CREATE TABLE addon_options (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      category_id uuid REFERENCES addon_categories(id) ON DELETE CASCADE,
      name text NOT NULL,
      description text,
      price numeric(10,2) DEFAULT 0,
      created_at timestamptz DEFAULT now()
    );

    ALTER TABLE addon_options ENABLE ROW LEVEL SECURITY;

    -- Add RLS policies for addon_options
    CREATE POLICY "Addon options are viewable by authenticated users"
      ON addon_options FOR SELECT
      TO authenticated
      USING (true);

    CREATE POLICY "Admins can manage addon options"
      ON addon_options FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND profiles.role = 'admin'
      ));
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'order_addons') THEN
    CREATE TABLE order_addons (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
      option_id uuid REFERENCES addon_options(id) ON DELETE CASCADE,
      created_at timestamptz DEFAULT now(),
      UNIQUE(order_id, option_id)
    );

    ALTER TABLE order_addons ENABLE ROW LEVEL SECURITY;

    -- Add RLS policies for order_addons
    CREATE POLICY "Order add-ons are viewable by order participants"
      ON order_addons FOR SELECT
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM orders
        WHERE orders.id = order_addons.order_id
        AND (
          orders.customer_id = auth.uid()
          OR orders.sales_person_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'admin'
          )
        )
      ));

    CREATE POLICY "Sales team can manage order add-ons"
      ON order_addons FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM orders
        WHERE orders.id = order_addons.order_id
        AND (
          orders.sales_person_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'admin'
          )
        )
      ));
  END IF;
END $$;

-- Insert sample data only if tables are empty
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM addon_categories) THEN
    INSERT INTO addon_categories (name, description) VALUES
      ('Safety Features', 'Additional safety and protection features'),
      ('Monitoring', 'Battery monitoring and management systems'),
      ('Installation', 'Additional installation services'),
      ('Warranty', 'Extended warranty options');

    INSERT INTO addon_options (category_id, name, description, price) VALUES
      ((SELECT id FROM addon_categories WHERE name = 'Safety Features'), 'Fire Suppression System', 'Automatic fire detection and suppression system', 5000),
      ((SELECT id FROM addon_categories WHERE name = 'Safety Features'), 'Enhanced Safety Barriers', 'Additional physical protection barriers', 2500),
      ((SELECT id FROM addon_categories WHERE name = 'Monitoring'), 'Advanced BMS', 'Enhanced battery management system with remote monitoring', 3500),
      ((SELECT id FROM addon_categories WHERE name = 'Monitoring'), 'Mobile App Integration', 'Real-time monitoring through mobile application', 1500),
      ((SELECT id FROM addon_categories WHERE name = 'Installation'), 'Premium Installation', 'Priority installation with extended testing', 4000),
      ((SELECT id FROM addon_categories WHERE name = 'Installation'), 'Site Preparation', 'Complete site preparation and foundation work', 3000),
      ((SELECT id FROM addon_categories WHERE name = 'Warranty'), '5-Year Extended Warranty', 'Extends standard warranty by 5 years', 2500),
      ((SELECT id FROM addon_categories WHERE name = 'Warranty'), '10-Year Extended Warranty', 'Extends standard warranty by 10 years', 4500);
  END IF;
END $$;