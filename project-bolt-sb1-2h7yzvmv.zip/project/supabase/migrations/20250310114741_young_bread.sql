/*
  # Update battery types to SPower and UPower

  1. Changes
    - Update battery_type check constraint in battery_features table
    - Update existing data to use new battery types

  2. Security
    - No changes to security policies
*/

-- Update battery_type check constraint
ALTER TABLE battery_features 
  DROP CONSTRAINT IF EXISTS battery_features_battery_type_check,
  ADD CONSTRAINT battery_features_battery_type_check 
    CHECK (battery_type IN ('SPower', 'UPower', 'both'));

-- Update existing data to use new battery types
DO $$ 
BEGIN
  UPDATE battery_features 
  SET battery_type = 'SPower' 
  WHERE battery_type = 'type1';

  UPDATE battery_features 
  SET battery_type = 'UPower' 
  WHERE battery_type = 'type2';
END $$;