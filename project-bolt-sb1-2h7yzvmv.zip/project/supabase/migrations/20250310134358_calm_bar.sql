/*
  # Add add-on options

  1. Changes
    - Insert add-on options for each category
    - Add error handling for duplicate entries
*/

DO $$ 
DECLARE 
  category_id uuid;
BEGIN
  -- Only proceed if the category exists and no options exist yet
  IF EXISTS (
    SELECT 1 FROM addon_categories
    WHERE name = 'Thermal Management'
  ) AND NOT EXISTS (
    SELECT 1 FROM addon_options
    WHERE name = 'Natural Ventilation'
  ) THEN
    -- Thermal Management options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Thermal Management';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Natural Ventilation', 'For highest monthly average temperatures up to 27°C', 0),
      (category_id, 'Forced Ventilation', 'For highest monthly average temperatures between 27°C and 40°C', 3000),
      (category_id, 'Air Conditioning', 'For highest monthly average temperatures above 40°C (up to 50°C)', 8000);

    -- Insulation Type options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Insulation Type';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Standard Insulation', 'For highest monthly average temperatures up to 30°C', 0),
      (category_id, 'Double-Layer Insulation', 'For highest monthly average temperatures above 30°C or below -10°C', 4000);

    -- Sun Protection Technology options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Sun Protection Technology';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Sun-Reflecting Paint', 'For highest monthly average temperatures up to 30°C', 1500),
      (category_id, 'Sun Umbrella™ Technology', 'For highest monthly average temperatures above 30°C', 3500);

    -- Battery Management System options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Battery Management System';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Standard BMS', 'Provides essential monitoring and control for safe operation', 0),
      (category_id, 'Intelligent BMS', 'Advanced features for proactive maintenance and performance optimization', 5000);

    -- Interconnection Type options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Interconnection Type';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'IP65-Rated Interconnections', 'No groundwork required, supports fast commissioning', 2000);

    -- Safety Features options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Safety Features';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Emergency Stop', 'Quick shutdown capability in emergency situations', 500),
      (category_id, 'Leak Detection', 'Early detection of potential leaks', 1000),
      (category_id, 'Overcharge Protection', 'Advanced protection against overcharging', 1500),
      (category_id, 'Overtemperature Protection', 'Temperature monitoring and protection system', 1500);

    -- Installation Support options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Installation Support';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Basic Installation', 'Standard installation service', 5000),
      (category_id, 'Premium Installation', 'Comprehensive installation with additional support', 8000);

    -- Maintenance Services options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Maintenance Services';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Basic Maintenance', 'Annual maintenance and inspection', 2000),
      (category_id, 'Premium Maintenance', 'Quarterly maintenance with 24/7 support', 5000);

    -- Warranty options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Warranty';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Standard 2-Year Warranty', 'Covers all major DC components', 0),
      (category_id, 'Extended 5-Year Warranty', 'Extended coverage for major components', 5000);

    -- Performance Guarantee options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Performance Guarantee';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Standard Performance Guarantee', 'Ensures system efficiency with authorized maintenance', 3000);

    -- Training Programs options
    SELECT id INTO category_id FROM addon_categories WHERE name = 'Training Programs';
    INSERT INTO addon_options (category_id, name, description, price) VALUES
      (category_id, 'Basic Training', 'Essential operation and maintenance training', 1500),
      (category_id, 'Advanced Training', 'Comprehensive training including troubleshooting', 3000);
  END IF;
END $$;