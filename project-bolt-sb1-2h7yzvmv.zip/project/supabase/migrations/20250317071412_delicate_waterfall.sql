/*
  # Add PCS Management Tables

  1. Changes
    - Create pcs_products table with improved schema
    - Add RLS policies for PCS management
    - Add unique constraints and validation

  2. Security
    - Enable RLS
    - Add policies for viewing and managing PCS products
*/

-- Create PCS Products table
CREATE TABLE IF NOT EXISTS pcs_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  manufacturer text NOT NULL,
  region text NOT NULL CHECK (region IN ('europe', 'namerica', 'asia')),
  specifications jsonb NOT NULL DEFAULT '{}'::jsonb,
  tested_by_hq boolean NOT NULL DEFAULT false,
  approved_by_hq boolean NOT NULL DEFAULT false,
  price numeric(10,2) NOT NULL DEFAULT 0,
  warranty integer NOT NULL DEFAULT 12,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(manufacturer, name, region)
);

-- Enable RLS
ALTER TABLE pcs_products ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "PCS products are viewable by authenticated users" ON pcs_products;
  DROP POLICY IF EXISTS "Admins can manage PCS products" ON pcs_products;
END $$;

-- Add RLS policies
CREATE POLICY "PCS products are viewable by authenticated users"
  ON pcs_products
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage PCS products"
  ON pcs_products
  FOR ALL
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM profiles
    WHERE profiles.id = auth.uid()
    AND profiles.role = 'admin'
  ));

-- Insert sample PCS products if none exist
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pcs_products) THEN
    INSERT INTO pcs_products (name, manufacturer, region, specifications, tested_by_hq, approved_by_hq, price, warranty) VALUES
    -- Europe
    ('PowerConverter 100', 'SolarTech', 'europe', 
      '{"voltage": 400, "current": 250, "efficiency": 98.5, "power_factor": 0.99}'::jsonb,
      true, true, 22500, 24),
    ('GridMaster Pro', 'PowerSolutions', 'europe',
      '{"voltage": 400, "current": 300, "efficiency": 99.0, "power_factor": 0.99}'::jsonb,
      true, true, 27000, 36),
    ('EuroConverter X1', 'GridTech', 'europe',
      '{"voltage": 400, "current": 200, "efficiency": 98.0, "power_factor": 0.98}'::jsonb,
      true, true, 18000, 24),

    -- North America
    ('PowerBridge NA', 'PowerSolutions', 'namerica',
      '{"voltage": 480, "current": 250, "efficiency": 98.5, "power_factor": 0.99}'::jsonb,
      true, true, 24000, 24),
    ('GridForce US', 'AmeriPower', 'namerica',
      '{"voltage": 480, "current": 300, "efficiency": 99.0, "power_factor": 0.99}'::jsonb,
      true, true, 28500, 36),
    ('NAConverter Pro', 'GridTech', 'namerica',
      '{"voltage": 480, "current": 200, "efficiency": 98.0, "power_factor": 0.98}'::jsonb,
      true, true, 19500, 24),

    -- Asia
    ('AsiaGrid Master', 'PowerSolutions', 'asia',
      '{"voltage": 380, "current": 250, "efficiency": 98.5, "power_factor": 0.99}'::jsonb,
      true, true, 21000, 24),
    ('PowerLink AS', 'AsianPower', 'asia',
      '{"voltage": 380, "current": 300, "efficiency": 99.0, "power_factor": 0.99}'::jsonb,
      true, true, 25500, 36),
    ('AsiaTech Pro', 'GridTech', 'asia',
      '{"voltage": 380, "current": 200, "efficiency": 98.0, "power_factor": 0.98}'::jsonb,
      true, true, 16500, 24);
  END IF;
END $$;