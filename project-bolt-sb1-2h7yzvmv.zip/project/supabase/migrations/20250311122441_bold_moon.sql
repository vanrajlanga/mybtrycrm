/*
  # Fix Profiles RLS Policies

  1. Changes
    - Enable RLS on profiles table
    - Add policy for admin users to manage all profiles
    - Add policy for users to read their own profile
    - Add policy for admin users to create new profiles
    - Add policy for users to update their own profile

  2. Security
    - Only admins can create new profiles
    - Users can only read and update their own profile
    - Admins have full access to all profiles
*/

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Admins can insert profiles" ON profiles;
DROP POLICY IF EXISTS "Admins can update profiles" ON profiles;
DROP POLICY IF EXISTS "Profiles are viewable by authenticated users" ON profiles;

-- Create new policies
CREATE POLICY "Admins have full access"
ON profiles
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles admin 
    WHERE admin.id = auth.uid() 
    AND admin.role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles admin 
    WHERE admin.id = auth.uid() 
    AND admin.role = 'admin'
  )
);

CREATE POLICY "Users can read own profile"
ON profiles
FOR SELECT
TO authenticated
USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
ON profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can create profiles"
ON profiles
FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles admin 
    WHERE admin.id = auth.uid() 
    AND admin.role = 'admin'
  )
);