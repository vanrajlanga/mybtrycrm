/*
  # Create PCS Products Table

  1. New Tables
    - `pcs_products`
      - `id` (uuid, primary key)
      - `name` (text)
      - `manufacturer` (text)
      - `region` (text)
      - `voltage` (numeric)
      - `current` (numeric)
      - `option_1` (text)
      - `option_2` (text)
      - `option_3` (text)
      - `option_4` (text)
      - `warranty` (integer, months)
      - `cost` (numeric)
      - `price` (numeric)
      - `tested_by_hq` (boolean)
      - `approved_by_hq` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for read/write access
*/

DO $$ BEGIN
  -- Create table if it doesn't exist
  CREATE TABLE IF NOT EXISTS pcs_products (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    manufacturer text NOT NULL,
    region text NOT NULL,
    voltage numeric NOT NULL,
    current numeric NOT NULL,
    option_1 text,
    option_2 text,
    option_3 text,
    option_4 text,
    warranty integer NOT NULL,
    cost numeric NOT NULL,
    price numeric NOT NULL,
    tested_by_hq boolean NOT NULL DEFAULT false,
    approved_by_hq boolean NOT NULL DEFAULT false,
    created_at timestamptz DEFAULT now(),
    updated_at timestamptz DEFAULT now()
  );

  -- Enable RLS if not already enabled
  ALTER TABLE pcs_products ENABLE ROW LEVEL SECURITY;

  -- Drop existing policies if they exist
  DROP POLICY IF EXISTS "PCS products are viewable by authenticated users" ON pcs_products;
  DROP POLICY IF EXISTS "Admins can insert PCS products" ON pcs_products;
  DROP POLICY IF EXISTS "Admins can update PCS products" ON pcs_products;

  -- Create new policies
  CREATE POLICY "PCS products are viewable by authenticated users"
    ON pcs_products
    FOR SELECT
    TO authenticated
    USING (true);

  CREATE POLICY "Admins can insert PCS products"
    ON pcs_products
    FOR INSERT
    TO authenticated
    WITH CHECK (EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    ));

  CREATE POLICY "Admins can update PCS products"
    ON pcs_products
    FOR UPDATE
    TO authenticated
    USING (EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    ));
END $$;