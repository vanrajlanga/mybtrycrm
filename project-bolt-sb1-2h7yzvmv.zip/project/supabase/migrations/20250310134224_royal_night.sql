/*
  # Insert initial addon data

  1. Data Population
    - Insert predefined categories
    - Insert predefined options for each category
*/

-- Insert categories
INSERT INTO addon_categories (name, description) VALUES
  ('System Protection Rating', 'Protection level against environmental factors'),
  ('Thermal Management', 'Temperature control solutions'),
  ('Insulation Type', 'Thermal insulation options'),
  ('Sun Protection Technology', 'Protection against sun exposure'),
  ('Battery Management System', 'BMS configuration options'),
  ('Interconnection Type', 'Connection options between units'),
  ('Safety Features', 'Additional safety measures'),
  ('Installation Support', 'Installation services'),
  ('Maintenance Services', 'Maintenance and support options'),
  ('Warranty', 'Warranty coverage options'),
  ('Performance Guarantee', 'System performance guarantees'),
  ('Training Programs', 'Training and education services');

-- System Protection Rating options
DO $$ 
DECLARE 
  category_id uuid;
BEGIN
  SELECT id INTO category_id FROM addon_categories WHERE name = 'System Protection Rating';
  
  INSERT INTO addon_options (category_id, name, description, price) VALUES
    (category_id, 'IP54 (Standard)', 'Suitable for controlled environments with minimal dust and moisture', 0),
    (category_id, 'IP65 (Enhanced)', 'Suitable for semi-outdoor or dusty environments with low-pressure water exposure', 2500),
    (category_id, 'IP68 (Fully Dust-Tight and Submersible)', 'Suitable for harsh outdoor environments or areas prone to flooding', 5000);
END $$;