/*
  # Fix order add-ons table policies

  1. Changes
    - Add policy existence checks before creation
    - Ensure policies are only created if they don't exist
*/

DO $$ 
BEGIN
  -- Create policies only if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'order_addons' 
    AND policyname = 'Order add-ons are viewable by order participants'
  ) THEN
    CREATE POLICY "Order add-ons are viewable by order participants"
      ON order_addons
      FOR SELECT
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM orders
          WHERE orders.id = order_addons.order_id
          AND (
            orders.customer_id = auth.uid()
            OR orders.sales_person_id = auth.uid()
            OR EXISTS (
              SELECT 1 FROM profiles
              WHERE profiles.id = auth.uid()
              AND profiles.role = 'admin'
            )
          )
        )
      );
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'order_addons' 
    AND policyname = 'Sales team can manage order add-ons'
  ) THEN
    CREATE POLICY "Sales team can manage order add-ons"
      ON order_addons
      FOR ALL
      TO authenticated
      USING (
        EXISTS (
          SELECT 1 FROM orders
          WHERE orders.id = order_addons.order_id
          AND (
            orders.sales_person_id = auth.uid()
            OR EXISTS (
              SELECT 1 FROM profiles
              WHERE profiles.id = auth.uid()
              AND profiles.role = 'admin'
            )
          )
        )
      );
  END IF;
END $$;