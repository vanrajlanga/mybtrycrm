/*
  # Create test users

  1. Changes
    - Insert test users for each role (admin, salesteam, customer)
    - Create corresponding profiles for each user
  
  2. Test Users
    - Admin: admin@example.com / admin123
    - Sales: sales@example.com / sales123
    - Customer: customer@example.com / customer123
*/

-- Create test users with auth.users
DO $$
DECLARE
  admin_id uuid;
  sales_id uuid;
  customer_id uuid;
BEGIN
  -- Admin user
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'admin@example.com') THEN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      recovery_sent_at,
      last_sign_in_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change,
      email_change_token_new,
      recovery_token
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'admin@example.com',
      crypt('admin123', gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{}',
      NOW(),
      NOW(),
      '',
      '',
      '',
      ''
    ) RETURNING id INTO admin_id;
  END IF;

  -- Sales user
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'sales@example.com') THEN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      recovery_sent_at,
      last_sign_in_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change,
      email_change_token_new,
      recovery_token
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'sales@example.com',
      crypt('sales123', gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{}',
      NOW(),
      NOW(),
      '',
      '',
      '',
      ''
    ) RETURNING id INTO sales_id;
  END IF;

  -- Customer user
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'customer@example.com') THEN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      recovery_sent_at,
      last_sign_in_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change,
      email_change_token_new,
      recovery_token
    )
    VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(),
      'authenticated',
      'authenticated',
      'customer@example.com',
      crypt('customer123', gen_salt('bf')),
      NOW(),
      NOW(),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{}',
      NOW(),
      NOW(),
      '',
      '',
      '',
      ''
    ) RETURNING id INTO customer_id;
  END IF;
END $$;

-- Create profiles for test users
DO $$
BEGIN
  -- Admin profile
  IF NOT EXISTS (
    SELECT 1 FROM profiles p
    JOIN auth.users u ON u.id = p.id
    WHERE u.email = 'admin@example.com'
  ) THEN
    INSERT INTO profiles (id, role, full_name)
    SELECT id, 'admin', 'Admin User'
    FROM auth.users
    WHERE email = 'admin@example.com';
  END IF;

  -- Sales profile
  IF NOT EXISTS (
    SELECT 1 FROM profiles p
    JOIN auth.users u ON u.id = p.id
    WHERE u.email = 'sales@example.com'
  ) THEN
    INSERT INTO profiles (id, role, full_name)
    SELECT id, 'salesteam', 'Sales User'
    FROM auth.users
    WHERE email = 'sales@example.com';
  END IF;

  -- Customer profile
  IF NOT EXISTS (
    SELECT 1 FROM profiles p
    JOIN auth.users u ON u.id = p.id
    WHERE u.email = 'customer@example.com'
  ) THEN
    INSERT INTO profiles (id, role, full_name)
    SELECT id, 'customer', 'Customer User'
    FROM auth.users
    WHERE email = 'customer@example.com';
  END IF;
END $$;