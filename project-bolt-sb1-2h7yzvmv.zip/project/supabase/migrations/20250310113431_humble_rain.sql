/*
  # Initial CRM Schema Setup

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key, references auth.users)
      - `role` (user_role enum)
      - `full_name` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `orders`
      - `id` (uuid, primary key)
      - `customer_id` (uuid, references profiles)
      - `sales_person_id` (uuid, references profiles)
      - `status` (text)
      - `product_type` (text)
      - `quantity` (integer)
      - `technical_specs` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `documents`
      - `id` (uuid, primary key)
      - `order_id` (uuid, references orders)
      - `type` (text)
      - `url` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for role-based access
*/

-- Create enum for user roles if it doesn't exist
DO $$ 
BEGIN 
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
    CREATE TYPE user_role AS ENUM ('admin', 'salesteam', 'customer');
  END IF;
END $$;

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  role user_role NOT NULL,
  full_name text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  sales_person_id uuid REFERENCES profiles(id),
  status text NOT NULL DEFAULT 'draft',
  product_type text NOT NULL,
  quantity integer NOT NULL,
  technical_specs jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  type text NOT NULL,
  url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  -- Profiles policies
  DROP POLICY IF EXISTS "Profiles are viewable by authenticated users" ON profiles;
  DROP POLICY IF EXISTS "Admins can insert profiles" ON profiles;
  DROP POLICY IF EXISTS "Admins can update profiles" ON profiles;
  
  -- Orders policies
  DROP POLICY IF EXISTS "Orders viewable by involved parties" ON orders;
  DROP POLICY IF EXISTS "Sales team can create orders" ON orders;
  DROP POLICY IF EXISTS "Sales team can update their orders" ON orders;
  
  -- Documents policies
  DROP POLICY IF EXISTS "Documents viewable by order participants" ON documents;
  DROP POLICY IF EXISTS "Sales team can create documents" ON documents;
END $$;

-- Profiles policies
CREATE POLICY "Profiles are viewable by authenticated users" ON profiles
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins can insert profiles" ON profiles
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IN (
    SELECT id FROM profiles WHERE role = 'admin'
  ));

CREATE POLICY "Admins can update profiles" ON profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() IN (
    SELECT id FROM profiles WHERE role = 'admin'
  ));

-- Orders policies
CREATE POLICY "Orders viewable by involved parties" ON orders
  FOR SELECT TO authenticated
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE role = 'admin'
    ) OR
    auth.uid() = customer_id OR
    auth.uid() = sales_person_id
  );

CREATE POLICY "Sales team can create orders" ON orders
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM profiles WHERE role IN ('admin', 'salesteam')
    )
  );

CREATE POLICY "Sales team can update their orders" ON orders
  FOR UPDATE TO authenticated
  USING (
    auth.uid() IN (
      SELECT id FROM profiles WHERE role = 'admin'
    ) OR
    auth.uid() = sales_person_id
  );

-- Documents policies
CREATE POLICY "Documents viewable by order participants" ON documents
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = documents.order_id
      AND (
        auth.uid() IN (
          SELECT id FROM profiles WHERE role = 'admin'
        ) OR
        auth.uid() = orders.customer_id OR
        auth.uid() = orders.sales_person_id
      )
    )
  );

CREATE POLICY "Sales team can create documents" ON documents
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM profiles WHERE role IN ('admin', 'salesteam')
    )
  );