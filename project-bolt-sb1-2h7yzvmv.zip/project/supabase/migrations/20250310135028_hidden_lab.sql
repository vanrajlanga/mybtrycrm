/*
  # Add-ons Schema Setup

  1. New Tables
    - `addon_categories`: Categories for grouping add-ons
    - `addon_options`: Individual add-on options within categories
    - `order_addons`: Junction table linking orders to selected add-ons

  2. Security
    - Enable RLS on all tables
    - Add policies for viewing and managing add-ons
*/

DO $$ 
BEGIN
  -- Create tables if they don't exist
  CREATE TABLE IF NOT EXISTS addon_categories (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    description text,
    created_at timestamptz DEFAULT now()
  );

  CREATE TABLE IF NOT EXISTS addon_options (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id uuid REFERENCES addon_categories(id) ON DELETE CASCADE,
    name text NOT NULL,
    description text,
    price numeric(10,2) DEFAULT 0,
    created_at timestamptz DEFAULT now()
  );

  CREATE TABLE IF NOT EXISTS order_addons (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
    option_id uuid REFERENCES addon_options(id) ON DELETE CASCADE,
    created_at timestamptz DEFAULT now(),
    UNIQUE(order_id, option_id)
  );

  -- Enable RLS
  ALTER TABLE addon_categories ENABLE ROW LEVEL SECURITY;
  ALTER TABLE addon_options ENABLE ROW LEVEL SECURITY;
  ALTER TABLE order_addons ENABLE ROW LEVEL SECURITY;

  -- Create policies if they don't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addon_categories' 
    AND policyname = 'Addon categories are viewable by authenticated users'
  ) THEN
    CREATE POLICY "Addon categories are viewable by authenticated users"
      ON addon_categories
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addon_categories' 
    AND policyname = 'Admins can manage addon categories'
  ) THEN
    CREATE POLICY "Admins can manage addon categories"
      ON addon_categories
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND profiles.role = 'admin'
      ));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addon_options' 
    AND policyname = 'Addon options are viewable by authenticated users'
  ) THEN
    CREATE POLICY "Addon options are viewable by authenticated users"
      ON addon_options
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'addon_options' 
    AND policyname = 'Admins can manage addon options'
  ) THEN
    CREATE POLICY "Admins can manage addon options"
      ON addon_options
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM profiles
        WHERE profiles.id = auth.uid()
        AND profiles.role = 'admin'
      ));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'order_addons' 
    AND policyname = 'Order add-ons are viewable by order participants'
  ) THEN
    CREATE POLICY "Order add-ons are viewable by order participants"
      ON order_addons
      FOR SELECT
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM orders
        WHERE orders.id = order_addons.order_id
        AND (
          orders.customer_id = auth.uid()
          OR orders.sales_person_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'admin'
          )
        )
      ));
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'order_addons' 
    AND policyname = 'Sales team can manage order add-ons'
  ) THEN
    CREATE POLICY "Sales team can manage order add-ons"
      ON order_addons
      FOR ALL
      TO authenticated
      USING (EXISTS (
        SELECT 1 FROM orders
        WHERE orders.id = order_addons.order_id
        AND (
          orders.sales_person_id = auth.uid()
          OR EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'admin'
          )
        )
      ));
  END IF;
END $$;