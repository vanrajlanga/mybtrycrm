/*
  # Remove duplicate add-ons

  1. Changes
    - Create temporary table to identify duplicates
    - Delete duplicate add-on options while keeping one copy
    - Update order_addons references to point to the kept copies
    - Add unique constraint to prevent future duplicates

  2. Security
    - No changes to RLS policies
*/

-- Create temporary table to store unique add-ons
CREATE TEMP TABLE unique_addons AS
SELECT DISTINCT ON (category_id, name, description, price) 
  id,
  category_id,
  name, 
  description,
  price,
  created_at
FROM addon_options;

-- Create mapping table for old to new IDs
CREATE TEMP TABLE addon_id_mapping AS
SELECT 
  ao.id as old_id,
  ua.id as new_id
FROM addon_options ao
JOIN unique_addons ua ON 
  ao.category_id = ua.category_id AND
  ao.name = ua.name AND
  ao.description IS NOT DISTINCT FROM ua.description AND
  ao.price = ua.price;

-- Update order_addons to point to kept copies
UPDATE order_addons oa
SET addon_id = aim.new_id
FROM addon_id_mapping aim
WHERE oa.addon_id = aim.old_id;

-- Delete duplicate add-ons
DELETE FROM addon_options ao
WHERE ao.id NOT IN (SELECT id FROM unique_addons);

-- Add unique constraint to prevent future duplicates
ALTER TABLE addon_options
ADD CONSTRAINT addon_options_unique_per_category 
UNIQUE (category_id, name, description, price);