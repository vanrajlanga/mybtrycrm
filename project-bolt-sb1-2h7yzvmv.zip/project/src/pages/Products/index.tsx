import { useState } from 'react';
import { Battery, Package, Plus, FileText } from 'lucide-react';
import BatteryProducts from './BatteryProducts';
import PCSProducts from './PCSProducts';
import ServiceProducts from './ServiceProducts';

type Tab = 'batteries' | 'pcs' | 'services';

export default function Products() {
  const [activeTab, setActiveTab] = useState<Tab>('batteries');

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('batteries')}
            className={`
              whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'batteries'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
            `}
          >
            <Battery className="inline-block h-5 w-5 mr-2" />
            Battery Products
          </button>
          <button
            onClick={() => setActiveTab('pcs')}
            className={`
              whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'pcs'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
            `}
          >
            <Package className="inline-block h-5 w-5 mr-2" />
            PCS Products
          </button>
          <button
            onClick={() => setActiveTab('services')}
            className={`
              whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
              ${activeTab === 'services'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}
            `}
          >
            <FileText className="inline-block h-5 w-5 mr-2" />
            Service Products
          </button>
        </nav>
      </div>

      <div>
        {activeTab === 'batteries' && <BatteryProducts />}
        {activeTab === 'pcs' && <PCSProducts />}
        {activeTab === 'services' && <ServiceProducts />}
      </div>
    </div>
  );
}