import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import { AlertCircle, Save, X } from 'lucide-react';

interface BatteryProductFormProps {
  productId?: string;
  onClose: () => void;
  onSave: () => void;
}

export default function BatteryProductForm({ productId, onClose, onSave }: BatteryProductFormProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    type: '',
    specifications: {
      rated_power: '',
      dc_efficiency: '',
      dc_voltage: '',
      max_dc_current: '',
      operating_temperature: '',
      storage_temperature: '',
      operational_altitude: '',
      life_cycle: '',
      communication_protocol: '',
      ip_grade: '',
      auxiliary_power: {
        type: '',
        stop: '',
        operation: ''
      },
      design_standards: ''
    },
    dimensions: {
      length: '',
      width: '',
      height: '',
      weight: {
        net: '',
        with_liquid: ''
      }
    },
    building_blocks: [] as Array<{
      containers?: number;
      units?: number;
      power: number;
      capacity: number;
    }>,
    spacing_requirements: {
      length_spacing: '',
      width_spacing: '',
      front_spacing: '',
      end_spacing: '',
      between_rows: ''
    },
    active: true
  });

  useEffect(() => {
    if (productId) {
      loadProduct();
    }
  }, [productId]);

  async function loadProduct() {
    try {
      const { data, error } = await supabase
        .from('battery_products')
        .select('*')
        .eq('id', productId)
        .single();

      if (error) throw error;
      if (data) {
        setFormData(data);
      }
    } catch (error) {
      console.error('Error loading product:', error);
      setError('Failed to load product details');
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const { error } = productId
        ? await supabase
            .from('battery_products')
            .update(formData)
            .eq('id', productId)
        : await supabase
            .from('battery_products')
            .insert([formData]);

      if (error) throw error;
      onSave();
    } catch (error: any) {
      console.error('Error saving product:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleBuildingBlockChange = (index: number, field: string, value: string) => {
    const blocks = [...formData.building_blocks];
    blocks[index] = {
      ...blocks[index],
      [field]: parseFloat(value) || 0
    };
    setFormData({ ...formData, building_blocks: blocks });
  };

  const addBuildingBlock = () => {
    setFormData({
      ...formData,
      building_blocks: [
        ...formData.building_blocks,
        { power: 0, capacity: 0 }
      ]
    });
  };

  const removeBuildingBlock = (index: number) => {
    const blocks = [...formData.building_blocks];
    blocks.splice(index, 1);
    setFormData({ ...formData, building_blocks: blocks });
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">
          {productId ? 'Edit Battery Product' : 'Add New Battery Product'}
        </h2>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-gray-500"
        >
          <X className="h-6 w-6" />
        </button>
      </div>

      {error && (
        <div className="mb-4 p-4 rounded-md bg-red-50 border border-red-200">
          <div className="flex">
            <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
            <p className="text-sm text-red-600">{error}</p>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <div>
          <label className="block text-sm font-medium text-gray-700">
            Product Type
          </label>
          <input
            type="text"
            value={formData.type}
            onChange={(e) => setFormData({ ...formData, type: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            required
          />
        </div>

        {/* Specifications */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900">Specifications</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Rated Power (kW)
              </label>
              <input
                type="number"
                value={formData.specifications.rated_power}
                onChange={(e) => setFormData({
                  ...formData,
                  specifications: {
                    ...formData.specifications,
                    rated_power: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                DC Efficiency
              </label>
              <input
                type="text"
                value={formData.specifications.dc_efficiency}
                onChange={(e) => setFormData({
                  ...formData,
                  specifications: {
                    ...formData.specifications,
                    dc_efficiency: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                DC Voltage
              </label>
              <input
                type="text"
                value={formData.specifications.dc_voltage}
                onChange={(e) => setFormData({
                  ...formData,
                  specifications: {
                    ...formData.specifications,
                    dc_voltage: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Max DC Current
              </label>
              <input
                type="text"
                value={formData.specifications.max_dc_current}
                onChange={(e) => setFormData({
                  ...formData,
                  specifications: {
                    ...formData.specifications,
                    max_dc_current: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
            </div>
          </div>
        </div>

        {/* Dimensions */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900">Dimensions</h3>
          
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Length (m)
              </label>
              <input
                type="number"
                step="0.001"
                value={formData.dimensions.length}
                onChange={(e) => setFormData({
                  ...formData,
                  dimensions: {
                    ...formData.dimensions,
                    length: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Width (m)
              </label>
              <input
                type="number"
                step="0.001"
                value={formData.dimensions.width}
                onChange={(e) => setFormData({
                  ...formData,
                  dimensions: {
                    ...formData.dimensions,
                    width: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Height (m)
              </label>
              <input
                type="number"
                step="0.001"
                value={formData.dimensions.height}
                onChange={(e) => setFormData({
                  ...formData,
                  dimensions: {
                    ...formData.dimensions,
                    height: e.target.value
                  }
                })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
            </div>
          </div>
        </div>

        {/* Building Blocks */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium text-gray-900">Building Blocks</h3>
            <button
              type="button"
              onClick={addBuildingBlock}
              className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
            >
              Add Block
            </button>
          </div>

          {formData.building_blocks.map((block, index) => (
            <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
              {formData.type === 'SPower' ? (
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700">
                    Containers
                  </label>
                  <input
                    type="number"
                    value={block.containers}
                    onChange={(e) => handleBuildingBlockChange(index, 'containers', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              ) : (
                <div className="flex-1">
                  <label className="block text-sm font-medium text-gray-700">
                    Units
                  </label>
                  <input
                    type="number"
                    value={block.units}
                    onChange={(e) => handleBuildingBlockChange(index, 'units', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              )}

              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700">
                  Power (kW)
                </label>
                <input
                  type="number"
                  value={block.power}
                  onChange={(e) => handleBuildingBlockChange(index, 'power', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
              </div>

              <div className="flex-1">
                <label className="block text-sm font-medium text-gray-700">
                  Capacity (kWh)
                </label>
                <input
                  type="number"
                  value={block.capacity}
                  onChange={(e) => handleBuildingBlockChange(index, 'capacity', e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
              </div>

              <button
                type="button"
                onClick={() => removeBuildingBlock(index)}
                className="mt-6 text-red-600 hover:text-red-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          ))}
        </div>

        {/* Spacing Requirements */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900">Spacing Requirements</h3>
          
          <div className="grid grid-cols-2 gap-4">
            {formData.type === 'SPower' ? (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Length Spacing (m)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.spacing_requirements.length_spacing}
                    onChange={(e) => setFormData({
                      ...formData,
                      spacing_requirements: {
                        ...formData.spacing_requirements,
                        length_spacing: e.target.value
                      }
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Width Spacing (m)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.spacing_requirements.width_spacing}
                    onChange={(e) => setFormData({
                      ...formData,
                      spacing_requirements: {
                        ...formData.spacing_requirements,
                        width_spacing: e.target.value
                      }
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              </>
            ) : (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Front Spacing (m)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.spacing_requirements.front_spacing}
                    onChange={(e) => setFormData({
                      ...formData,
                      spacing_requirements: {
                        ...formData.spacing_requirements,
                        front_spacing: e.target.value
                      }
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    End Spacing (m)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.spacing_requirements.end_spacing}
                    onChange={(e) => setFormData({
                      ...formData,
                      spacing_requirements: {
                        ...formData.spacing_requirements,
                        end_spacing: e.target.value
                      }
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Between Rows (m)
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.spacing_requirements.between_rows}
                    onChange={(e) => setFormData({
                      ...formData,
                      spacing_requirements: {
                        ...formData.spacing_requirements,
                        between_rows: e.target.value
                      }
                    })}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              </>
            )}
          </div>
        </div>

        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={loading}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
            ) : (
              <>
                <Save className="h-5 w-5 mr-2" />
                Save Product
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}