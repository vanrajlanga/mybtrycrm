import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { supabase } from '../../lib/supabase';
import { Battery, Plus, AlertCircle } from 'lucide-react';
import type { ServiceProduct, ServiceProductFeature, ServiceProductStandard, ServiceProductConfiguration, ServiceProductWarranty, ServiceProductBenefit, ServiceProductGuarantee, ServiceProductTraining } from '../../types';
import { formatCurrency } from '../../lib/utils';

interface FormData {
  projectName: string;
  projectDescription: string;
  editorName: string;
  planningOffice: string;
  customerName: string;
  customerCity: string;
  customerAddress: string;
  customerEmail: string;
  customerPhone: string;
  customerCountry: string;
  quotationDate: string;
  serviceProductId: string;
  selectedFeatures: string[];
  selectedStandards: string[];
  selectedConfigurations: string[];
  selectedWarranty: string;
  selectedBenefits: string[];
  selectedGuarantees: string[];
  selectedTrainings: string[];
  productType: 'SPower' | 'UPower';
}

export default function QuotationForm() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(1);

  const [formData, setFormData] = useState<FormData>({
    projectName: '',
    projectDescription: '',
    editorName: '',
    planningOffice: '',
    customerName: '',
    customerCity: '',
    customerAddress: '',
    customerEmail: '',
    customerPhone: '',
    customerCountry: '',
    quotationDate: new Date().toISOString().split('T')[0],
    serviceProductId: '',
    selectedFeatures: [],
    selectedStandards: [],
    selectedConfigurations: [],
    selectedWarranty: '',
    selectedBenefits: [],
    selectedGuarantees: [],
    selectedTrainings: [],
    productType: 'SPower'
  });

  const [serviceProducts, setServiceProducts] = useState<ServiceProduct[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<{
    features: ServiceProductFeature[];
    standards: ServiceProductStandard[];
    configurations: ServiceProductConfiguration[];
    warranties: ServiceProductWarranty[];
    benefits: ServiceProductBenefit[];
    guarantees: ServiceProductGuarantee[];
    trainings: ServiceProductTraining[];
  } | null>(null);

  useEffect(() => {
    fetchServiceProducts();
  }, []);

  useEffect(() => {
    if (formData.serviceProductId) {
      fetchProductDetails();
    }
  }, [formData.serviceProductId]);

  const canMoveToStep = (step: number) => {
    switch (step) {
      case 1:
        return true;
      case 2:
        return formData.projectName && formData.editorName && formData.planningOffice && formData.quotationDate;
      case 3:
        return formData.customerName && formData.customerEmail && formData.customerPhone && formData.customerCountry;
      case 4:
        return formData.serviceProductId !== '';
      default:
        return false;
    }
  };

  const handleStepClick = (step: number) => {
    if (step <= currentStep || canMoveToStep(step)) {
      setCurrentStep(step);
    }
  };

  async function fetchServiceProducts() {
    try {
      const { data, error } = await supabase
        .from('service_products')
        .select('*')
        .order('title');

      if (error) throw error;
      setServiceProducts(data || []);
    } catch (error: any) {
      console.error('Error fetching service products:', error);
      setError(error.message);
    }
  }

  async function fetchProductDetails() {
    if (!formData.serviceProductId) return;

    try {
      const [
        { data: features },
        { data: standards },
        { data: configurations },
        { data: warranties },
        { data: benefits },
        { data: guarantees },
        { data: trainings }
      ] = await Promise.all([
        supabase
          .from('service_product_features')
          .select('*')
          .eq('service_product_id', formData.serviceProductId),
        supabase
          .from('service_product_standards')
          .select('*')
          .eq('service_product_id', formData.serviceProductId),
        supabase
          .from('service_product_configurations')
          .select('*')
          .eq('service_product_id', formData.serviceProductId),
        supabase
          .from('service_product_warranties')
          .select('*')
          .eq('service_product_id', formData.serviceProductId),
        supabase
          .from('service_product_benefits')
          .select('*')
          .eq('service_product_id', formData.serviceProductId),
        supabase
          .from('service_product_guarantees')
          .select('*')
          .eq('service_product_id', formData.serviceProductId),
        supabase
          .from('service_product_trainings')
          .select('*')
          .eq('service_product_id', formData.serviceProductId)
      ]);

      setSelectedProduct({
        features: features || [],
        standards: standards || [],
        configurations: configurations || [],
        warranties: warranties || [],
        benefits: benefits || [],
        guarantees: guarantees || [],
        trainings: trainings || []
      });
    } catch (error: any) {
      console.error('Error fetching product details:', error);
      setError(error.message);
    }
  }

  const calculateTotal = () => {
    if (!selectedProduct) return 0;

    let total = 0;

    // Add base product price
    const product = serviceProducts.find(p => p.id === formData.serviceProductId);
    if (product) {
      total += product.price;
    }

    // Add warranty price
    const selectedWarrantyOption = selectedProduct.warranties.find(w => w.id === formData.selectedWarranty);
    if (selectedWarrantyOption) {
      total += selectedWarrantyOption.price;
    }

    // Add training prices
    formData.selectedTrainings.forEach(trainingId => {
      const training = selectedProduct.trainings.find(t => t.id === trainingId);
      if (training) {
        total += training.price;
      }
    });

    return total;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (currentStep < 4) {
      if (canMoveToStep(currentStep + 1)) {
        setCurrentStep(currentStep + 1);
      }
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data: quotation, error: quotationError } = await supabase
        .from('quotations')
        .insert([
          {
            project_name: formData.projectName,
            project_description: formData.projectDescription,
            editor_name: formData.editorName,
            planning_office: formData.planningOffice,
            customer_name: formData.customerName,
            customer_city: formData.customerCity,
            customer_address: formData.customerAddress,
            customer_email: formData.customerEmail,
            customer_phone: formData.customerPhone,
            customer_country: formData.customerCountry,
            quotation_date: formData.quotationDate,
            service_product_id: formData.serviceProductId,
            selected_features: formData.selectedFeatures,
            selected_standards: formData.selectedStandards,
            selected_configurations: formData.selectedConfigurations,
            selected_warranty: formData.selectedWarranty,
            selected_benefits: formData.selectedBenefits,
            selected_guarantees: formData.selectedGuarantees,
            selected_trainings: formData.selectedTrainings,
            total_price: calculateTotal(),
            created_by: user?.id,
            status: 'draft',
            product_type: formData.productType
          }
        ])
        .select()
        .single();

      if (quotationError) throw quotationError;

      navigate(`/dashboard/quotations/${quotation.id}`);
    } catch (error: any) {
      console.error('Error creating quotation:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center mb-6">
          <Battery className="h-8 w-8 text-blue-600 mr-3" />
          <h2 className="text-2xl font-bold text-gray-900">Create Quotation</h2>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-md bg-red-50 border border-red-200">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          </div>
        )}

        <div className="mb-8">
          <div className="flex flex-wrap gap-4 mb-6">
            <button
              onClick={() => handleStepClick(1)}
              className={`flex-1 px-4 py-2 text-sm font-medium rounded-md ${
                currentStep === 1
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-blue-600 border border-blue-600 hover:bg-blue-50'
              }`}
            >
              Project Details
            </button>
            <button
              onClick={() => handleStepClick(2)}
              className={`flex-1 px-4 py-2 text-sm font-medium rounded-md ${
                currentStep === 2
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-blue-600 border border-blue-600 hover:bg-blue-50'
              }`}
            >
              Customer Details
            </button>
            <button
              onClick={() => handleStepClick(3)}
              className={`flex-1 px-4 py-2 text-sm font-medium rounded-md ${
                currentStep === 3
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-blue-600 border border-blue-600 hover:bg-blue-50'
              }`}
            >
              Service Selection
            </button>
            <button
              onClick={() => handleStepClick(4)}
              className={`flex-1 px-4 py-2 text-sm font-medium rounded-md ${
                currentStep === 4
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-blue-600 border border-blue-600 hover:bg-blue-50'
              }`}
            >
              Additional Options
            </button>
          </div>

          <div className="relative pt-1">
            <div className="flex mb-2 items-center justify-between">
              <div>
                <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                  Step {currentStep} of 4
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold inline-block text-blue-600">
                  {Math.round((currentStep / 4) * 100)}%
                </span>
              </div>
            </div>
            <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
              <div
                style={{ width: `${(currentStep / 4) * 100}%` }}
                className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600"
              ></div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Project Name</label>
                <input
                  type="text"
                  value={formData.projectName}
                  onChange={(e) => setFormData(prev => ({ ...prev, projectName: e.target.value }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Project Description</label>
                <textarea
                  value={formData.projectDescription}
                  onChange={(e) => setFormData(prev => ({ ...prev, projectDescription: e.target.value }))}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Quotation Date</label>
                <input
                  type="date"
                  value={formData.quotationDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, quotationDate: e.target.value }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Editor Name</label>
                  <input
                    type="text"
                    value={formData.editorName}
                    onChange={(e) => setFormData(prev => ({ ...prev, editorName: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Planning Office</label>
                  <input
                    type="text"
                    value={formData.planningOffice}
                    onChange={(e) => setFormData(prev => ({ ...prev, planningOffice: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Product Type</label>
                <select
                  value={formData.productType}
                  onChange={(e) => setFormData(prev => ({ ...prev, productType: e.target.value as 'SPower' | 'UPower' }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  required
                >
                  <option value="SPower">SPower</option>
                  <option value="UPower">UPower</option>
                </select>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Customer Name</label>
                  <input
                    type="text"
                    value={formData.customerName}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerName: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Country</label>
                  <input
                    type="text"
                    value={formData.customerCountry}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerCountry: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">City</label>
                  <input
                    type="text"
                    value={formData.customerCity}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerCity: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Address</label>
                  <input
                    type="text"
                    value={formData.customerAddress}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerAddress: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    value={formData.customerEmail}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerEmail: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Phone</label>
                  <input
                    type="tel"
                    value={formData.customerPhone}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerPhone: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Service Product</label>
                <select
                  value={formData.serviceProductId}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    serviceProductId: e.target.value,
                    selectedFeatures: [],
                    selectedStandards: [],
                    selectedConfigurations: [],
                    selectedWarranty: '',
                    selectedBenefits: [],
                    selectedGuarantees: [],
                    selectedTrainings: []
                  }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  required
                >
                  <option value="">Select a Service Product</option>
                  {serviceProducts.map(product => (
                    <option key={product.id} value={product.id}>
                      {product.title} - {formatCurrency(product.price)}
                    </option>
                  ))}
                </select>
              </div>

              {selectedProduct && (
                <>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Features</h3>
                    <div className="space-y-4">
                      {selectedProduct.features.map(feature => (
                        <label key={feature.id} className="flex items-start space-x-3">
                          <div className="flex items-center h-5">
                            <input
                              type="checkbox"
                              checked={formData.selectedFeatures.includes(feature.id)}
                              onChange={(e) => {
                                const newFeatures = e.target.checked
                                  ? [...formData.selectedFeatures, feature.id]
                                  : formData.selectedFeatures.filter(id => id !== feature.id);
                                setFormData(prev => ({ ...prev, selectedFeatures: newFeatures }));
                              }}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900">{feature.title}</p>
                            <p className="text-sm text-gray-500">{feature.description}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-4">Standards</h3>
                    <div className="space-y-4">
                      {selectedProduct.standards.map(standard => (
                        <label key={standard.id} className="flex items-start space-x-3">
                          <div className="flex items-center h-5">
                            <input
                              type="checkbox"
                              checked={formData.selectedStandards.includes(standard.id)}
                              onChange={(e) => {
                                const newStandards = e.target.checked
                                  ? [...formData.selectedStandards, standard.id]
                                  : formData.selectedStandards.filter(id => id !== standard.id);
                                setFormData(prev => ({ ...prev, selectedStandards: newStandards }));
                              }}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            />
                          </div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-gray-900">{standard.title}</p>
                            <p className="text-sm text-gray-500">{standard.description}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {currentStep === 4 && selectedProduct && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Configurations</h3>
                <div className="space-y-4">
                  {selectedProduct.configurations.map(config => (
                    <label key={config.id} className="flex items-start space-x-3">
                      <div className="flex items-center h-5">
                        <input
                          type="checkbox"
                          checked={formData.selectedConfigurations.includes(config.id)}
                          onChange={(e) => {
                            const newConfigs = e.target.checked
                              ? [...formData.selectedConfigurations, config.id]
                              : formData.selectedConfigurations.filter(id => id !== config.id);
                            setFormData(prev => ({ ...prev, selectedConfigurations: newConfigs }));
                          }}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{config.title}</p>
                        <p className="text-sm text-gray-500">{config.description}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Warranty Options</h3>
                <div className="space-y-4">
                  {selectedProduct.warranties.map(warranty => (
                    <label key={warranty.id} className="flex items-start space-x-3">
                      <div className="flex items-center h-5">
                        <input
                          type="radio"
                          checked={formData.selectedWarranty === warranty.id}
                          onChange={() => setFormData(prev => ({ ...prev, selectedWarranty: warranty.id }))}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <p className="text-sm font-medium text-gray-900">{warranty.title}</p>
                          <p className="text-sm font-medium text-gray-900">
                            {warranty.price === 0 ? 'Included' : formatCurrency(warranty.price)}
                          </p>
                        </div>
                        <p className="text-sm text-gray-500">{warranty.description}</p>
                        <p className="text-sm text-gray-500">Duration: {warranty.duration_months} months</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Benefits</h3>
                <div className="space-y-4">
                  {selectedProduct.benefits.map(benefit => (
                    <label key={benefit.id} className="flex items-start space-x-3">
                      <div className="flex items-center h-5">
                        <input
                          type="checkbox"
                          checked={formData.selectedBenefits.includes(benefit.id)}
                          onChange={(e) => {
                            const newBenefits = e.target.checked
                              ? [...formData.selectedBenefits, benefit.id]
                              : formData.selectedBenefits.filter(id => id !== benefit.id);
                            setFormData(prev => ({ ...prev, selectedBenefits: newBenefits }));
                          }}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{benefit.title}</p>
                        <p className="text-sm text-gray-500">{benefit.description}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Guarantees</h3>
                <div className="space-y-4">
                  {selectedProduct.guarantees.map(guarantee => (
                    <label key={guarantee.id} className="flex items-start space-x-3">
                      <div className="flex items-center h-5">
                        <input
                          type="checkbox"
                          checked={formData.selectedGuarantees.includes(guarantee.id)}
                          onChange={(e) => {
                            const newGuarantees = e.target.checked
                              ? [...formData.selectedGuarantees, guarantee.id]
                              : formData.selectedGuarantees.filter(id => id !== guarantee.id);
                            setFormData(prev => ({ ...prev, selectedGuarantees: newGuarantees }));
                          }}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{guarantee.title}</p>
                        <p className="text-sm text-gray-500">{guarantee.description}</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Training Services</h3>
                <div className="space-y-4">
                  {selectedProduct.trainings.map(training => (
                    <label key={training.id} className="flex items-start space-x-3">
                      <div className="flex items-center h-5">
                        <input
                          type="checkbox"
                          checked={formData.selectedTrainings.includes(training.id)}
                          onChange={(e) => {
                            const newTrainings = e.target.checked
                              ? [...formData.selectedTrainings, training.id]
                              : formData.selectedTrainings.filter(id => id !== training.id);
                            setFormData(prev => ({ ...prev, selectedTrainings: newTrainings }));
                          }}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <p className="text-sm font-medium text-gray-900">{training.title}</p>
                          <p className="text-sm font-medium text-gray-900">{formatCurrency(training.price)}</p>
                        </div>
                        <p className="text-sm text-gray-500">{training.description}</p>
                        <p className="text-sm text-gray-500">Duration: {training.duration_days} days</p>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between text-lg font-medium">
                  <span>Total:</span>
                  <span>{formatCurrency(calculateTotal())}</span>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-between pt-6">
            {currentStep > 1 && (
              <button
                type="button"
                onClick={() => setCurrentStep(currentStep - 1)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Previous
              </button>
            )}
            <button
              type={currentStep === 4 ? 'submit' : 'button'}
              onClick={() => currentStep < 4 && canMoveToStep(currentStep + 1) && setCurrentStep(currentStep + 1)}
              disabled={currentStep === 4 && loading}
              className={`ml-auto px-4 py-2 text-sm font-medium text-white rounded-md ${
                loading ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {currentStep === 4 ? (
                loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  'Create Quotation'
                )
              ) : (
                'Next'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}