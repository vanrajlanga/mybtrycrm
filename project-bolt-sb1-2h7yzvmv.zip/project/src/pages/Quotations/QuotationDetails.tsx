import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Battery, Download, Send, ArrowLeft, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import type { Quotation } from '../../types';
import { formatCurrency } from '../../lib/utils';
import html2pdf from 'html-to-pdf-js';

export default function QuotationDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [quotation, setQuotation] = useState<Quotation | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    fetchQuotationDetails();
  }, [id]);

  async function fetchQuotationDetails() {
    try {
      // First, fetch the quotation with its service product details
      const { data: quotationData, error: quotationError } = await supabase
        .from('quotations')
        .select(`
          *,
          service_product:service_product_id (
            id,
            title,
            description,
            price,
            features:service_product_features (
              id,
              title,
              description
            ),
            services:service_product_trainings (
              id,
              title,
              description,
              duration_days,
              price
            ),
            warranties:service_product_warranties (
              id,
              title,
              description,
              duration_months,
              price
            ),
            benefits:service_product_benefits (
              id,
              title,
              description
            )
          )
        `)
        .eq('id', id)
        .single();

      if (quotationError) throw quotationError;
      setQuotation(quotationData);
    } catch (error: any) {
      console.error('Error fetching quotation:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  }

  const handleExportPDF = async () => {
    if (!quotation) return;

    try {
      setActionLoading(true);
      const element = document.getElementById('quotation-content');
      if (!element) return;

      const pdf = await html2pdf()
        .set({
          margin: 10,
          filename: `quotation-${quotation.id}.pdf`,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2, logging: false },
          jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        })
        .from(element)
        .save();

    } catch (error) {
      console.error('Error exporting PDF:', error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleSendQuotation = async () => {
    if (!quotation) return;

    try {
      setActionLoading(true);
      const { error } = await supabase
        .from('quotations')
        .update({ status: 'sent' })
        .eq('id', quotation.id);

      if (error) throw error;
      await fetchQuotationDetails();
    } catch (error: any) {
      console.error('Error sending quotation:', error);
      setError(error.message);
    } finally {
      setActionLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!quotation) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-lg font-medium text-gray-900">Quotation not found</h3>
        <p className="mt-1 text-sm text-gray-500">This quotation may have been deleted or doesn't exist.</p>
        <button
          onClick={() => navigate('/quotations')}
          className="mt-6 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Quotations
        </button>
      </div>
    );
  }

  const serviceProduct = quotation.service_product;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Battery className="h-8 w-8 text-blue-600 mr-3" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Quotation Details</h2>
            <p className="mt-1 text-sm text-gray-600">Quotation ID: {quotation.id}</p>
          </div>
        </div>
        <div className="flex gap-4">
          <button
            onClick={() => navigate('/quotations')}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to List
          </button>
          <button
            onClick={handleExportPDF}
            disabled={actionLoading}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
          >
            <Download className="h-5 w-5 mr-2" />
            Export PDF
          </button>
          {quotation.status === 'draft' && (
            <button
              onClick={handleSendQuotation}
              disabled={actionLoading}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
            >
              <Send className="h-5 w-5 mr-2" />
              Send Quotation
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="rounded-md bg-red-50 p-4">
          <div className="flex">
            <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        </div>
      )}

      <div id="quotation-content" className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <h3 className="text-lg font-medium text-gray-900">Project Details</h3>
              <div className="mt-2 text-sm text-gray-600">
                <p><span className="font-medium">Project Name:</span> {quotation.project_name}</p>
                <p><span className="font-medium">Description:</span> {quotation.project_description}</p>
                <p><span className="font-medium">Editor:</span> {quotation.editor_name}</p>
                <p><span className="font-medium">Planning Office:</span> {quotation.planning_office}</p>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-medium text-gray-900">Customer Details</h3>
              <div className="mt-2 text-sm text-gray-600">
                <p><span className="font-medium">Name:</span> {quotation.customer_name}</p>
                <p><span className="font-medium">City:</span> {quotation.customer_city}</p>
                <p><span className="font-medium">Address:</span> {quotation.customer_address}</p>
                <p><span className="font-medium">Email:</span> {quotation.customer_email}</p>
                <p><span className="font-medium">Phone:</span> {quotation.customer_phone}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
          <h3 className="text-lg font-medium text-gray-900">Product Details</h3>
          <div className="mt-2 text-sm text-gray-600">
            <p><span className="font-medium">Product Type:</span> {quotation.product_type}</p>
            <p><span className="font-medium">Total Price:</span> {formatCurrency(quotation.total_price)}</p>
            <p><span className="font-medium">Status:</span> 
              <span className={`ml-2 px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                quotation.status === 'draft' ? 'bg-gray-100 text-gray-800' :
                quotation.status === 'sent' ? 'bg-blue-100 text-blue-800' :
                quotation.status === 'accepted' ? 'bg-green-100 text-green-800' :
                'bg-red-100 text-red-800'
              }`}>
                {quotation.status.charAt(0).toUpperCase() + quotation.status.slice(1)}
              </span>
            </p>
          </div>
        </div>

        {serviceProduct && (
          <>
            <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Selected Features</h3>
              <div className="space-y-4">
                {quotation.selected_features?.map((featureId, index) => {
                  const feature = serviceProduct.features?.find(f => f.id === featureId);
                  if (!feature) return null;
                  return (
                    <div key={index} className="border rounded-lg p-4">
                      <h4 className="font-medium text-gray-900">{feature.title}</h4>
                      <p className="mt-1 text-sm text-gray-600">{feature.description}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Selected Services</h3>
              <div className="space-y-4">
                {quotation.selected_services?.map((serviceId, index) => {
                  const service = serviceProduct.services?.find(s => s.id === serviceId);
                  if (!service) return null;
                  return (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex justify-between">
                        <h4 className="font-medium text-gray-900">{service.title}</h4>
                        <p className="text-gray-900">{formatCurrency(service.price)}</p>
                      </div>
                      <p className="mt-1 text-sm text-gray-600">{service.description}</p>
                      <p className="mt-1 text-sm text-gray-500">Duration: {service.duration_days} days</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {quotation.selected_warranty && (
              <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">Selected Warranty</h3>
                {(() => {
                  const warranty = serviceProduct.warranties?.find(w => w.id === quotation.selected_warranty);
                  if (!warranty) return null;
                  return (
                    <div className="border rounded-lg p-4">
                      <div className="flex justify-between">
                        <h4 className="font-medium text-gray-900">{warranty.title}</h4>
                        <p className="text-gray-900">{formatCurrency(warranty.price)}</p>
                      </div>
                      <p className="mt-1 text-sm text-gray-600">{warranty.description}</p>
                      <p className="mt-1 text-sm text-gray-500">Duration: {warranty.duration_months} months</p>
                    </div>
                  );
                })()}
              </div>
            )}

            <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Selected Benefits</h3>
              <div className="space-y-4">
                {quotation.selected_benefits?.map((benefitId, index) => {
                  const benefit = serviceProduct.benefits?.find(b => b.id === benefitId);
                  if (!benefit) return null;
                  return (
                    <div key={index} className="border rounded-lg p-4">
                      <h4 className="font-medium text-gray-900">{benefit.title}</h4>
                      <p className="mt-1 text-sm text-gray-600">{benefit.description}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </>
        )}

        <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
          <div className="flex justify-between text-lg font-medium text-gray-900">
            <span>Total Price:</span>
            <span>{formatCurrency(quotation.total_price)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}