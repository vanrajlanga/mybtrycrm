import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Battery, CheckCircle, XCircle, ArrowLeft, Package } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import type { Order, AddonOption } from '../../types';
import { formatCurrency } from '../../lib/utils';
import LayoutViewer from '../../components/OrderDetails/LayoutViewer';

export default function OrderDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [order, setOrder] = useState<Order | null>(null);
  const [addons, setAddons] = useState<AddonOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    fetchOrderDetails();
  }, [id]);

  async function fetchOrderDetails() {
    try {
      const [orderResult, addonsResult] = await Promise.all([
        supabase
          .from('orders')
          .select('*')
          .eq('id', id)
          .single(),
        supabase
          .from('order_addons')
          .select(`
            addon_id,
            addon_options (
              id,
              name,
              description,
              price,
              addon_categories (
                name
              )
            )
          `)
          .eq('order_id', id)
      ]);

      if (orderResult.error) throw orderResult.error;
      if (addonsResult.error) throw addonsResult.error;

      setOrder(orderResult.data);
      setAddons(addonsResult.data.map(item => item.addon_options));
    } catch (error) {
      console.error('Error fetching order details:', error);
    } finally {
      setLoading(false);
    }
  }

  async function handleOrderAction(newStatus: 'pending' | 'completed') {
    if (!order) return;
    
    setActionLoading(true);
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', order.id);

      if (error) throw error;
      
      await fetchOrderDetails();
    } catch (error) {
      console.error(`Error updating order status to ${newStatus}:`, error);
    } finally {
      setActionLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="text-center py-12">
        <h3 className="text-lg font-medium text-gray-900">Order not found</h3>
        <button
          onClick={() => navigate('/dashboard/orders/history')}
          className="mt-4 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Orders
        </button>
      </div>
    );
  }

  const selectedLayout = {
    id: order.technical_specs.selectedLayout || 1,
    name: 'Selected Layout',
    pattern: order.technical_specs.layoutPattern || 'linear',
    rows: order.technical_specs.layoutRows || 1,
    cols: order.technical_specs.layoutCols || order.quantity,
    spacing: {
      betweenContainers: order.technical_specs.spacing?.betweenContainers || 1.0,
      containerToPcs: order.technical_specs.spacing?.containerToPcs || 6.058
    }
  } as const;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Battery className="h-8 w-8 text-blue-600 mr-3" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Order Details</h2>
            <p className="mt-1 text-sm text-gray-600">Order ID: {order.id}</p>
          </div>
        </div>
        <button
          onClick={() => navigate('/dashboard/orders/history')}
          className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Orders
        </button>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              {order.product_type} Battery System
            </h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Created on {new Date(order.created_at).toLocaleDateString()}
            </p>
          </div>
          <span className={`px-3 py-1 rounded-full text-sm font-medium
            ${order.status === 'draft' ? 'bg-gray-100 text-gray-800' :
              order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
              order.status === 'completed' ? 'bg-green-100 text-green-800' :
              'bg-red-100 text-red-800'}`}
          >
            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
          </span>
        </div>

        <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
          <dl className="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-gray-500">Power Required</dt>
              <dd className="mt-1 text-sm text-gray-900">{order.technical_specs.powerRequired} kW</dd>
            </div>
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-gray-500">Number of Units</dt>
              <dd className="mt-1 text-sm text-gray-900">{order.quantity}</dd>
            </div>
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-gray-500">Room Dimensions</dt>
              <dd className="mt-1 text-sm text-gray-900">
                {order.technical_specs.dimensions.length}m × {order.technical_specs.dimensions.width}m
              </dd>
            </div>
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-gray-500">Region</dt>
              <dd className="mt-1 text-sm text-gray-900">{order.technical_specs.region}</dd>
            </div>
            
            {order.technical_specs.selectedBlocks && order.technical_specs.selectedBlocks.length > 0 && (
              <div className="sm:col-span-2">
                <dt className="text-sm font-medium text-gray-500">Selected Blocks</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  <ul className="border rounded-md divide-y divide-gray-200">
                    {order.technical_specs.selectedBlocks.map((block, index) => (
                      <li key={index} className="px-4 py-3">
                        Block {block.id}: {block.power}kW / {block.capacity}kWh ({block.containers} containers)
                      </li>
                    ))}
                  </ul>
                </dd>
              </div>
            )}

            <div className="sm:col-span-2">
              <dt className="text-sm font-medium text-gray-500 mb-4">Layout Configuration</dt>
              <dd className="mt-1">
                <div className="mb-4 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-900">Selected Layout Details</h4>
                  <div className="mt-2 space-y-2 text-sm text-gray-600">
                    <p>Pattern: {selectedLayout.pattern}</p>
                    <p>Rows: {selectedLayout.rows}</p>
                    <p>Columns: {selectedLayout.cols}</p>
                    <p>Container Spacing: {selectedLayout.spacing.betweenContainers}m</p>
                    <p>PCS Spacing: {selectedLayout.spacing.containerToPcs}m</p>
                  </div>
                </div>
                <LayoutViewer
                  layout={selectedLayout}
                  roomDimensions={order.technical_specs.dimensions}
                  batteryType={order.product_type}
                  blocks={order.technical_specs.selectedBlocks || []}
                />
              </dd>
            </div>

            {addons.length > 0 && (
              <div className="sm:col-span-2">
                <dt className="text-sm font-medium text-gray-500">Selected Add-ons</dt>
                <dd className="mt-1">
                  <ul className="border rounded-md divide-y divide-gray-200">
                    {addons.map((addon) => (
                      <li key={addon.id} className="px-4 py-3">
                        <div className="flex justify-between">
                          <div>
                            <p className="text-sm font-medium text-gray-900">{addon.name}</p>
                            {addon.description && (
                              <p className="text-sm text-gray-500">{addon.description}</p>
                            )}
                          </div>
                          <p className="text-sm font-medium text-gray-900">
                            {addon.price > 0 ? formatCurrency(addon.price) : 'Included'}
                          </p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </dd>
              </div>
            )}
          </dl>
        </div>

        {(order.status === 'draft' || order.status === 'pending') && (
          <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
            <div className="flex justify-end space-x-3">
              {order.status === 'draft' && (
                <>
                  <button
                    onClick={() => navigate(`/dashboard/orders/${order.id}/edit`)}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                  >
                    Edit Order
                  </button>
                  <button
                    onClick={() => handleOrderAction('pending')}
                    disabled={actionLoading}
                    className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {actionLoading ? (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    ) : (
                      <>
                        <CheckCircle className="h-5 w-5 mr-2" />
                        Place Order
                      </>
                    )}
                  </button>
                </>
              )}
              {order.status === 'pending' && (
                <button
                  onClick={() => handleOrderAction('completed')}
                  disabled={actionLoading}
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  {actionLoading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <CheckCircle className="h-5 w-5 mr-2" />
                      Complete Order
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}