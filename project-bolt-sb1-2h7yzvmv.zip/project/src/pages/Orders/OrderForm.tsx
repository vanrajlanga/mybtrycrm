import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Battery, Plus, AlertCircle } from 'lucide-react';
import { supabase, handleSupabaseError } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import type { BatteryType, LegoBlock, TechnicalSpecs } from '../../types';
import { BATTERY_TYPES, REGIONS, UNIT_DIMENSIONS, DEFAULT_PCS_DIMENSIONS, DEFAULT_SPACING } from '../../components/OrderForm/constants';
import SPowerCalculator from '../../components/OrderForm/SPowerCalculator';
import UPowerCalculator from '../../components/OrderForm/UPowerCalculator';
import PCSSelector from '../../components/OrderForm/PCSSelector';
import LayoutPreview from '../../components/OrderForm/LayoutPreview';
import AddonsSelector from '../../components/OrderForm/AddonsSelector';

const STEPS = [
  { id: 1, name: 'Power Requirements' },
  { id: 2, name: 'Region & PCS' },
  { id: 3, name: 'BESS Features' },
  { id: 4, name: 'Room Layout' }
] as const;

export default function OrderForm() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedLayout, setSelectedLayout] = useState<number | null>(null);
  const [layoutDetails, setLayoutDetails] = useState<{
    pattern: 'linear' | 'grid' | 'perimeter' | 'diagonal' | 'zigzag';
    rows: number;
    cols: number;
    spacing: {
      betweenContainers: number;
      containerToPcs: number;
    };
  } | null>(null);
  
  const [formData, setFormData] = useState({
    batteryType: 'SPower' as BatteryType,
    powerRequired: '',
    powerUnit: 'kW' as 'kW' | 'MW',
    duration: '',
    durationUnit: 'kWh' as 'kWh' | 'MWh',
    capacityRequired: 0,
    containerCount: 1,
    selectedBlocks: [] as LegoBlock[],
    upowerUnits: 1,
    pcsSelection: '',
    features: [] as string[],
    addons: [] as string[],
    region: '',
    dimensions: {
      roomLength: '',
      roomWidth: ''
    },
    spacing: {
      betweenContainers: DEFAULT_SPACING.betweenContainers,
      containerToPcs: DEFAULT_SPACING.containerToPcs
    }
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const technicalSpecs: TechnicalSpecs = {
        batteryType: formData.batteryType,
        powerRequired: parseFloat(formData.powerRequired) || 0,
        powerUnit: formData.powerUnit,
        duration: parseFloat(formData.duration) || 0,
        durationUnit: formData.durationUnit,
        capacityRequired: formData.capacityRequired,
        containerCount: formData.containerCount,
        selectedBlocks: formData.selectedBlocks,
        upowerUnits: formData.upowerUnits,
        pcsSelection: formData.pcsSelection,
        features: formData.features,
        region: formData.region,
        dimensions: {
          length: parseFloat(formData.dimensions.roomLength) || 0,
          width: parseFloat(formData.dimensions.roomWidth) || 0
        },
        spacing: formData.spacing,
        selectedLayout: selectedLayout || 1,
        ...(layoutDetails && {
          layoutPattern: layoutDetails.pattern,
          layoutRows: layoutDetails.rows,
          layoutCols: layoutDetails.cols,
          layoutSpacing: layoutDetails.spacing
        })
      };

      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert([
          {
            sales_person_id: user?.id,
            status: 'draft',
            product_type: formData.batteryType,
            quantity: formData.batteryType === 'SPower' 
              ? formData.selectedBlocks.reduce((sum, block) => sum + block.containers, 0)
              : formData.upowerUnits,
            technical_specs: technicalSpecs,
          },
        ])
        .select()
        .single();

      if (orderError) throw orderError;

      if (formData.addons.length > 0) {
        const { error: addonsError } = await supabase
          .from('order_addons')
          .insert(
            formData.addons.map(addonId => ({
              order_id: order.id,
              addon_id: addonId
            }))
          );

        if (addonsError) throw addonsError;
      }

      navigate(`/dashboard/orders/${order.id}`);
    } catch (error) {
      console.error('Error creating order:', error);
      setError(handleSupabaseError(error).message);
    } finally {
      setLoading(false);
    }
  };

  const handleSpacingChange = (type: 'betweenContainers' | 'containerToPcs', value: string) => {
    const numValue = parseFloat(value);
    if (!isNaN(numValue) && numValue >= 0) {
      setFormData(prev => ({
        ...prev,
        spacing: {
          ...prev.spacing,
          [type]: numValue
        }
      }));
    }
  };

  const handlePowerChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      powerRequired: value
    }));
  };

  const handleDimensionChange = (dimension: 'roomLength' | 'roomWidth', value: string) => {
    setFormData(prev => ({
      ...prev,
      dimensions: {
        ...prev.dimensions,
        [dimension]: value
      }
    }));
  };

  const getPowerValue = () => {
    const power = parseFloat(formData.powerRequired);
    return isNaN(power) ? 0 : power;
  };

  const getDimensionValue = (dimension: 'roomLength' | 'roomWidth') => {
    const value = parseFloat(formData.dimensions[dimension]);
    return isNaN(value) ? 0 : value;
  };

  const handleLayoutSelect = (layoutId: number, details: {
    pattern: 'linear' | 'grid' | 'perimeter' | 'diagonal' | 'zigzag';
    rows: number;
    cols: number;
    spacing: {
      betweenContainers: number;
      containerToPcs: number;
    };
  }) => {
    setSelectedLayout(layoutId);
    setLayoutDetails(details);
  };

  const canMoveToStep = (step: number) => {
    switch (step) {
      case 1:
        return true;
      case 2:
        return getPowerValue() > 0;
      case 3:
        return formData.region !== '' && formData.pcsSelection !== '';
      case 4:
        return formData.addons.length > 0;
      default:
        return false;
    }
  };

  const handleStepClick = (step: number) => {
    if (canMoveToStep(step)) {
      setCurrentStep(step);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center mb-6">
          <Battery className="h-8 w-8 text-blue-600 mr-3" />
          <h2 className="text-2xl font-bold text-gray-900">Create New Order</h2>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-md bg-red-50 border border-red-200">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          </div>
        )}

        <div className="mb-8">
          <div className="flex flex-wrap gap-4 mb-6">
            {STEPS.map((step) => (
              <button
                key={step.id}
                onClick={() => handleStepClick(step.id)}
                disabled={!canMoveToStep(step.id)}
                className={`
                  flex-1 px-4 py-2 text-sm font-medium rounded-md
                  ${currentStep === step.id
                    ? 'bg-blue-600 text-white'
                    : canMoveToStep(step.id)
                      ? 'bg-white text-blue-600 border border-blue-600 hover:bg-blue-50'
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }
                `}
              >
                {step.name}
              </button>
            ))}
          </div>

          <div className="relative pt-1">
            <div className="flex mb-2 items-center justify-between">
              <div>
                <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                  Step {currentStep} of {STEPS.length}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold inline-block text-blue-600">
                  {Math.round((currentStep / STEPS.length) * 100)}%
                </span>
              </div>
            </div>
            <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
              <div
                style={{ width: `${(currentStep / STEPS.length) * 100}%` }}
                className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600"
              ></div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {currentStep === 1 && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Battery Type
                </label>
                <select
                  value={formData.batteryType}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      batteryType: e.target.value as BatteryType,
                      selectedBlocks: [],
                      upowerUnits: 1,
                    })
                  }
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                >
                  {BATTERY_TYPES.map(type => (
                    <option key={type.id} value={type.id}>{type.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Required Power
                </label>
                <div className="flex space-x-2">
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={formData.powerRequired}
                    onChange={(e) => handlePowerChange(e.target.value)}
                    className="mt-1 block w-2/3 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  />
                  <select
                    value={formData.powerUnit}
                    onChange={(e) => setFormData(prev => ({ ...prev, powerUnit: e.target.value as 'kW' | 'MW' }))}
                    className="mt-1 block w-1/3 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  >
                    <option value="kW">kW</option>
                    <option value="MW">MW</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Duration
                </label>
                <div className="flex space-x-2">
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={formData.duration}
                    onChange={(e) => setFormData(prev => ({ ...prev, duration: e.target.value }))}
                    className="mt-1 block w-2/3 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  />
                  <select
                    value={formData.durationUnit}
                    onChange={(e) => setFormData(prev => ({ ...prev, durationUnit: e.target.value as 'kWh' | 'MWh' }))}
                    className="mt-1 block w-1/3 border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  >
                    <option value="kWh">kWh</option>
                    <option value="MWh">MWh</option>
                  </select>
                </div>
              </div>

              <div>
                {formData.batteryType === 'SPower' ? (
                  <SPowerCalculator
                    powerRequired={getPowerValue()}
                    powerUnit={formData.powerUnit}
                    onBlocksChange={(blocks) => setFormData(prev => ({
                      ...prev,
                      selectedBlocks: blocks,
                      containerCount: blocks.reduce((sum, block) => sum + block.containers, 0)
                    }))}
                  />
                ) : (
                  <UPowerCalculator
                    powerRequired={getPowerValue()}
                    powerUnit={formData.powerUnit}
                    onUnitsChange={(units) => setFormData(prev => ({
                      ...prev,
                      upowerUnits: units
                    }))}
                  />
                )}
              </div>

              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  disabled={getPowerValue() <= 0}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Next: Region & PCS
                </button>
              </div>
            </>
          )}

          {currentStep === 2 && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Region
                </label>
                <select
                  value={formData.region}
                  onChange={(e) =>
                    setFormData(prev => ({ ...prev, region: e.target.value }))
                  }
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                >
                  <option value="">Select Region</option>
                  {REGIONS.map(region => (
                    <option key={region.id} value={region.id}>{region.name}</option>
                  ))}
                </select>
              </div>

              {formData.region && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    PCS Selection
                  </label>
                  <PCSSelector
                    region={formData.region}
                    value={formData.pcsSelection}
                    onChange={(value) => setFormData(prev => ({ ...prev, pcsSelection: value }))}
                  />
                </div>
              )}

              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  disabled={!formData.pcsSelection}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Next: BESS Features
                </button>
              </div>
            </>
          )}

          {currentStep === 3 && (
            <>
              <AddonsSelector
                selectedAddons={formData.addons}
                onAddonsChange={(addons) => setFormData(prev => ({ ...prev, addons }))}
              />

              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(4)}
                  disabled={formData.addons.length === 0}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  Next: Room Layout
                </button>
              </div>
            </>
          )}

          {currentStep === 4 && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Room Length (m)
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="0.1"
                    value={formData.dimensions.roomLength}
                    onChange={(e) => handleDimensionChange('roomLength', e.target.value)}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Room Width (m)
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="0.1"
                    value={formData.dimensions.roomWidth}
                    onChange={(e) => handleDimensionChange('roomWidth', e.target.value)}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Space Between Containers (m)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    value={formData.spacing.betweenContainers}
                    onChange={(e) => handleSpacingChange('betweenContainers', e.target.value)}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Space Between Container and PCS (m)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    value={formData.spacing.containerToPcs}
                    onChange={(e) => handleSpacingChange('containerToPcs', e.target.value)}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  />
                </div>
              </div>

              {getDimensionValue('roomLength') > 0 && getDimensionValue('roomWidth') > 0 && (
                <div className="space-y-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="text-sm font-medium text-gray-900 mb-2">Room Configuration</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                      <div>
                        <span className="font-medium">Dimensions:</span> {getDimensionValue('roomLength')}m × {getDimensionValue('roomWidth')}m
                      </div>
                      <div>
                        <span className="font-medium">Total Units:</span> {formData.containerCount}
                      </div>
                      <div>
                        <span className="font-medium">Container Spacing:</span> {formData.spacing.betweenContainers}m
                      </div>
                      <div>
                        <span className="font-medium">PCS Spacing:</span> {formData.spacing.containerToPcs}m
                      </div>
                    </div>
                  </div>

                  <LayoutPreview
                    roomLength={getDimensionValue('roomLength')}
                    roomWidth={getDimensionValue('roomWidth')}
                    unitLength={UNIT_DIMENSIONS[formData.batteryType].length}
                    unitWidth={UNIT_DIMENSIONS[formData.batteryType].width}
                    pcsLength={DEFAULT_PCS_DIMENSIONS.length}
                    pcsWidth={DEFAULT_PCS_DIMENSIONS.width}
                    spacing={formData.spacing}
                    blocks={formData.batteryType === 'SPower' ? formData.selectedBlocks : [
                      { id: 1, power: 10, capacity: 40, containers: formData.upowerUnits }
                    ]}
                    onLayoutSelect={handleLayoutSelect}
                  />
                </div>
              )}

              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Previous
                </button>
                <button
                  type="submit"
                  disabled={loading || !selectedLayout || getDimensionValue('roomLength') <= 0 || getDimensionValue('roomWidth') <= 0}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-300 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  ) : (
                    <>
                      <Plus className="h-5 w-5 mr-2" />
                      Create Order
                    </>
                  )}
                </button>
              </div>
            </>
          )}
        </form>
      </div>
    </div>
  );
}