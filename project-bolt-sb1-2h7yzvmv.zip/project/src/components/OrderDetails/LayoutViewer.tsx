import React from 'react';
import type { Block } from '../../types';

interface LayoutViewerProps {
  layout: {
    id: number;
    name: string;
    pattern: string;
    rows: number;
    cols: number;
    spacing: {
      betweenContainers: number;
      containerToPcs: number;
    };
  };
  roomDimensions: {
    length: number;
    width: number;
  };
  batteryType: string;
  blocks: Block[];
}

const LayoutViewer: React.FC<LayoutViewerProps> = ({
  layout,
  roomDimensions,
  batteryType,
  blocks
}) => {
  return (
    <div className="border rounded-lg p-4 bg-white">
      <div className="relative w-full" style={{ paddingBottom: '56.25%' }}>
        <div className="absolute inset-0 flex items-center justify-center bg-gray-50 rounded">
          <div className="text-center">
            <p className="text-sm text-gray-500 mb-2">
              Room Size: {roomDimensions.length}m × {roomDimensions.width}m
            </p>
            <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
              <div>
                <p>Pattern: {layout.pattern}</p>
                <p>Rows: {layout.rows}</p>
              </div>
              <div>
                <p>Columns: {layout.cols}</p>
                <p>Battery Type: {batteryType}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LayoutViewer;