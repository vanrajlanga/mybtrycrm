import { useEffect, useState } from 'react';
import type { PCSProduct } from '../../types';
import { supabase } from '../../lib/supabase';
import { formatCurrency } from '../../lib/utils';

interface PCSSelectorProps {
  region: string;
  value: string;
  onChange: (value: string) => void;
}

export default function PCSSelector({ region, value, onChange }: PCSSelectorProps) {
  const [loading, setLoading] = useState(false);
  const [pcsProducts, setPcsProducts] = useState<PCSProduct[]>([]);

  useEffect(() => {
    async function loadPCSProducts() {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('pcs_products')
          .select('*')
          .order('manufacturer');

        if (error) throw error;
        setPcsProducts(data || []);
      } catch (error) {
        console.error('Error loading PCS products:', error);
      } finally {
        setLoading(false);
      }
    }

    loadPCSProducts();
  }, []);

  if (loading) {
    return <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>;
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4">
        {pcsProducts.map((pcs) => (
          <label
            key={pcs.id}
            className={`
              relative flex cursor-pointer rounded-lg border p-4 hover:bg-gray-50
              ${value === pcs.id ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}
            `}
          >
            <input
              type="radio"
              name="pcs-selection"
              value={pcs.id}
              checked={value === pcs.id}
              onChange={(e) => onChange(e.target.value)}
              className="sr-only"
            />
            <div className="flex w-full items-center justify-between">
              <div className="flex items-center">
                <div className="text-sm">
                  <p className="font-medium text-gray-900">
                    {pcs.manufacturer} - {pcs.name}
                  </p>
                  <ul className="mt-1 flex space-x-4 text-gray-500">
                    {pcs.warranty && <li>Warranty: {pcs.warranty} months</li>}
                    {pcs.price && <li>Price: {formatCurrency(pcs.price)}</li>}
                    {pcs.specifications?.voltage && <li>Voltage: {pcs.specifications.voltage}V</li>}
                    {pcs.specifications?.current && <li>Current: {pcs.specifications.current}A</li>}
                  </ul>
                </div>
              </div>
              <div className={`h-5 w-5 rounded-full border flex items-center justify-center
                ${value === pcs.id ? 'border-blue-500 bg-blue-500' : 'border-gray-300'}
              `}>
                {value === pcs.id && (
                  <div className="h-2.5 w-2.5 rounded-full bg-white"></div>
                )}
              </div>
            </div>
          </label>
        ))}
      </div>

      {pcsProducts.length === 0 && (
        <p className="text-gray-500 italic">No PCS products available</p>
      )}
    </div>
  );
}