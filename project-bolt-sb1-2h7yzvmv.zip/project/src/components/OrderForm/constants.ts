// Battery type options
export const BATTERY_TYPES = [
  { id: 'SPower', name: 'SPower Battery' },
  { id: 'UPower', name: 'UPower Battery' }
] as const;

// Region options
export const REGIONS = [
  { id: 'europe', name: 'Europe' },
  { id: 'namerica', name: 'North America' },
  { id: 'asia', name: 'Asia' }
] as const;

// SPower building blocks configuration
export const SPOWER_BLOCKS = [
  { id: 1, power: 60, capacity: 240, containers: 1 },
  { id: 2, power: 180, capacity: 720, containers: 3 },
  { id: 3, power: 360, capacity: 1440, containers: 6 },
  { id: 4, power: 540, capacity: 2160, containers: 9 }
] as const;

// Standard unit dimensions for each battery type (in meters)
export const UNIT_DIMENSIONS = {
  // SPower container dimensions: 20ft container
  SPower: {
    length: 2.0,    // Wider for better visibility
    width: 1.2,     // Wider for better visibility
    height: 6.058   // Original length used as height for taller units
  },
  // UPower container dimensions: 10ft container
  UPower: {
    length: 1.0,    // Wider for better visibility
    width: 0.6,     // Wider for better visibility
    height: 1.775   // Original length
  }
} as const;

// Default PCS dimensions (using container size as default)
export const DEFAULT_PCS_DIMENSIONS = {
  length: 2.0,    // Same as SPower unit length
  width: 1.2,     // Same as SPower unit width
  height: 6.058   // Same as SPower unit height
} as const;

// Layout patterns for different arrangements
export const LAYOUT_PATTERNS = [
  {
    id: 'layout-a',
    name: 'Layout A',
    description: '36 units with 6 PCS distributed in 6 sections',
    unitRange: { min: 36, max: 36 },
    pcsRange: { min: 6, max: 6 }
  },
  {
    id: 'layout-b',
    name: 'Layout B',
    description: '36 units with 6 PCS in 4 sections',
    unitRange: { min: 36, max: 36 },
    pcsRange: { min: 6, max: 6 }
  },
  {
    id: 'layout-c',
    name: 'Layout C',
    description: '36 units with 6 PCS in 3 rows',
    unitRange: { min: 36, max: 36 },
    pcsRange: { min: 6, max: 6 }
  }
] as const;

// Default spacing values (in meters)
export const SPACING_REQUIREMENTS = {
  SPower: {
    length_spacing: 0.8,    // Increased spacing between units
    width_spacing: 0.8,     // Increased spacing between rows
    pcs_spacing: 0.8,       // Spacing from PCS
    unit_arrangement: {
      pattern: 'grid',
      rows: 2,
      cols: 3
    }
  },
  UPower: {
    front_spacing: 0.8,
    end_spacing: 0.8,      // Increased end spacing
    between_rows: 0.8,     // Increased row spacing
    pcs_spacing: 0.8,      // Spacing from PCS
    unit_arrangement: {
      pattern: 'grid',
      rows: 2,
      cols: 3
    }
  }
} as const;

// Default spacing values for initial layout
export const DEFAULT_SPACING = {
  betweenContainers: 0.5,  // 50cm between containers
  containerToPcs: 0.8      // 80cm between container and PCS
} as const;