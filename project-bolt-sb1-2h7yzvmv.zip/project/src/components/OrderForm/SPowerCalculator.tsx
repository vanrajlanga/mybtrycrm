import { useEffect, useState } from 'react';
import type { LegoBlock } from '../../types';
import { SPOWER_BLOCKS } from './constants';
import { calculateTotalPower, calculateTotalCapacity, convertPowerValue } from '../../lib/utils';

interface SPowerCalculatorProps {
  powerRequired: number;
  powerUnit: 'kW' | 'MW';
  onBlocksChange: (blocks: LegoBlock[]) => void;
}

export default function SPowerCalculator({ powerRequired, powerUnit, onBlocksChange }: SPowerCalculatorProps) {
  const [selectedBlocks, setSelectedBlocks] = useState<LegoBlock[]>([]);

  useEffect(() => {
    if (powerRequired <= 0) {
      setSelectedBlocks([]);
      onBlocksChange([]);
      return;
    }

    // Convert to kW if needed
    const powerInKW = convertPowerValue(powerRequired, powerUnit, 'kW');
    
    const blocks: LegoBlock[] = [];
    let remainingPower = powerInKW;

    // Start with largest blocks first
    for (const block of [...SPOWER_BLOCKS].reverse()) {
      while (remainingPower >= block.power) {
        blocks.push(block);
        remainingPower -= block.power;
      }
    }

    // If there's remaining power, add one more block that can cover it
    if (remainingPower > 0) {
      for (const block of SPOWER_BLOCKS) {
        if (block.power >= remainingPower) {
          blocks.push(block);
          break;
        }
      }
    }

    setSelectedBlocks(blocks);
    onBlocksChange(blocks);
  }, [powerRequired, powerUnit]); // Depend on both powerRequired and powerUnit

  const totalPower = calculateTotalPower(selectedBlocks);
  const totalCapacity = calculateTotalCapacity(selectedBlocks);
  const totalContainers = selectedBlocks.reduce((sum, block) => sum + block.containers, 0);

  return (
    <div className="space-y-4">
      <div className="rounded-lg border border-gray-200 p-4">
        <h4 className="font-medium text-gray-900">Selected Configuration</h4>
        <div className="mt-2 space-y-2">
          <p className="text-sm text-gray-600">
            Total Power: {powerUnit === 'MW' ? (totalPower / 1000).toFixed(2) : totalPower}{powerUnit}
          </p>
          <p className="text-sm text-gray-600">
            Total Capacity: {totalCapacity}kWh
          </p>
          <p className="text-sm text-gray-600">
            Total Containers: {totalContainers}
          </p>
        </div>
      </div>

      <div className="rounded-lg border border-gray-200 p-4">
        <h4 className="font-medium text-gray-900">Selected Blocks</h4>
        <div className="mt-2 space-y-2">
          {selectedBlocks.map((block, index) => (
            <div key={index} className="text-sm text-gray-600">
              Block {block.id}: {block.power}kW / {block.capacity}kWh ({block.containers} containers)
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}