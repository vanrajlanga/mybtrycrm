import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import type { AddonCategory, AddonOption } from '../../types';
import { formatCurrency } from '../../lib/utils';

interface AddonsSelectorProps {
  selectedAddons: string[];
  onAddonsChange: (addons: string[]) => void;
}

export default function AddonsSelector({ selectedAddons, onAddonsChange }: AddonsSelectorProps) {
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState<AddonCategory[]>([]);
  const [options, setOptions] = useState<AddonOption[]>([]);

  useEffect(() => {
    loadAddons();
  }, []);

  async function loadAddons() {
    try {
      const [categoriesResult, optionsResult] = await Promise.all([
        supabase.from('addon_categories').select('*').order('name'),
        supabase.from('addon_options').select('*').order('name')
      ]);

      if (categoriesResult.error) throw categoriesResult.error;
      if (optionsResult.error) throw optionsResult.error;

      setCategories(categoriesResult.data || []);
      setOptions(optionsResult.data || []);
    } catch (error) {
      console.error('Error loading addons:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleOptionChange = (optionId: string) => {
    const newSelectedAddons = selectedAddons.includes(optionId)
      ? selectedAddons.filter(id => id !== optionId)
      : [...selectedAddons, optionId];
    onAddonsChange(newSelectedAddons);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const totalPrice = options
    .filter(option => selectedAddons.includes(option.id))
    .reduce((sum, option) => sum + option.price, 0);

  return (
    <div className="space-y-6">
      {categories.map(category => {
        const categoryOptions = options.filter(option => option.category_id === category.id);
        if (categoryOptions.length === 0) return null;

        return (
          <div key={category.id} className="border rounded-lg p-4">
            <h3 className="text-lg font-medium text-gray-900 mb-2">{category.name}</h3>
            {category.description && (
              <p className="text-sm text-gray-500 mb-4">{category.description}</p>
            )}
            <div className="space-y-2">
              {categoryOptions.map(option => (
                <label key={option.id} className="flex items-start space-x-3">
                  <div className="flex items-center h-5">
                    <input
                      type="checkbox"
                      checked={selectedAddons.includes(option.id)}
                      onChange={() => handleOptionChange(option.id)}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <p className="text-sm font-medium text-gray-900">{option.name}</p>
                      <p className="text-sm font-medium text-gray-900">
                        {option.price > 0 ? formatCurrency(option.price) : 'Included'}
                      </p>
                    </div>
                    {option.description && (
                      <p className="text-sm text-gray-500">{option.description}</p>
                    )}
                  </div>
                </label>
              ))}
            </div>
          </div>
        );
      })}

      {totalPrice > 0 && (
        <div className="border-t pt-4">
          <div className="flex justify-between text-lg font-medium">
            <span>Total Add-ons Cost:</span>
            <span>{formatCurrency(totalPrice)}</span>
          </div>
        </div>
      )}
    </div>
  );
}