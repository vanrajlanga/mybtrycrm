import { useEffect, useMemo } from 'react';
import { convertPowerValue } from '../../lib/utils';

interface UPowerCalculatorProps {
  powerRequired: number;
  powerUnit: 'kW' | 'MW';
  onUnitsChange: (units: number) => void;
}

export default function UPowerCalculator({ powerRequired, powerUnit, onUnitsChange }: UPowerCalculatorProps) {
  // Convert power to kW for calculations
  const powerInKW = convertPowerValue(powerRequired, powerUnit, 'kW');
  
  // Calculate units using useMemo to avoid unnecessary recalculations
  const units = useMemo(() => {
    if (powerInKW <= 0) return 0;
    return Math.min(Math.ceil(powerInKW / 10), 6); // Max 6 units
  }, [powerInKW]);

  // Update parent component when units change
  useEffect(() => {
    onUnitsChange(units);
  }, [units]); // Only depend on units, not onUnitsChange

  const totalPower = units * 10; // in kW
  const totalPowerFormatted = powerUnit === 'MW' ? (totalPower / 1000).toFixed(2) : totalPower;
  const totalCapacity = units * 40; // in kWh

  return (
    <div className="rounded-lg border border-gray-200 p-4">
      <h4 className="font-medium text-gray-900">UPower Configuration</h4>
      <div className="mt-2 space-y-2">
        <p className="text-sm text-gray-600">
          Number of Units: {units}
        </p>
        <p className="text-sm text-gray-600">
          Power per Unit: 10kW
        </p>
        <p className="text-sm text-gray-600">
          Capacity per Unit: 40kWh
        </p>
        <p className="text-sm text-gray-600 font-medium">
          Total Power: {totalPowerFormatted}{powerUnit}
        </p>
        <p className="text-sm text-gray-600 font-medium">
          Total Capacity: {totalCapacity}kWh
        </p>
      </div>
    </div>
  );
}