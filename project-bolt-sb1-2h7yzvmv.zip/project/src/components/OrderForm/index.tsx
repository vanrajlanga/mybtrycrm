import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Battery, Plus, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuthStore } from '../../store/authStore';
import type { BatteryType, LegoBlock, TechnicalSpecs } from '../../types';
import { BATTERY_TYPES, REGIONS } from './constants';
import SPowerCalculator from './SPowerCalculator';
import UPowerCalculator from './UPowerCalculator';
import PCSSelector from './PCSSelector';
import LayoutPreview from './LayoutPreview';
import AddonsSelector from './AddonsSelector';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

const STEPS = [
  { id: 1, name: 'Project Details' },
  { id: 2, name: 'Customer Details' },
  { id: 3, name: 'Power Requirements' },
  { id: 4, name: 'Region & PCS' },
  { id: 5, name: 'BESS Features' },
  { id: 6, name: 'Service Selection' },
  { id: 7, name: 'Room Layout' },
  { id: 8, name: 'Additional Options' }
] as const;

export default function OrderForm() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedLayout, setSelectedLayout] = useState<number | null>(null);
  const [layoutDetails, setLayoutDetails] = useState<{
    pattern: 'linear' | 'grid' | 'perimeter' | 'diagonal' | 'zigzag';
    rows: number;
    cols: number;
    spacing: {
      betweenContainers: number;
      containerToPcs: number;
    };
  } | null>(null);

  const [formData, setFormData] = useState({
    // Project Details
    projectName: '',
    projectDescription: '',
    editorName: '',
    planningOffice: '',
    quotationDate: new Date().toISOString().split('T')[0],

    // Customer Details
    customerName: '',
    customerEmail: '',
    customerPhone: '',
    customerCountry: '',
    customerCity: '',
    customerAddress: '',

    // Battery & Power Details
    batteryType: 'SPower' as BatteryType,
    powerRequired: '',
    powerUnit: 'kW' as 'kW' | 'MW',
    duration: '',
    durationUnit: 'kWh' as 'kWh' | 'MWh',
    capacityRequired: 0,
    containerCount: 1,
    selectedBlocks: [] as LegoBlock[],
    upowerUnits: 1,
    pcsSelection: '',
    features: [] as string[],
    addons: [] as string[],
    region: '',
    dimensions: {
      roomLength: '',
      roomWidth: ''
    },
    spacing: {
      betweenContainers: 0.8,
      containerToPcs: 0.8
    },

    // Service Selection
    selectedServices: [] as string[],
    selectedWarranty: '',
    selectedTrainings: [] as string[],
    selectedBenefits: [] as string[],
    selectedGuarantees: [] as string[],
    selectedStandards: [] as string[],
    selectedConfigurations: [] as string[]
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (currentStep < 8) {
      setCurrentStep(currentStep + 1);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const technicalSpecs: TechnicalSpecs = {
        batteryType: formData.batteryType,
        powerRequired: parseFloat(formData.powerRequired) || 0,
        powerUnit: formData.powerUnit,
        duration: parseFloat(formData.duration) || 0,
        durationUnit: formData.durationUnit,
        capacityRequired: formData.capacityRequired,
        containerCount: formData.containerCount,
        selectedBlocks: formData.selectedBlocks,
        upowerUnits: formData.upowerUnits,
        pcsSelection: formData.pcsSelection,
        features: formData.features,
        region: formData.region,
        dimensions: {
          length: parseFloat(formData.dimensions.roomLength) || 0,
          width: parseFloat(formData.dimensions.roomWidth) || 0
        },
        spacing: formData.spacing,
        selectedLayout: selectedLayout || 1,
        ...(layoutDetails && {
          layoutPattern: layoutDetails.pattern,
          layoutRows: layoutDetails.rows,
          layoutCols: layoutDetails.cols,
          layoutSpacing: layoutDetails.spacing
        })
      };

      // Create order
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert([
          {
            sales_person_id: user?.id,
            status: 'draft',
            product_type: formData.batteryType,
            quantity: formData.batteryType === 'SPower' 
              ? formData.selectedBlocks.reduce((sum, block) => sum + block.containers, 0)
              : formData.upowerUnits,
            technical_specs: technicalSpecs,
          },
        ])
        .select()
        .single();

      if (orderError) throw orderError;

      // Create quotation
      const { data: quotation, error: quotationError } = await supabase
        .from('quotations')
        .insert([
          {
            project_name: formData.projectName,
            project_description: formData.projectDescription,
            editor_name: formData.editorName,
            planning_office: formData.planningOffice,
            quotation_date: formData.quotationDate,
            customer_name: formData.customerName,
            customer_email: formData.customerEmail,
            customer_phone: formData.customerPhone,
            customer_country: formData.customerCountry,
            customer_city: formData.customerCity,
            customer_address: formData.customerAddress,
            product_type: formData.batteryType,
            selected_features: formData.features,
            selected_services: formData.selectedServices,
            selected_warranty: formData.selectedWarranty,
            selected_trainings: formData.selectedTrainings,
            selected_benefits: formData.selectedBenefits,
            selected_guarantees: formData.selectedGuarantees,
            selected_standards: formData.selectedStandards,
            selected_configurations: formData.selectedConfigurations,
            created_by: user?.id,
            status: 'draft'
          }
        ])
        .select()
        .single();

      if (quotationError) throw quotationError;

      if (formData.addons.length > 0) {
        const { error: addonsError } = await supabase
          .from('order_addons')
          .insert(
            formData.addons.map(addonId => ({
              order_id: order.id,
              addon_id: addonId
            }))
          );

        if (addonsError) throw addonsError;
      }

      // Generate PDF
      const element = document.getElementById('order-content');
      if (element) {
        const canvas = await html2canvas(element);
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4'
        });

        const imgWidth = 210; // A4 width in mm
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
        pdf.save(`quotation-${quotation.id}.pdf`);
      }

      navigate(`/dashboard/orders/${order.id}`);
    } catch (error: any) {
      console.error('Error creating order:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const canMoveToStep = (step: number) => {
    switch (step) {
      case 1:
        return true;
      case 2:
        return formData.projectName && formData.editorName && formData.planningOffice;
      case 3:
        return formData.customerName && formData.customerEmail && formData.customerPhone;
      case 4:
        return getPowerValue() > 0;
      case 5:
        return formData.region !== '' && formData.pcsSelection !== '';
      case 6:
        return formData.features.length > 0;
      case 7:
        return formData.selectedServices.length > 0;
      case 8:
        return getDimensionValue('roomLength') > 0 && getDimensionValue('roomWidth') > 0;
      default:
        return false;
    }
  };

  const handleStepClick = (step: number) => {
    if (step <= currentStep || canMoveToStep(step)) {
      setCurrentStep(step);
    }
  };

  const getPowerValue = () => {
    const power = parseFloat(formData.powerRequired);
    return isNaN(power) ? 0 : power;
  };

  const getDimensionValue = (dimension: 'roomLength' | 'roomWidth') => {
    const value = parseFloat(formData.dimensions[dimension]);
    return isNaN(value) ? 0 : value;
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center mb-6">
          <Battery className="h-8 w-8 text-blue-600 mr-3" />
          <h2 className="text-2xl font-bold text-gray-900">Create Order & Quotation</h2>
        </div>

        {error && (
          <div className="mb-6 p-4 rounded-md bg-red-50 border border-red-200">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
              <p className="text-sm text-red-600">{error}</p>
            </div>
          </div>
        )}

        <div className="mb-8">
          <div className="flex flex-wrap gap-4 mb-6">
            {STEPS.map((step) => (
              <button
                key={step.id}
                onClick={() => handleStepClick(step.id)}
                disabled={!canMoveToStep(step.id)}
                className={`
                  flex-1 px-4 py-2 text-sm font-medium rounded-md
                  ${currentStep === step.id
                    ? 'bg-blue-600 text-white'
                    : canMoveToStep(step.id)
                      ? 'bg-white text-blue-600 border border-blue-600 hover:bg-blue-50'
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }
                `}
              >
                {step.name}
              </button>
            ))}
          </div>

          <div className="relative pt-1">
            <div className="flex mb-2 items-center justify-between">
              <div>
                <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                  Step {currentStep} of {STEPS.length}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold inline-block text-blue-600">
                  {Math.round((currentStep / STEPS.length) * 100)}%
                </span>
              </div>
            </div>
            <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
              <div
                style={{ width: `${(currentStep / STEPS.length) * 100}%` }}
                className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600"
              ></div>
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Step 1: Project Details */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Project Name</label>
                <input
                  type="text"
                  value={formData.projectName}
                  onChange={(e) => setFormData(prev => ({ ...prev, projectName: e.target.value }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Project Description</label>
                <textarea
                  value={formData.projectDescription}
                  onChange={(e) => setFormData(prev => ({ ...prev, projectDescription: e.target.value }))}
                  rows={4}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Quotation Date</label>
                <input
                  type="date"
                  value={formData.quotationDate}
                  onChange={(e) => setFormData(prev => ({ ...prev, quotationDate: e.target.value }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Editor Name</label>
                  <input
                    type="text"
                    value={formData.editorName}
                    onChange={(e) => setFormData(prev => ({ ...prev, editorName: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Planning Office</label>
                  <input
                    type="text"
                    value={formData.planningOffice}
                    onChange={(e) => setFormData(prev => ({ ...prev, planningOffice: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Customer Details */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Customer Name</label>
                  <input
                    type="text"
                    value={formData.customerName}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerName: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Country</label>
                  <input
                    type="text"
                    value={formData.customerCountry}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerCountry: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">City</label>
                  <input
                    type="text"
                    value={formData.customerCity}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerCity: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Address</label>
                  <input
                    type="text"
                    value={formData.customerAddress}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerAddress: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    value={formData.customerEmail}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerEmail: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700">Phone</label>
                  <input
                    type="tel"
                    value={formData.customerPhone}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerPhone: e.target.value }))}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    required
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 3: Power Requirements */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Battery Type</label>
                <select
                  value={formData.batteryType}
                  onChange={(e) => setFormData(prev => ({
                    ...prev,
                    batteryType: e.target.value as BatteryType,
                    selectedBlocks: [],
                    upowerUnits: 1,
                  }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  required
                >
                  {BATTERY_TYPES.map(type => (
                    <option key={type.id} value={type.id}>{type.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Required Power</label>
                <div className="flex space-x-2">
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={formData.powerRequired}
                    onChange={(e) => handlePowerChange(e.target.value)}
                    className="mt-1 block w-2/3 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                  <select
                    value={formData.powerUnit}
                    onChange={(e) => setFormData(prev => ({ ...prev, powerUnit: e.target.value as 'kW' | 'MW' }))}
                    className="mt-1 block w-1/3 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  >
                    <option value="kW">kW</option>
                    <option value="MW">MW</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Duration</label>
                <div className="flex space-x-2">
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={formData.duration}
                    onChange={(e) => setFormData(prev => ({ ...prev, duration: e.target.value }))}
                    className="mt-1 block w-2/3 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                  <select
                    value={formData.durationUnit}
                    onChange={(e) => setFormData(prev => ({ ...prev, durationUnit: e.target.value as 'kWh' | 'MWh' }))}
                    className="mt-1 block w-1/3 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  >
                    <option value="kWh">kWh</option>
                    <option value="MWh">MWh</option>
                  </select>
                </div>
              </div>

              <div>
                {formData.batteryType === 'SPower' ? (
                  <SPowerCalculator
                    powerRequired={getPowerValue()}
                    powerUnit={formData.powerUnit}
                    onBlocksChange={(blocks) => setFormData(prev => ({
                      ...prev,
                      selectedBlocks: blocks,
                      containerCount: blocks.reduce((sum, block) => sum + block.containers, 0)
                    }))}
                  />
                ) : (
                  <UPowerCalculator
                    powerRequired={getPowerValue()}
                    powerUnit={formData.powerUnit}
                    onUnitsChange={(units) => setFormData(prev => ({
                      ...prev,
                      upowerUnits: units
                    }))}
                  />
                )}
              </div>
            </div>
          )}

          {/* Step 4: Region & PCS */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Region</label>
                <select
                  value={formData.region}
                  onChange={(e) => setFormData(prev => ({ ...prev, region: e.target.value }))}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  required
                >
                  <option value="">Select Region</option>
                  {REGIONS.map(region => (
                    <option key={region.id} value={region.id}>{region.name}</option>
                  ))}
                </select>
              </div>

              {formData.region && (
                <div>
                  <label className="block text-sm font-medium text-gray-700">PCS Selection</label>
                  <PCSSelector
                    region={formData.region}
                    value={formData.pcsSelection}
                    onChange={(value) => setFormData(prev => ({ ...prev, pcsSelection: value }))}
                  />
                </div>
              )}
            </div>
          )}

          {/* Step 5: BESS Features */}
          {currentStep === 5 && (
            <div className="space-y-6">
              <AddonsSelector
                selectedAddons={formData.addons}
                onAddonsChange={(addons) => setFormData(prev => ({ ...prev, addons }))}
              />
            </div>
          )}

          {/* Step 6: Service Selection */}
          {currentStep === 6 && (
            <div className="space-y-6">
              {/* Service selection components will be added here */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Available Services</h3>
                {/* Add service selection components */}
              </div>
            </div>
          )}

          {/* Step 7: Room Layout */}
          {currentStep === 7 && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Room Length (m)</label>
                  <input
                    type="number"
                    min="1"
                    step="0.1"
                    value={formData.dimensions.roomLength}
                    onChange={(e) => handleDimensionChange('roomLength', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Room Width (m)</label>
                  <input
                    type="number"
                    min="1"
                    step="0.1"
                    value={formData.dimensions.roomWidth}
                    onChange={(e) => handleDimensionChange('roomWidth', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Space Between Containers (m)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    value={formData.spacing.betweenContainers}
                    onChange={(e) => handleSpacingChange('betweenContainers', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Space Between Container and PCS (m)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.1"
                    value={formData.spacing.containerToPcs}
                    onChange={(e) => handleSpacingChange('containerToPcs', e.target.value)}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              </div>

              {getDimensionValue('roomLength') > 0 && getDimensionValue('roomWidth') > 0 && (
                <LayoutPreview
                  roomLength={getDimensionValue('roomLength')}
                  roomWidth={getDimensionValue('roomWidth')}
                  unitLength={2.0}
                  unitWidth={1.2}
                  unitHeight={6.058}
                  pcsLength={2.0}
                  pcsWidth={1.2}
                  pcsHeight={6.058}
                  spacing={formData.spacing}
                  blocks={formData.batteryType === 'SPower' ? formData.selectedBlocks : [
                    { id: 1, power: 10, capacity: 40, containers: formData.upowerUnits }
                  ]}
                  onLayoutSelect={handleLayoutSelect}
                />
              )}
            </div>
          )}

          {/* Step 8: Additional Options */}
          {currentStep === 8 && (
            <div className="space-y-6">
              {/* Additional options components will be added here */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Additional Options</h3>
                {/* Add additional options components */}
              </div>
            </div>
          )}

          <div className="flex justify-between pt-6">
            {currentStep > 1 && (
              <button
                type="button"
                onClick={() => setCurrentStep(currentStep - 1)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              >
                Previous
              </button>
            )}
            <button
              type={currentStep === 8 ? 'submit' : 'button'}
              onClick={() => currentStep < 8 && canMoveToStep(currentStep + 1) && setCurrentStep(currentStep + 1)}
              disabled={currentStep === 8 && loading}
              className={`ml-auto px-4 py-2 text-sm font-medium text-white rounded-md ${
                loading ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {currentStep === 8 ? (
                loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  'Create Order & Quotation'
                )
              ) : (
                'Next'
              )}
            </button>
          </div>
        </form>

        {/* Hidden div for PDF generation */}
        <div id="order-content" className="hidden">
          {/* Content for PDF will be rendered here */}
          {/* This will be populated with all the selected options and layout */}
        </div>
      </div>
    </div>
  );
}