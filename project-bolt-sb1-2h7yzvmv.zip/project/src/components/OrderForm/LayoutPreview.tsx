import { useState, useRef } from 'react';
import { Download } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';
import type { LegoBlock } from '../../types';

interface LayoutPreviewProps {
  roomLength: number;
  roomWidth: number;
  unitLength: number;
  unitWidth: number;
  unitHeight: number;
  pcsLength: number;
  pcsWidth: number;
  pcsHeight: number;
  spacing: {
    betweenContainers: number;
    containerToPcs: number;
  };
  blocks: LegoBlock[];
  onLayoutSelect: (layoutId: number, details: any) => void;
}

type ViewType = 'normal' | 'top' | 'side';
type LayoutType = 'layout-a' | 'layout-b' | 'layout-c';

export default function LayoutPreview({
  roomLength,
  roomWidth,
  unitLength,
  unitWidth,
  unitHeight,
  pcsLength,
  pcsWidth,
  pcsHeight,
  spacing,
  blocks,
  onLayoutSelect,
}: LayoutPreviewProps) {
  const [viewType, setViewType] = useState<ViewType>('normal');
  const [selectedLayout, setSelectedLayout] = useState<LayoutType>('layout-a');
  const layoutRef = useRef<HTMLDivElement>(null);

  const generateScaleMarkers = () => {
    const markers = [];
    const scaleStep = 5;
    const maxScale = Math.max(roomLength, roomWidth);
    const markerLength = 0.5;
    const fontSize = Math.min(roomLength, roomWidth) * 0.02;

    for (let i = 0; i <= roomLength; i += scaleStep) {
      markers.push(
        <g key={`h-${i}`}>
          <line
            x1={i}
            y1={-markerLength}
            x2={i}
            y2={0}
            stroke="#64748b"
            strokeWidth={0.1}
          />
          <text
            x={i}
            y={-markerLength * 2}
            textAnchor="middle"
            fill="#64748b"
            fontSize={fontSize}
          >
            {i}m
          </text>
        </g>
      );
    }

    for (let i = 0; i <= roomWidth; i += scaleStep) {
      markers.push(
        <g key={`v-${i}`}>
          <line
            x1={-markerLength}
            y1={i}
            x2={0}
            y2={i}
            stroke="#64748b"
            strokeWidth={0.1}
          />
          <text
            x={-markerLength * 3}
            y={i}
            dominantBaseline="middle"
            fill="#64748b"
            fontSize={fontSize}
          >
            {i}m
          </text>
        </g>
      );
    }

    return markers;
  };

  const drawDimensionLine = (x1: number, y1: number, x2: number, y2: number, label: string, offset: number = 1) => {
    const angle = Math.atan2(y2 - y1, x2 - x1);
    const length = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    const fontSize = Math.min(roomLength, roomWidth) * 0.02;

    return (
      <g>
        {/* Main dimension line */}
        <line
          x1={x1}
          y1={y1}
          x2={x2}
          y2={y2}
          stroke="#ef4444"
          strokeWidth={0.1}
          strokeDasharray="0.2 0.1"
        />
        
        {/* Arrows */}
        <line
          x1={x1}
          y1={y1}
          x2={x1 + Math.cos(angle + Math.PI/6) * 0.5}
          y2={y1 + Math.sin(angle + Math.PI/6) * 0.5}
          stroke="#ef4444"
          strokeWidth={0.1}
        />
        <line
          x1={x1}
          y1={y1}
          x2={x1 + Math.cos(angle - Math.PI/6) * 0.5}
          y2={y1 + Math.sin(angle - Math.PI/6) * 0.5}
          stroke="#ef4444"
          strokeWidth={0.1}
        />
        <line
          x1={x2}
          y1={y2}
          x2={x2 - Math.cos(angle + Math.PI/6) * 0.5}
          y2={y2 - Math.sin(angle + Math.PI/6) * 0.5}
          stroke="#ef4444"
          strokeWidth={0.1}
        />
        <line
          x1={x2}
          y1={y2}
          x2={x2 - Math.cos(angle - Math.PI/6) * 0.5}
          y2={y2 - Math.sin(angle - Math.PI/6) * 0.5}
          stroke="#ef4444"
          strokeWidth={0.1}
        />

        {/* Dimension text */}
        <text
          x={(x1 + x2) / 2}
          y={(y1 + y2) / 2 + offset}
          textAnchor="middle"
          fill="#ef4444"
          fontSize={fontSize}
        >
          {label}
        </text>
      </g>
    );
  };

  const calculateLayoutADimensions = () => {
    const leftSectionWidth = unitLength * 2 + spacing.betweenContainers;
    const pcsSpacing = spacing.containerToPcs * 2;
    const rightSectionWidth = unitLength * 4 + spacing.betweenContainers * 3;
    const totalWidth = leftSectionWidth + pcsLength + pcsSpacing + rightSectionWidth + pcsLength + spacing.containerToPcs;
    const totalHeight = unitWidth * 6 + spacing.betweenContainers * 5;

    return {
      totalWidth,
      totalHeight,
      leftSectionWidth,
      rightSectionWidth
    };
  };

  const calculateLayoutBDimensions = () => {
    const pcsSpacing = spacing.containerToPcs;
    const middleSectionWidth = 6 * (unitLength + spacing.betweenContainers) - spacing.betweenContainers;
    const rightSectionWidth = 3 * (unitLength + spacing.betweenContainers) - spacing.betweenContainers;
    const totalWidth = pcsLength + pcsSpacing + middleSectionWidth + pcsSpacing + pcsLength + pcsSpacing + rightSectionWidth;
    const totalHeight = unitWidth * 4 + spacing.betweenContainers * 3;

    return {
      totalWidth,
      totalHeight,
      middleSectionWidth,
      rightSectionWidth
    };
  };

  const calculateLayoutCDimensions = () => {
    const unitsPerRow = 12;
    const totalUnitsWidth = unitLength * unitsPerRow + spacing.betweenContainers * (unitsPerRow - 1);
    const totalWidth = totalUnitsWidth + 2 * (pcsLength + spacing.containerToPcs);
    const totalHeight = unitWidth * 3 + spacing.betweenContainers * 2;

    return {
      totalWidth,
      totalHeight,
      unitsWidth: totalUnitsWidth
    };
  };

  const renderDimensions = () => {
    let dimensions;
    let startX;
    let startY;

    switch (selectedLayout) {
      case 'layout-a':
        dimensions = calculateLayoutADimensions();
        startX = (roomLength - dimensions.totalWidth) / 2 - spacing.containerToPcs;
        startY = (roomWidth - dimensions.totalHeight) / 2;
        return (
          <>
            {/* Total width */}
            {drawDimensionLine(
              startX,
              startY - 2,
              startX + dimensions.totalWidth,
              startY - 2,
              `${dimensions.totalWidth.toFixed(1)}m`
            )}
            {/* Total height */}
            {drawDimensionLine(
              startX - 2,
              startY,
              startX - 2,
              startY + dimensions.totalHeight,
              `${dimensions.totalHeight.toFixed(1)}m`,
              -0.5
            )}
            {/* Left section */}
            {drawDimensionLine(
              startX,
              startY - 1,
              startX + dimensions.leftSectionWidth,
              startY - 1,
              `${dimensions.leftSectionWidth.toFixed(1)}m`
            )}
            {/* Right section */}
            {drawDimensionLine(
              startX + dimensions.totalWidth - dimensions.rightSectionWidth,
              startY - 1,
              startX + dimensions.totalWidth,
              startY - 1,
              `${dimensions.rightSectionWidth.toFixed(1)}m`
            )}
          </>
        );

      case 'layout-b':
        dimensions = calculateLayoutBDimensions();
        startX = (roomLength - dimensions.totalWidth) / 2;
        startY = (roomWidth - dimensions.totalHeight) / 2;
        return (
          <>
            {/* Total width */}
            {drawDimensionLine(
              startX,
              startY - 2,
              startX + dimensions.totalWidth,
              startY - 2,
              `${dimensions.totalWidth.toFixed(1)}m`
            )}
            {/* Total height */}
            {drawDimensionLine(
              startX - 2,
              startY,
              startX - 2,
              startY + dimensions.totalHeight,
              `${dimensions.totalHeight.toFixed(1)}m`,
              -0.5
            )}
            {/* Middle section */}
            {drawDimensionLine(
              startX + pcsLength + spacing.containerToPcs,
              startY - 1,
              startX + pcsLength + spacing.containerToPcs + dimensions.middleSectionWidth,
              startY - 1,
              `${dimensions.middleSectionWidth.toFixed(1)}m`
            )}
          </>
        );

      case 'layout-c':
        dimensions = calculateLayoutCDimensions();
        startX = (roomLength - dimensions.totalWidth) / 2;
        startY = (roomWidth - dimensions.totalHeight) / 2;
        return (
          <>
            {/* Total width */}
            {drawDimensionLine(
              startX,
              startY - 2,
              startX + dimensions.totalWidth,
              startY - 2,
              `${dimensions.totalWidth.toFixed(1)}m`
            )}
            {/* Total height */}
            {drawDimensionLine(
              startX - 2,
              startY,
              startX - 2,
              startY + dimensions.totalHeight,
              `${dimensions.totalHeight.toFixed(1)}m`,
              -0.5
            )}
            {/* Units width */}
            {drawDimensionLine(
              startX + pcsLength + spacing.containerToPcs,
              startY - 1,
              startX + pcsLength + spacing.containerToPcs + dimensions.unitsWidth,
              startY - 1,
              `${dimensions.unitsWidth.toFixed(1)}m`
            )}
          </>
        );

      default:
        return null;
    }
  };

  const calculateLayoutAUnitPositions = () => {
    const positions = [];
    
    // Adjust spacing for better positioning
    const leftSectionWidth = unitLength * 2 + spacing.betweenContainers;
    const pcsSpacing = spacing.containerToPcs * 2; // Reduced spacing
    const rightSectionWidth = unitLength * 4 + spacing.betweenContainers * 3;
    const totalWidth = leftSectionWidth + pcsLength + pcsSpacing + rightSectionWidth + pcsLength + spacing.containerToPcs;
    
    // Move everything slightly to the left
    const startX = (roomLength - totalWidth) / 2 - pcsSpacing;
    const startY = (roomWidth - (unitWidth * 6 + spacing.betweenContainers * 5)) / 2;

    // Left section units (1-12)
    for (let row = 0; row < 6; row++) {
      for (let col = 0; col < 2; col++) {
        positions.push({
          x: startX + col * (unitLength + spacing.betweenContainers),
          y: startY + row * (unitWidth + spacing.betweenContainers),
          section: 'left'
        });
      }
    }

    // Right section units (13-36)
    const rightStartX = startX + leftSectionWidth + pcsLength + pcsSpacing * 2;
    for (let row = 0; row < 6; row++) {
      for (let col = 0; col < 4; col++) {
        positions.push({
          x: rightStartX + col * (unitLength + spacing.betweenContainers),
          y: startY + row * (unitWidth + spacing.betweenContainers),
          section: 'right'
        });
      }
    }

    return positions;
  };

  const calculateLayoutBUnitPositions = () => {
    const positions = [];
    
    // Center everything in the room
    const pcsSpacing = spacing.containerToPcs;
    const sectionSpacing = spacing.betweenContainers * 2;
    
    // Calculate total width for centering
    const leftPcsWidth = pcsLength;
    const middleSectionWidth = 6 * (unitLength + spacing.betweenContainers) - spacing.betweenContainers;
    const middlePcsWidth = pcsLength;
    const rightSectionWidth = 3 * (unitLength + spacing.betweenContainers) - spacing.betweenContainers;
    
    const totalWidth = leftPcsWidth + pcsSpacing + middleSectionWidth + pcsSpacing + 
                    middlePcsWidth + pcsSpacing + rightSectionWidth;
    
    const startX = (roomLength - totalWidth) / 2;
    const startY = (roomWidth - (unitWidth * 4 + spacing.betweenContainers * 3)) / 2;

    // Middle section (24 units in 4x6 grid)
    const middleStartX = startX + leftPcsWidth + pcsSpacing;
    for (let row = 0; row < 4; row++) {
      for (let col = 0; col < 6; col++) {
        positions.push({
          x: middleStartX + col * (unitLength + spacing.betweenContainers),
          y: startY + row * (unitWidth + spacing.betweenContainers),
          section: 'middle'
        });
      }
    }

    // Right section (12 units in 4x3 grid)
    const rightStartX = middleStartX + middleSectionWidth + pcsSpacing + middlePcsWidth + pcsSpacing;
    for (let row = 0; row < 4; row++) {
      for (let col = 0; col < 3; col++) {
        positions.push({
          x: rightStartX + col * (unitLength + spacing.betweenContainers),
          y: startY + row * (unitWidth + spacing.betweenContainers),
          section: 'right'
        });
      }
    }

    return positions;
  };

  const calculateLayoutCUnitPositions = () => {
    const positions = [];
    const unitsPerRow = 12;

    const totalUnitsWidth = unitLength * unitsPerRow + spacing.betweenContainers * (unitsPerRow - 1);
    const totalWidth = totalUnitsWidth + 2 * (pcsLength + spacing.containerToPcs);
    const totalHeight = unitWidth * 3 + spacing.betweenContainers * 2;

    const startX = (roomLength - totalWidth) / 2;
    const startY = (roomWidth - totalHeight) / 2;

    for (let row = 0; row < 3; row++) {
      const rowY = startY + row * (unitWidth + spacing.betweenContainers);
      
      for (let col = 0; col < unitsPerRow; col++) {
        positions.push({
          x: startX + pcsLength + spacing.containerToPcs + col * (unitLength + spacing.betweenContainers),
          y: rowY,
          section: `row-${row}`
        });
      }
    }

    return positions;
  };

  const calculateLayoutAPCSPositions = () => {
    const positions = [];
    
    const leftSectionWidth = unitLength * 2 + spacing.betweenContainers;
    const pcsSpacing = spacing.containerToPcs * 2;
    const rightSectionWidth = unitLength * 4 + spacing.betweenContainers * 3;
    const totalWidth = leftSectionWidth + pcsLength + pcsSpacing + rightSectionWidth + pcsLength + spacing.containerToPcs;
    
    const startX = (roomLength - totalWidth) / 2 - pcsSpacing;
    const startY = (roomWidth - (unitWidth * 6 + spacing.betweenContainers * 5)) / 2;

    // PCS 1-4 (middle)
    const pcsLeftX = startX + leftSectionWidth + pcsSpacing;
    for (let i = 0; i < 4; i++) {
      positions.push({
        x: pcsLeftX,
        y: startY + i * (unitWidth * 1.5 + spacing.betweenContainers),
        section: 'middle'
      });
    }

    // PCS 5-6 (right)
    const pcsRightX = startX + leftSectionWidth + pcsLength + pcsSpacing * 2 + rightSectionWidth + spacing.containerToPcs * 2;
    positions.push(
      {
        x: pcsRightX,
        y: startY + unitWidth + spacing.betweenContainers,
        section: 'right'
      },
      {
        x: pcsRightX,
        y: startY + unitWidth * 4 + spacing.betweenContainers * 4,
        section: 'right'
      }
    );

    return positions;
  };

  const calculateLayoutBPCSPositions = () => {
    const positions = [];
    
    // Center everything in the room
    const pcsSpacing = spacing.containerToPcs;
    const sectionSpacing = spacing.betweenContainers * 2;
    
    // Calculate total width for centering (same as units)
    const leftPcsWidth = pcsLength;
    const middleSectionWidth = 6 * (unitLength + spacing.betweenContainers) - spacing.betweenContainers;
    const middlePcsWidth = pcsLength;
    const rightSectionWidth = 3 * (unitLength + spacing.betweenContainers) - spacing.betweenContainers;
    
    const totalWidth = leftPcsWidth + pcsSpacing + middleSectionWidth + pcsSpacing + 
                    middlePcsWidth + pcsSpacing + rightSectionWidth;
    
    const startX = (roomLength - totalWidth) / 2;
    const startY = (roomWidth - (unitWidth * 4 + spacing.betweenContainers * 3)) / 2;

    // Left side PCS (2 units)
    const pcsVerticalSpacing = (unitWidth * 4 + spacing.betweenContainers * 3 - pcsWidth * 2) / 3;
    positions.push(
      {
        x: startX,
        y: startY + pcsVerticalSpacing,
        section: 'left'
      },
      {
        x: startX,
        y: startY + pcsVerticalSpacing * 2 + pcsWidth,
        section: 'left'
      }
    );

    // Middle PCS units (4 units vertically arranged)
    const middlePcsX = startX + leftPcsWidth + pcsSpacing + middleSectionWidth + pcsSpacing;
    const middlePcsSpacing = (unitWidth * 4 + spacing.betweenContainers * 3 - pcsWidth * 4) / 5;
    
    for (let i = 0; i < 4; i++) {
      positions.push({
        x: middlePcsX,
        y: startY + middlePcsSpacing * (i + 1) + pcsWidth * i,
        section: 'middle'
      });
    }

    return positions;
  };

  const calculateLayoutCPCSPositions = () => {
    const positions = [];

    const totalUnitsWidth = unitLength * 12 + spacing.betweenContainers * 11;
    const totalWidth = totalUnitsWidth + 2 * (pcsLength + spacing.containerToPcs);
    const totalHeight = unitWidth * 3 + spacing.betweenContainers * 2;
    const startX = (roomLength - totalWidth) / 2;
    const startY = (roomWidth - totalHeight) / 2;

    for (let row = 0; row < 3; row++) {
      const rowY = startY + row * (unitWidth + spacing.betweenContainers);

      positions.push({
        x: startX,
        y: rowY + (unitWidth - pcsWidth) / 2,
        section: `row-${row}-left`
      });

      positions.push({
        x: startX + totalWidth - pcsLength,
        y: rowY + (unitWidth - pcsWidth) / 2,
        section: `row-${row}-right`
      });
    }

    return positions;
  };

  const unitPositions = (() => {
    switch (selectedLayout) {
      case 'layout-a':
        return calculateLayoutAUnitPositions();
      case 'layout-b':
        return calculateLayoutBUnitPositions();
      case 'layout-c':
        return calculateLayoutCUnitPositions();
      default:
        return calculateLayoutAUnitPositions();
    }
  })();

  const pcsPositions = (() => {
    switch (selectedLayout) {
      case 'layout-a':
        return calculateLayoutAPCSPositions();
      case 'layout-b':
        return calculateLayoutBPCSPositions();
      case 'layout-c':
        return calculateLayoutCPCSPositions();
      default:
        return calculateLayoutAPCSPositions();
    }
  })();

  const handleExportPDF = async () => {
    if (!layoutRef.current) return;
    
    const canvas = await html2canvas(layoutRef.current);
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4'
    });
    
    const imgWidth = 280;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    
    pdf.addImage(imgData, 'PNG', 10, 10, imgWidth, imgHeight);
    pdf.save(`layout-${selectedLayout}.pdf`);
  };

  const handleExportExcel = () => {
    const workbook = XLSX.utils.book_new();
    const worksheet = XLSX.utils.json_to_sheet([
      {
        'Layout Type': selectedLayout,
        'Total Units': 36,
        'PCS Units': 6,
        'Room Length': roomLength,
        'Room Width': roomWidth
      }
    ]);

    XLSX.utils.book_append_sheet(workbook, worksheet, 'Layout Details');
    XLSX.writeFile(workbook, `layout-${selectedLayout}.xlsx`);
  };

  const handleLayoutChange = (layout: LayoutType) => {
    setSelectedLayout(layout);
    
    const layoutDetails = {
      pattern: layout === 'layout-c' ? 'rows' : 'grid',
      rows: layout === 'layout-c' ? 3 : 2,
      cols: layout === 'layout-c' ? 12 : 3,
      spacing: {
        betweenContainers: spacing.betweenContainers,
        containerToPcs: spacing.containerToPcs
      }
    };
    
    onLayoutSelect(
      layout === 'layout-a' ? 1 : layout === 'layout-b' ? 2 : 3,
      layoutDetails
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex gap-4">
          <div className="flex rounded-md shadow-sm">
            <button
              type="button"
              onClick={() => handleLayoutChange('layout-a')}
              className={`px-4 py-2 text-sm font-medium ${
                selectedLayout === 'layout-a'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              } rounded-l-md border border-gray-300`}
            >
              Layout A
            </button>
            <button
              type="button"
              onClick={() => handleLayoutChange('layout-b')}
              className={`px-4 py-2 text-sm font-medium ${
                selectedLayout === 'layout-b'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              } border-t border-b border-gray-300`}
            >
              Layout B
            </button>
            <button
              type="button"
              onClick={() => handleLayoutChange('layout-c')}
              className={`px-4 py-2 text-sm font-medium ${
                selectedLayout === 'layout-c'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              } rounded-r-md border border-gray-300`}
            >
              Layout C
            </button>
          </div>
          <div className="flex rounded-md shadow-sm">
            <button
              onClick={() => setViewType('normal')}
              className={`px-4 py-2 text-sm font-medium ${
                viewType === 'normal'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              } rounded-l-md border border-gray-300`}
            >
              Normal
            </button>
            <button
              onClick={() => setViewType('top')}
              className={`px-4 py-2 text-sm font-medium ${
                viewType === 'top'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              } border-t border-b border-gray-300`}
            >
              Top View
            </button>
            <button
              onClick={() => setViewType('side')}
              className={`px-4 py-2 text-sm font-medium ${
                viewType === 'side'
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-50'
              } rounded-r-md border border-gray-300`}
            >
              Side View
            </button>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleExportPDF}
            className="flex items-center gap-2 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600"
          >
            <Download size={16} />
            Export PDF
          </button>
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
          >
            <Download size={16} />
            Export Excel
          </button>
        </div>
      </div>

      <div
        ref={layoutRef}
        className="p-4 border rounded-lg bg-white"
      >
        <svg
          width="100%"
          height="600"
          viewBox={`-2 -2 ${roomLength + 4} ${roomWidth + 4}`}
          className="bg-white"
        >
          {generateScaleMarkers()}

          <rect
            x={0}
            y={0}
            width={roomLength}
            height={roomWidth}
            fill="none"
            stroke="#94a3b8"
            strokeWidth={0.1}
          />

          {renderDimensions()}

          {pcsPositions.map((pos, index) => (
            <rect
              key={`pcs-${index}`}
              x={pos.x}
              y={pos.y}
              width={pcsLength}
              height={pcsWidth}
              fill="#d1fae5"
              stroke="#059669"
              strokeWidth={0.1}
            />
          ))}

          {unitPositions.map((pos, index) => (
            <rect
              key={`unit-${index}`}
              x={pos.x}
              y={pos.y}
              width={unitLength}
              height={unitWidth}
              fill="#bfdbfe"
              stroke="#3b82f6"
              strokeWidth={0.1}
            />
          ))}

          {unitPositions.map((pos, index) => (
            <text
              key={`text-${index}`}
              x={pos.x + unitLength / 2}
              y={pos.y + unitWidth / 2}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="#1e40af"
              fontSize={Math.min(unitLength, unitWidth) * 0.3}
            >
              {index + 1}
            </text>
          ))}

          {pcsPositions.map((pos, index) => (
            <text
              key={`pcs-text-${index}`}
              x={pos.x + pcsLength / 2}
              y={pos.y + pcsWidth / 2}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="#047857"
              fontSize={Math.min(pcsLength, pcsWidth) * 0.3}
            >
              PCS {index + 1}
            </text>
          ))}
        </svg>
      </div>
    </div>
  );
}