import { useState, useEffect } from 'react';
import { X, Plus, Save, AlertCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface ServiceProductFormProps {
  productId?: string;
  onClose: () => void;
  onSave: () => void;
}

interface FormData {
  title: string;
  description: string;
  price: string;
  features: Array<{
    title: string;
    description: string;
  }>;
  standards: Array<{
    title: string;
    description: string;
  }>;
  configurations: Array<{
    title: string;
    description: string;
  }>;
  warranties: Array<{
    title: string;
    description: string;
    duration_months: string;
    price: string;
  }>;
  benefits: Array<{
    title: string;
    description: string;
  }>;
  guarantees: Array<{
    title: string;
    description: string;
  }>;
  trainings: Array<{
    title: string;
    description: string;
    duration_days: string;
    price: string;
  }>;
}

const emptyFormData: FormData = {
  title: '',
  description: '',
  price: '',
  features: [],
  standards: [],
  configurations: [],
  warranties: [],
  benefits: [],
  guarantees: [],
  trainings: []
};

export default function ServiceProductForm({
  productId,
  onClose,
  onSave
}: ServiceProductFormProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState<FormData>(emptyFormData);

  useEffect(() => {
    if (productId) {
      loadProduct();
    }
  }, [productId]);

  async function loadProduct() {
    try {
      const { data, error } = await supabase
        .from('service_products')
        .select(`
          *,
          features:service_product_features(*),
          standards:service_product_standards(*),
          configurations:service_product_configurations(*),
          warranties:service_product_warranties(*),
          benefits:service_product_benefits(*),
          guarantees:service_product_guarantees(*),
          trainings:service_product_trainings(*)
        `)
        .eq('id', productId)
        .single();

      if (error) throw error;
      if (data) {
        setFormData({
          title: data.title,
          description: data.description,
          price: data.price.toString(),
          features: data.features.map((f: any) => ({
            title: f.title,
            description: f.description
          })),
          standards: data.standards.map((s: any) => ({
            title: s.title,
            description: s.description
          })),
          configurations: data.configurations.map((c: any) => ({
            title: c.title,
            description: c.description
          })),
          warranties: data.warranties.map((w: any) => ({
            title: w.title,
            description: w.description,
            duration_months: w.duration_months.toString(),
            price: w.price.toString()
          })),
          benefits: data.benefits.map((b: any) => ({
            title: b.title,
            description: b.description
          })),
          guarantees: data.guarantees.map((g: any) => ({
            title: g.title,
            description: g.description
          })),
          trainings: data.trainings.map((t: any) => ({
            title: t.title,
            description: t.description,
            duration_days: t.duration_days.toString(),
            price: t.price.toString()
          }))
        });
      }
    } catch (error) {
      console.error('Error loading product:', error);
      setError('Failed to load product details');
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const productData = {
        title: formData.title,
        description: formData.description,
        price: parseFloat(formData.price) || 0
      };

      let productId: string;

      if (productId) {
        // Update existing product
        const { data, error } = await supabase
          .from('service_products')
          .update(productData)
          .eq('id', productId)
          .select()
          .single();

        if (error) throw error;
        productId = data.id;
      } else {
        // Create new product
        const { data, error } = await supabase
          .from('service_products')
          .insert([productData])
          .select()
          .single();

        if (error) throw error;
        productId = data.id;
      }

      // Insert features
      await supabase
        .from('service_product_features')
        .delete()
        .eq('service_product_id', productId);

      if (formData.features.length > 0) {
        await supabase
          .from('service_product_features')
          .insert(formData.features.map(f => ({
            service_product_id: productId,
            title: f.title,
            description: f.description
          })));
      }

      // Insert standards
      await supabase
        .from('service_product_standards')
        .delete()
        .eq('service_product_id', productId);

      if (formData.standards.length > 0) {
        await supabase
          .from('service_product_standards')
          .insert(formData.standards.map(s => ({
            service_product_id: productId,
            title: s.title,
            description: s.description
          })));
      }

      // Insert configurations
      await supabase
        .from('service_product_configurations')
        .delete()
        .eq('service_product_id', productId);

      if (formData.configurations.length > 0) {
        await supabase
          .from('service_product_configurations')
          .insert(formData.configurations.map(c => ({
            service_product_id: productId,
            title: c.title,
            description: c.description
          })));
      }

      // Insert warranties
      await supabase
        .from('service_product_warranties')
        .delete()
        .eq('service_product_id', productId);

      if (formData.warranties.length > 0) {
        await supabase
          .from('service_product_warranties')
          .insert(formData.warranties.map(w => ({
            service_product_id: productId,
            title: w.title,
            description: w.description,
            duration_months: parseInt(w.duration_months) || 0,
            price: parseFloat(w.price) || 0
          })));
      }

      // Insert benefits
      await supabase
        .from('service_product_benefits')
        .delete()
        .eq('service_product_id', productId);

      if (formData.benefits.length > 0) {
        await supabase
          .from('service_product_benefits')
          .insert(formData.benefits.map(b => ({
            service_product_id: productId,
            title: b.title,
            description: b.description
          })));
      }

      // Insert guarantees
      await supabase
        .from('service_product_guarantees')
        .delete()
        .eq('service_product_id', productId);

      if (formData.guarantees.length > 0) {
        await supabase
          .from('service_product_guarantees')
          .insert(formData.guarantees.map(g => ({
            service_product_id: productId,
            title: g.title,
            description: g.description
          })));
      }

      // Insert trainings
      await supabase
        .from('service_product_trainings')
        .delete()
        .eq('service_product_id', productId);

      if (formData.trainings.length > 0) {
        await supabase
          .from('service_product_trainings')
          .insert(formData.trainings.map(t => ({
            service_product_id: productId,
            title: t.title,
            description: t.description,
            duration_days: parseInt(t.duration_days) || 0,
            price: parseFloat(t.price) || 0
          })));
      }

      onSave();
    } catch (error: any) {
      console.error('Error saving product:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const addItem = (field: keyof FormData) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...(prev[field] as any[]), {
        title: '',
        description: '',
        ...(field === 'warranties' ? { duration_months: '', price: '' } : {}),
        ...(field === 'trainings' ? { duration_days: '', price: '' } : {})
      }]
    }));
  };

  const removeItem = (field: keyof FormData, index: number) => {
    setFormData(prev => ({
      ...prev,
      [field]: (prev[field] as any[]).filter((_, i) => i !== index)
    }));
  };

  const updateItem = (field: keyof FormData, index: number, updates: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: (prev[field] as any[]).map((item, i) =>
        i === index ? { ...item, ...updates } : item
      )
    }));
  };

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">
              {productId ? 'Edit Service Product' : 'Create Service Product'}
            </h3>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {error && (
          <div className="p-4 bg-red-50">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">Title</label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Description</label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Price</label>
            <input
              type="number"
              min="0"
              step="0.01"
              value={formData.price}
              onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              required
            />
          </div>

          {/* Features */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-medium text-gray-900">Features</h4>
              <button
                type="button"
                onClick={() => addItem('features')}
                className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Feature
              </button>
            </div>
            <div className="space-y-4">
              {formData.features.map((feature, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-1">
                    <input
                      type="text"
                      value={feature.title}
                      onChange={(e) => updateItem('features', index, { title: e.target.value })}
                      placeholder="Feature title"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div className="flex-1">
                    <input
                      type="text"
                      value={feature.description}
                      onChange={(e) => updateItem('features', index, { description: e.target.value })}
                      placeholder="Feature description"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem('features', index)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Standards */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-medium text-gray-900">Standards</h4>
              <button
                type="button"
                onClick={() => addItem('standards')}
                className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Standard
              </button>
            </div>
            <div className="space-y-4">
              {formData.standards.map((standard, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-1">
                    <input
                      type="text"
                      value={standard.title}
                      onChange={(e) => updateItem('standards', index, { title: e.target.value })}
                      placeholder="Standard title"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div className="flex-1">
                    <input
                      type="text"
                      value={standard.description}
                      onChange={(e) => updateItem('standards', index, { description: e.target.value })}
                      placeholder="Standard description"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem('standards', index)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Warranties */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-medium text-gray-900">Warranties</h4>
              <button
                type="button"
                onClick={() => addItem('warranties')}
                className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Warranty
              </button>
            </div>
            <div className="space-y-4">
              {formData.warranties.map((warranty, index) => (
                <div key={index} className="grid grid-cols-4 gap-4">
                  <div className="col-span-1">
                    <input
                      type="text"
                      value={warranty.title}
                      onChange={(e) => updateItem('warranties', index, { title: e.target.value })}
                      placeholder="Title"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div className="col-span-1">
                    <input
                      type="text"
                      value={warranty.description}
                      onChange={(e) => updateItem('warranties', index, { description: e.target.value })}
                      placeholder="Description"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div>
                    <input
                      type="number"
                      value={warranty.duration_months}
                      onChange={(e) => updateItem('warranties', index, { duration_months: e.target.value })}
                      placeholder="Duration (months)"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={warranty.price}
                      onChange={(e) => updateItem('warranties', index, { price: e.target.value })}
                      placeholder="Price"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => removeItem('warranties', index)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Benefits */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-medium text-gray-900">Benefits</h4>
              <button
                type="button"
                onClick={() => addItem('benefits')}
                className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Benefit
              </button>
            </div>
            <div className="space-y-4">
              {formData.benefits.map((benefit, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-1">
                    <input
                      type="text"
                      value={benefit.title}
                      onChange={(e) => updateItem('benefits', index, { title: e.target.value })}
                      placeholder="Benefit title"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div className="flex-1">
                    <input
                      type="text"
                      value={benefit.description}
                      onChange={(e) => updateItem('benefits', index, { description: e.target.value })}
                      placeholder="Benefit description"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem('benefits', index)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Guarantees */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-medium text-gray-900">Guarantees</h4>
              <button
                type="button"
                onClick={() => addItem('guarantees')}
                className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Guarantee
              </button>
            </div>
            <div className="space-y-4">
              {formData.guarantees.map((guarantee, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex-1">
                    <input
                      type="text"
                      value={guarantee.title}
                      onChange={(e) => updateItem('guarantees', index, { title: e.target.value })}
                      placeholder="Guarantee title"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div className="flex-1">
                    <input
                      type="text"
                      value={guarantee.description}
                      onChange={(e) => updateItem('guarantees', index, { description: e.target.value })}
                      placeholder="Guarantee description"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem('guarantees', index)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Trainings */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-lg font-medium text-gray-900">Training Services</h4>
              <button
                type="button"
                onClick={() => addItem('trainings')}
                className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Training
              </button>
            </div>
            <div className="space-y-4">
              {formData.trainings.map((training, index) => (
                <div key={index} className="grid grid-cols-4 gap-4">
                  <div className="col-span-1">
                    <input
                      type="text"
                      value={training.title}
                      onChange={(e) => updateItem('trainings', index, { title: e.target.value })}
                      placeholder="Title"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div className="col-span-1">
                    <input
                      type="text"
                      value={training.description}
                      onChange={(e) => updateItem('trainings', index, { description: e.target.value })}
                      placeholder="Description"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div>
                    <input
                      type="number"
                      value={training.duration_days}
                      onChange={(e) => updateItem('trainings', index, { duration_days: e.target.value })}
                      placeholder="Duration (days)"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={training.price}
                      onChange={(e) => updateItem('trainings', index, { price: e.target.value })}
                      placeholder="Price"
                      className="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => removeItem('trainings', index)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                <>
                  <Save className="h-5 w-5 mr-2" />
                  Save Product
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}