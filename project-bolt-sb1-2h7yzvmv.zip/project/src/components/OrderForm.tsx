import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Battery, Plus, FileText, Image, Layout } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/authStore';
import type { BatteryFeature, PCSProduct, BatteryType } from '../types';

interface LegoBlock {
  id: number;
  power: number;
  capacity: number;
  containers: number;
}

const SPOWER_BLOCKS: LegoBlock[] = [
  { id: 1, power: 60, capacity: 240, containers: 1 },
  { id: 2, power: 180, capacity: 720, containers: 3 },
  { id: 3, power: 360, capacity: 1440, containers: 6 },
  { id: 4, power: 540, capacity: 2160, containers: 9 }
];

export default function OrderForm() {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [features, setFeatures] = useState<BatteryFeature[]>([]);
  const [pcsProducts, setPcsProducts] = useState<PCSProduct[]>([]);
  const [formData, setFormData] = useState({
    batteryType: 'SPower' as BatteryType,
    containerCount: 1,
    powerRequired: 0,
    capacityRequired: 0,
    length: 0,
    width: 0,
    pcsSelection: '',
    selectedFeatures: [] as string[],
    region: '',
    selectedBlocks: [] as LegoBlock[],
    upowerUnits: 1
  });

  useEffect(() => {
    fetchFeatures();
    fetchPCSProducts();
  }, []);

  async function fetchFeatures() {
    try {
      const { data, error } = await supabase
        .from('battery_features')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setFeatures(data || []);
    } catch (error) {
      console.error('Error fetching features:', error);
    }
  }

  async function fetchPCSProducts() {
    try {
      const { data, error } = await supabase
        .from('pcs_products')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setPcsProducts(data || []);
    } catch (error) {
      console.error('Error fetching PCS products:', error);
    }
  }

  const calculateSPowerBlocks = (powerRequired: number) => {
    const blocks: LegoBlock[] = [];
    let remainingPower = powerRequired;

    // Start with largest blocks first
    for (const block of [...SPOWER_BLOCKS].reverse()) {
      while (remainingPower >= block.power) {
        blocks.push(block);
        remainingPower -= block.power;
      }
    }

    // If there's remaining power, add one more block that can cover it
    if (remainingPower > 0) {
      for (const block of SPOWER_BLOCKS) {
        if (block.power >= remainingPower) {
          blocks.push(block);
          break;
        }
      }
    }

    return blocks;
  };

  const handlePowerChange = (value: number) => {
    if (formData.batteryType === 'SPower') {
      const blocks = calculateSPowerBlocks(value);
      setFormData({
        ...formData,
        powerRequired: value,
        selectedBlocks: blocks,
        containerCount: blocks.reduce((sum, block) => sum + block.containers, 0)
      });
    } else {
      // For UPower, each unit is 10kW
      const units = Math.min(Math.ceil(value / 10), 6); // Max 6 units
      setFormData({
        ...formData,
        powerRequired: value,
        upowerUnits: units,
        containerCount: units
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Create order
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert([
          {
            sales_person_id: user?.id,
            status: 'draft',
            product_type: formData.batteryType,
            quantity: formData.containerCount,
            technical_specs: {
              batteryType: formData.batteryType,
              powerRequired: formData.powerRequired,
              capacityRequired: formData.capacityRequired,
              containerCount: formData.containerCount,
              selectedBlocks: formData.selectedBlocks,
              upowerUnits: formData.upowerUnits,
              pcsSelection: formData.pcsSelection,
              features: formData.selectedFeatures,
              region: formData.region,
              dimensions: {
                length: formData.length,
                width: formData.width
              }
            },
          },
        ])
        .select()
        .single();

      if (orderError) throw orderError;

      // Generate and store documents
      const documentTypes = [
        'technical_offer',
        'commercial_offer',
        'ga_drawing',
        'front_view',
        'top_view',
        'sld',
        'layout',
      ];

      for (const type of documentTypes) {
        await supabase.from('documents').insert([
          {
            order_id: order.id,
            type,
            url: await generateDocument(type, order.id, formData),
          },
        ]);
      }

      navigate('/sales/orders/' + order.id);
    } catch (error) {
      console.error('Error creating order:', error);
    } finally {
      setLoading(false);
    }
  };

  // This is a placeholder function - implement actual document generation logic
  async function generateDocument(
    type: string,
    orderId: string,
    specs: typeof formData
  ): Promise<string> {
    // In a real implementation, this would:
    // 1. Generate technical/commercial offers using text blocks
    // 2. Combine static drawings (GA, front, top) with dynamic ones (SLD, layout)
    // 3. Upload to storage and return URL
    return `https://example.com/documents/${type}/${orderId}`;
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center mb-6">
          <Battery className="h-8 w-8 text-blue-600 mr-3" />
          <h2 className="text-2xl font-bold text-gray-900">Create New Order</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Battery Type Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Battery Type
            </label>
            <select
              value={formData.batteryType}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  batteryType: e.target.value as BatteryType,
                  selectedBlocks: [],
                  upowerUnits: 1,
                  containerCount: 1
                })
              }
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
            >
              <option value="SPower">SPower Battery</option>
              <option value="UPower">UPower Battery</option>
            </select>
          </div>

          {/* Power Requirements */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Required Power (kW)
            </label>
            <input
              type="number"
              min={formData.batteryType === 'UPower' ? 10 : 60}
              step={formData.batteryType === 'UPower' ? 10 : 60}
              value={formData.powerRequired}
              onChange={(e) => handlePowerChange(parseInt(e.target.value))}
              className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            />
            {formData.batteryType === 'SPower' && formData.selectedBlocks.length > 0 && (
              <div className="mt-2">
                <p className="text-sm text-gray-600">Selected Lego Blocks:</p>
                <ul className="mt-1 space-y-1">
                  {formData.selectedBlocks.map((block, index) => (
                    <li key={index} className="text-sm text-gray-600">
                      Block {block.id}: {block.power}kW / {block.capacity}kWh ({block.containers} containers)
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {formData.batteryType === 'UPower' && (
              <p className="mt-2 text-sm text-gray-600">
                Number of Units: {formData.upowerUnits} (10kW / 40kWh per unit)
              </p>
            )}
          </div>

          {/* Space Requirements */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Length (m)
              </label>
              <input
                type="number"
                min="1"
                step="0.1"
                value={formData.length}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    length: parseFloat(e.target.value),
                  })
                }
                className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Width (m)
              </label>
              <input
                type="number"
                min="1"
                step="0.1"
                value={formData.width}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    width: parseFloat(e.target.value),
                  })
                }
                className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              />
            </div>
          </div>

          {/* Region Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Region
            </label>
            <select
              value={formData.region}
              onChange={(e) =>
                setFormData({ ...formData, region: e.target.value })
              }
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
            >
              <option value="">Select Region</option>
              <option value="europe">Europe</option>
              <option value="namerica">North America</option>
              <option value="asia">Asia</option>
            </select>
          </div>

          {/* PCS Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              PCS Selection
            </label>
            <select
              value={formData.pcsSelection}
              onChange={(e) =>
                setFormData({ ...formData, pcsSelection: e.target.value })
              }
              className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
            >
              <option value="">Select PCS</option>
              {pcsProducts
                .filter((pcs) => pcs.region === formData.region)
                .map((pcs) => (
                  <option key={pcs.id} value={pcs.id}>
                    {pcs.manufacturer} - {pcs.name}
                  </option>
                ))}
            </select>
          </div>

          {/* Features Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Features
            </label>
            <div className="space-y-2">
              {features
                .filter(
                  (f) =>
                    f.batteryType === 'both' ||
                    f.batteryType === formData.batteryType
                )
                .map((feature) => (
                  <label
                    key={feature.id}
                    className="flex items-center space-x-3"
                  >
                    <input
                      type="checkbox"
                      checked={formData.selectedFeatures.includes(feature.id)}
                      onChange={(e) => {
                        const newFeatures = e.target.checked
                          ? [...formData.selectedFeatures, feature.id]
                          : formData.selectedFeatures.filter(
                              (id) => id !== feature.id
                            );
                        setFormData({
                          ...formData,
                          selectedFeatures: newFeatures,
                        });
                      }}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    <span className="text-sm text-gray-900">
                      {feature.name}
                      <p className="text-xs text-gray-500">
                        {feature.description}
                      </p>
                    </span>
                  </label>
                ))}
            </div>
          </div>

          {/* Preview Section */}
          <div className="border-t pt-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Generated Documents Preview
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <FileText className="h-5 w-5" />
                <span>Technical Offer</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <FileText className="h-5 w-5" />
                <span>Commercial Offer</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Image className="h-5 w-5" />
                <span>GA Drawing</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Image className="h-5 w-5" />
                <span>Front View</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Image className="h-5 w-5" />
                <span>Top View</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Layout className="h-5 w-5" />
                <span>Single Line Diagram</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Layout className="h-5 w-5" />
                <span>Layout Drawing</span>
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={loading}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              ) : (
                <>
                  <Plus className="h-5 w-5 mr-2" />
                  Create Order
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}