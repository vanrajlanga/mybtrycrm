export type BatteryType = 'SPower' | 'UPower';

export interface LegoBlock {
  id: number;
  power: number;
  capacity: number;
  containers: number;
}

export interface Profile {
  id: string;
  role: 'admin' | 'salesteam' | 'customer';
  full_name: string | null;
  created_at: string;
  updated_at: string;
}

export interface Order {
  id: string;
  customer_id: string | null;
  sales_person_id: string | null;
  status: 'draft' | 'pending' | 'completed';
  product_type: BatteryType;
  quantity: number;
  technical_specs: TechnicalSpecs;
  created_at: string;
  updated_at: string;
}

export interface TechnicalSpecs {
  batteryType: BatteryType;
  powerRequired: number;
  powerUnit: 'kW' | 'MW';
  duration: number;
  durationUnit: 'kWh' | 'MWh';
  capacityRequired: number;
  containerCount: number;
  selectedBlocks: LegoBlock[];
  upowerUnits: number;
  pcsSelection: string;
  pcsSpecs: {
    length: number;
    width: number;
  };
  spacing: {
    betweenContainers: number;
    containerToPcs: number;
  };
  features: string[];
  region: string;
  dimensions: {
    length: number;
    width: number;
  };
  selectedLayout?: number;
  layoutPattern?: 'linear' | 'grid' | 'perimeter' | 'diagonal' | 'zigzag';
  layoutRows?: number;
  layoutCols?: number;
}

export interface AddonOption {
  id: string;
  category_id: string;
  name: string;
  description: string | null;
  price: number;
  created_at: string;
}

export interface AddonCategory {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  description: string | null;
  type: BatteryType;
  specifications: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface PCSProduct {
  id: string;
  name: string;
  manufacturer: string;
  region: string;
  specifications: Record<string, any>;
  tested_by_hq: boolean;
  approved_by_hq: boolean;
  price: number;
  warranty: number;
  created_at: string;
}

export interface BatteryFeature {
  id: string;
  name: string;
  description: string | null;
  battery_type: BatteryType | 'both';
  created_at: string;
}

export interface ProductDescription {
  id: string;
  product_type: BatteryType;
  description: string;
  technical_details: Record<string, any>;
  created_at: string;
  updated_at: string;
}

export interface SystemFeature {
  id: string;
  product_type: BatteryType;
  title: string;
  description: string;
  created_at: string;
  updated_at: string;
}

export interface ProductService {
  id: string;
  product_type: BatteryType;
  title: string;
  description: string;
  price: number;
  created_at: string;
  updated_at: string;
}

export interface ProductWarranty {
  id: string;
  product_type: BatteryType;
  title: string;
  description: string;
  duration_months: number;
  price: number;
  created_at: string;
  updated_at: string;
}

export interface ProductBenefit {
  id: string;
  product_type: BatteryType;
  title: string;
  description: string;
  created_at: string;
  updated_at: string;
}

export interface ProductTraining {
  id: string;
  product_type: BatteryType;
  title: string;
  description: string;
  duration_days: number;
  price: number;
  created_at: string;
  updated_at: string;
}

export interface ServiceProduct {
  id: string;
  title: string;
  description: string;
  price: number;
  created_at: string;
  updated_at: string;
}

export interface ServiceProductFeature {
  id: string;
  service_product_id: string;
  title: string;
  description: string;
  created_at: string;
}

export interface ServiceProductStandard {
  id: string;
  service_product_id: string;
  title: string;
  description: string;
  created_at: string;
}

export interface ServiceProductConfiguration {
  id: string;
  service_product_id: string;
  title: string;
  description: string;
  created_at: string;
}

export interface ServiceProductWarranty {
  id: string;
  service_product_id: string;
  title: string;
  description: string;
  duration_months: number;
  price: number;
  created_at: string;
}

export interface ServiceProductBenefit {
  id: string;
  service_product_id: string;
  title: string;
  description: string;
  created_at: string;
}

export interface ServiceProductGuarantee {
  id: string;
  service_product_id: string;
  title: string;
  description: string;
  created_at: string;
}

export interface ServiceProductTraining {
  id: string;
  service_product_id: string;
  title: string;
  description: string;
  duration_days: number;
  price: number;
  created_at: string;
}

export interface Quotation {
  id: string;
  project_name: string;
  project_description: string | null;
  editor_name: string;
  planning_office: string;
  customer_name: string;
  customer_city: string;
  customer_address: string;
  customer_email: string;
  customer_phone: string;
  service_product_id: string;
  selected_features: string[];
  selected_standards: string[];
  selected_configurations: string[];
  selected_warranty: string;
  selected_benefits: string[];
  selected_guarantees: string[];
  selected_trainings: string[];
  total_price: number;
  status: 'draft' | 'sent' | 'accepted' | 'rejected';
  created_by: string;
  created_at: string;
  updated_at: string;
}