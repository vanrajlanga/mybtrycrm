import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import DashboardLayout from './components/DashboardLayout';
import OrderForm from './pages/Orders/OrderForm';
import OrderHistory from './pages/Orders/OrderHistory';
import OrderDetails from './pages/Orders/OrderDetails';
import Products from './pages/Products';
import QuotationForm from './pages/Quotations/QuotationForm';
import QuotationList from './pages/Quotations/QuotationList';
import QuotationDetails from './pages/Quotations/QuotationDetails';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuthStore();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-100">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <DashboardLayout>{children}</DashboardLayout>;
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
        <Route path="/dashboard/products" element={<PrivateRoute><Products /></PrivateRoute>} />
        <Route path="/dashboard/orders">
          <Route path="new" element={<PrivateRoute><OrderForm /></PrivateRoute>} />
          <Route path="history" element={<PrivateRoute><OrderHistory /></PrivateRoute>} />
          <Route path=":id" element={<PrivateRoute><OrderDetails /></PrivateRoute>} />
        </Route>
        <Route path="/dashboard/quotations">
          <Route path="new" element={<PrivateRoute><QuotationForm /></PrivateRoute>} />
          <Route path="list" element={<PrivateRoute><QuotationList /></PrivateRoute>} />
          <Route path=":id" element={<PrivateRoute><QuotationDetails /></PrivateRoute>} />
          <Route path=":id/edit" element={<PrivateRoute><QuotationForm /></PrivateRoute>} />
        </Route>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Router>
  );
}