import Drawing from 'dxf-writer';

export function createDXFDrawing() {
  const d = new Drawing();
  
  return {
    setLayer: (name: string) => {
      d.addLayer(name, Drawing.ACI.BYLAYER, 'CONTINUOUS');
      d.setActiveLayer(name);
    },
    drawLine: (x1: number, y1: number, x2: number, y2: number) => {
      d.drawLine(x1, y1, x2, y2);
    },
    drawRect: (x: number, y: number, width: number, height: number) => {
      // Draw rectangle using lines since some DXF viewers have issues with native rectangles
      d.drawLine(x, y, x + width, y); // Top
      d.drawLine(x + width, y, x + width, y + height); // Right
      d.drawLine(x + width, y + height, x, y + height); // Bottom
      d.drawLine(x, y + height, x, y); // Left
    },
    drawText: (x: number, y: number, height: number, text: string) => {
      d.drawText(x, y, height, 0, text);
    },
    drawDimension: (x1: number, y1: number, x2: number, y2: number, offset: number, text: string) => {
      d.drawAlignedDimension(x1, y1, x2, y2, offset, text);
    },
    toDxfString: () => d.toDxfString()
  };
}

export function createSLDDrawing() {
  const d = new Drawing();
  
  return {
    setLayer: (name: string) => {
      d.addLayer(name, Drawing.ACI.BYLAYER, 'CONTINUOUS');
      d.setActiveLayer(name);
    },
    drawBattery: (x: number, y: number, width: number, height: number) => {
      // Battery symbol
      d.drawLine(x, y, x + width, y); // Top
      d.drawLine(x + width, y, x + width, y + height); // Right
      d.drawLine(x + width, y + height, x, y + height); // Bottom
      d.drawLine(x, y + height, x, y); // Left
      
      // Draw positive and negative terminals
      const terminalWidth = width * 0.2;
      const terminalHeight = height * 0.1;
      // Positive terminal (horizontal and vertical lines)
      d.drawLine(x + width/2 - terminalWidth/2, y - terminalHeight, x + width/2 + terminalWidth/2, y - terminalHeight);
      d.drawLine(x + width/2, y - terminalHeight*2, x + width/2, y - terminalHeight);
      // Negative terminal (horizontal line)
      d.drawLine(x + width/2 - terminalWidth/2, y + height + terminalHeight, x + width/2 + terminalWidth/2, y + height + terminalHeight);
    },
    drawPCS: (x: number, y: number, width: number, height: number) => {
      // PCS symbol (rectangle with internal components)
      d.drawLine(x, y, x + width, y); // Top
      d.drawLine(x + width, y, x + width, y + height); // Right
      d.drawLine(x + width, y + height, x, y + height); // Bottom
      d.drawLine(x, y + height, x, y); // Left
      
      // Draw internal components to represent PCS
      const margin = width * 0.1;
      const componentWidth = width * 0.3;
      const componentHeight = height * 0.2;
      // Draw three internal rectangles
      d.drawLine(x + margin, y + height * 0.2, x + margin + componentWidth, y + height * 0.2);
      d.drawLine(x + margin + componentWidth, y + height * 0.2, x + margin + componentWidth, y + height * 0.2 + componentHeight);
      d.drawLine(x + margin + componentWidth, y + height * 0.2 + componentHeight, x + margin, y + height * 0.2 + componentHeight);
      d.drawLine(x + margin, y + height * 0.2 + componentHeight, x + margin, y + height * 0.2);
    },
    drawConnection: (x1: number, y1: number, x2: number, y2: number) => {
      // Draw connection line with arrow
      d.drawLine(x1, y1, x2, y2);
      
      // Calculate arrow points
      const arrowLength = 200;
      const arrowAngle = Math.PI / 6;
      const angle = Math.atan2(y2 - y1, x2 - x1);
      
      const x3 = x2 - arrowLength * Math.cos(angle - arrowAngle);
      const y3 = y2 - arrowLength * Math.sin(angle - arrowAngle);
      const x4 = x2 - arrowLength * Math.cos(angle + arrowAngle);
      const y4 = y2 - arrowLength * Math.sin(angle + arrowAngle);
      
      // Draw arrow head
      d.drawLine(x2, y2, x3, y3);
      d.drawLine(x2, y2, x4, y4);
    },
    drawText: (x: number, y: number, height: number, text: string) => {
      d.drawText(x, y, height, 0, text);
    },
    toDxfString: () => d.toDxfString()
  };
}