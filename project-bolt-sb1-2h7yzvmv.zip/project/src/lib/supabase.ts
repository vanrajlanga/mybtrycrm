import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables. Please check your .env file and ensure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set correctly.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: 'supabase.auth.token',
    storage: window.localStorage
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  },
  global: {
    headers: {
      'x-application-name': 'battery-crm'
    },
    fetch: (url, options) => {
      return fetch(url, {
        ...options,
        timeout: 30000, // 30 second timeout
      }).catch(error => {
        console.error('Fetch error:', error);
        throw new Error('Network error: Please check your internet connection');
      });
    }
  }
});

// Enhanced connection check with retries
export const checkConnection = async (retries = 3): Promise<boolean> => {
  for (let i = 0; i < retries; i++) {
    try {
      const { error } = await supabase.from('profiles').select('count', { count: 'exact', head: true });
      if (!error) {
        return true;
      }
      console.warn(`Connection attempt ${i + 1} failed:`, error);
      // Wait before retrying (exponential backoff)
      await new Promise(resolve => setTimeout(resolve, Math.pow(2, i) * 1000));
    } catch (error) {
      console.error(`Connection attempt ${i + 1} failed:`, error);
      if (i === retries - 1) {
        throw new Error('Failed to connect to Supabase after multiple attempts. Please check your internet connection and configuration.');
      }
    }
  }
  return false;
};

// Enhanced error handler with specific error messages
export const handleSupabaseError = (error: any): Error => {
  if (!error) return new Error('An unknown error occurred');

  // Network related errors
  if (error.message?.includes('Failed to fetch') || error.code === 'NETWORK_ERROR') {
    return new Error('Connection to database failed. Please check your internet connection and try again.');
  }

  // Authentication errors
  if (error.code?.startsWith('auth/') || error.message?.includes('auth')) {
    return new Error('Authentication error. Please try logging in again.');
  }

  // Rate limiting
  if (error.status === 429) {
    return new Error('Too many requests. Please try again later.');
  }

  // Database errors
  if (error.code?.startsWith('PGRST')) {
    return new Error('Database error. Please try again or contact support if the problem persists.');
  }

  // Return original error if no specific handling
  return error instanceof Error ? error : new Error(error.message || 'An unexpected error occurred');
};

// Initialize connection check
checkConnection()
  .then(isConnected => {
    if (!isConnected) {
      console.error('Failed to establish initial connection to Supabase');
    }
  })
  .catch(error => {
    console.error('Error during initial connection check:', error);
  });