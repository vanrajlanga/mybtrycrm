import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function calculateTotalPower(blocks: Array<{ power: number }>): number {
  return blocks.reduce((total, block) => total + block.power, 0);
}

export function calculateTotalCapacity(blocks: Array<{ capacity: number }>): number {
  return blocks.reduce((total, block) => total + block.capacity, 0);
}

export function convertPowerValue(value: number, fromUnit: 'kW' | 'MW', toUnit: 'kW' | 'MW'): number {
  if (fromUnit === toUnit) return value;
  if (fromUnit === 'MW' && toUnit === 'kW') return value * 1000;
  if (fromUnit === 'kW' && toUnit === 'MW') return value / 1000;
  return value;
}

export function convertEnergyValue(value: number, fromUnit: 'kWh' | 'MWh', toUnit: 'kWh' | 'MWh'): number {
  if (fromUnit === toUnit) return value;
  if (fromUnit === 'MWh' && toUnit === 'kWh') return value * 1000;
  if (fromUnit === 'kWh' && toUnit === 'MWh') return value / 1000;
  return value;
}